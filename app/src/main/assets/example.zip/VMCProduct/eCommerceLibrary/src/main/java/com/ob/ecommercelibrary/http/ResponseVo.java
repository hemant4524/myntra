package com.ob.ecommercelibrary.http;

import com.ob.ecommercelibrary.vo.BaseVo;

import java.io.Reader;

/**
 * Created by Ishan4452 on 6/7/2016.
 */
public class ResponseVo {


   public  BaseVo baseVo;
   public  Reader reader;
}
