package com.ob.ecommercelibrary.utils;

/**
 * Created by Ishan4452 on 9/24/2015.
 */
public class LibConstants {
    public static final String PREF_DRAWER_MENU_ITEMS = "pref_drawer_menu_item";
}
