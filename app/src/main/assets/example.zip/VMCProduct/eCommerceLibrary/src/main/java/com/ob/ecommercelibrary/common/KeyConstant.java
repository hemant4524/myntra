package com.ob.ecommercelibrary.common;

/**
 * Created by software on 9/23/15.
 */
public class KeyConstant {


    // Pref Keys
    public static final String PREF_ACCESS_TOKEN = "access_token";

    public static final String PREF_USER_ID = "user_id";

    // Broadcast action
    public static final String ACTION = "Action";
    // Broadcast action name
    public static final String BROAD_CAST_ACTION_NAME = "com.ob.ecommerce";
    public static final int ACTION_LOGOUT_FINISH = 0;
}
