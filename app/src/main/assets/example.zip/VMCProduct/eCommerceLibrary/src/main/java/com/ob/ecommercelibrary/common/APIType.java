package com.ob.ecommercelibrary.common;

/**
 * Created by Ishan4452 on 6/14/2016.
 */
public class APIType {

    public static int METHOD_GET=0;
    public static int METHOD_POST=1;
}
