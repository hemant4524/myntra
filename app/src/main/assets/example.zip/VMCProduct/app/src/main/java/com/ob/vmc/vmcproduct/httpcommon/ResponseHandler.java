package com.ob.vmc.vmcproduct.httpcommon;

import com.ob.ecommercelibrary.http.HttpResponseHandler;
import com.ob.ecommercelibrary.vo.BaseVo;

import java.io.Reader;

/**
 * Created by Ishan4452 on 6/14/2016.
 */

/*This Class handle API response next action or result*/
public class ResponseHandler implements HttpResponseHandler {

    private OnCompleteListener onCompleteListener;

    public ResponseHandler(OnCompleteListener onCompleteListener) {
        this.onCompleteListener = onCompleteListener;
    }

    @Override
    public void onFail(BaseVo baseVo, int pRequestCode) {
        onCompleteListener.onError(baseVo);
    }

    @Override
    public void onSuccess(Reader reader, int mRequestCode) {
        new AsycResponseParcer(reader, mRequestCode, onCompleteListener).execute();

    }

}
