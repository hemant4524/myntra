package com.ob.vmc.vmcproduct.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ob.vmc.vmcproduct.R;

/**
 * Created by Ishan4452 on 10/17/2016.
 */

public class OnBoardingActivity extends AppCompatActivity {
    private static final int TOTAL_TOUR_PAGE = 3;
    private ViewPager mVPTour;
    private TextView mTvFinish;
    private LinearLayout mLlVpIndictor;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding);

        initViews();
        initAdapter();
        initListener();
    }

    private void initViews() {
        mVPTour = (ViewPager) findViewById(R.id.aob_vpObBoardScreen);
        mTvFinish = (TextView) findViewById(R.id.aob_tvOnBoardFinish);
        mLlVpIndictor = (LinearLayout) findViewById(R.id.aob_llViewPagerIndicator);
    }

    private void initAdapter() {
        mVPTour.setAdapter(new OnBoardingAdapter(this));

        for (int i = 0; i < TOTAL_TOUR_PAGE; i++) {
            ImageView indicator = new ImageView(this);
            indicator.setPadding(10,0,10,0);
            if (i == 0)
                indicator.setImageResource(R.drawable.slider_active);
            else
                indicator.setImageResource(R.drawable.slider_deactive);
            mLlVpIndictor.addView(indicator);
        }

    }

    private void initListener() {

        mVPTour.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                int indicatorCount = mLlVpIndictor.getChildCount();
                for (int i = 0; i < indicatorCount; i++) {
                    ImageView indicator = (ImageView) mLlVpIndictor.getChildAt(i);
                    if (position == i) {
                        indicator.setImageResource(R.drawable.slider_active);
                    } else {
                        indicator.setImageResource(R.drawable.slider_deactive);
                    }

                    if (position == TOTAL_TOUR_PAGE - 1) {
                        mTvFinish.setText(R.string.txt_get_started);
                        mTvFinish.setTextColor(getResources().getColor(R.color.white));
                        mTvFinish.setBackgroundResource(R.color.get_started_background);
                    }else
                    {
                        mTvFinish.setText(R.string.txt_get_skip);
                        mTvFinish.setTextColor(getResources().getColor(R.color.black));
                        mTvFinish.setBackground(null);
                    }
                }


            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private class OnBoardingAdapter extends PagerAdapter {
        private Context aContext;

        public OnBoardingAdapter(Context context) {
            aContext = context;
        }


        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View view;
            if (position == 0) {
                view = LayoutInflater.from(aContext).inflate(R.layout.adapter_onboard_screen_one, container, false);
            } else if (position == 1) {
                view = LayoutInflater.from(aContext).inflate(R.layout.adapter_onboard_screen_two, container, false);
            } else {
                view = LayoutInflater.from(aContext).inflate(R.layout.adapter_onboard_screen_third, container, false);
            }

            container.addView(view);
            return (ViewGroup)view;
        }

        @Override
        public int getCount() {
            return TOTAL_TOUR_PAGE;
        }

        @Override
        public void destroyItem(ViewGroup collection, int position, Object view) {
            collection.removeView((View) view);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

    }
}
