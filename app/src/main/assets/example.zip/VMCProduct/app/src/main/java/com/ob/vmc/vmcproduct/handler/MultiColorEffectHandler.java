package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

/**
 * Created by khyati5403 on 12/6/2016.
 */

public class MultiColorEffectHandler {

    private Context mContext;
    private boolean isEngraveEffect;


    public MultiColorEffectHandler(Context pContext) {
        mContext=pContext;
    }

    public Bitmap executeProcess(Bitmap srcBitmap) {

      //Do some code If required

        return srcBitmap ;

    }
}
