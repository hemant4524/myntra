package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.EmbossMaskFilter;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/28/2016.
 */

public class EmbroideryEffectHandler {

    private Context mContext;


    public EmbroideryEffectHandler(Context mContext) {
        this.mContext = mContext;
    }


    public Bitmap executeProcess(int colorCode, Bitmap srcBitmap, int drawableMask, boolean removeWhite) {

        try {
            if (srcBitmap != null) {
                Bitmap mask = BitmapFactory.decodeResource(mContext.getResources(), drawableMask);

                if (removeWhite) {

                    int[] intArray = new int[srcBitmap.getWidth() * srcBitmap.getHeight()];
                    srcBitmap.getPixels(intArray, 0, srcBitmap.getWidth(), 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight());
                    ;
                    for (int x = 0; x < intArray.length; x++) {
                        intArray[x] = BitmapProcessing.removeWhite(intArray[x]);

                    }
                    srcBitmap = Bitmap.createBitmap(intArray, srcBitmap.getWidth(), srcBitmap.getHeight(), srcBitmap.getConfig());
                }

                int width = srcBitmap.getWidth();
                int height = srcBitmap.getHeight();

                Bitmap result1 = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas mCanvas = new Canvas(result1);

                RectF mDstRect = new RectF();
                mDstRect.set(0, 0, width, height);

                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                Shader textShader = new BitmapShader(mask,
                        Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                paint.setShader(textShader);


                ColorFilter filter = new LightingColorFilter(colorCode, 1);
                paint.setColorFilter(filter);
                mCanvas.drawRect(mDstRect, paint);

                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
                paint.setMaskFilter(new EmbossMaskFilter(new float[]{0f, 1f, 0.5f}, 0.8f, 3f, 3f));
                mCanvas.drawBitmap(srcBitmap, 0, 0, paint);

                return result1;
//                srcBitmap = BitmapProcessing.embroideryEffect(colorCode, srcBitmap, mask);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return srcBitmap;

    }
}
