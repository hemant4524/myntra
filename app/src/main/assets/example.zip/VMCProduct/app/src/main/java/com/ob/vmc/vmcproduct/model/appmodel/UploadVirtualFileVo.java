package com.ob.vmc.vmcproduct.model.appmodel;

import java.util.List;

/**
 * Created by Ishan4452 on 12/14/2016.
 */
public class UploadVirtualFileVo {

    private String colorCode;
    private List<VirtualFileSideVo> virtualFileSideVos;

    public UploadVirtualFileVo(String colorCode, List<VirtualFileSideVo> virtualFileSideVos) {
        this.colorCode = colorCode;
        this.virtualFileSideVos = virtualFileSideVos;
    }

    public String getColorCode() {
        return colorCode;
    }

    public List<VirtualFileSideVo> getVirtualFileSideVos() {
        return virtualFileSideVos;
    }
}
