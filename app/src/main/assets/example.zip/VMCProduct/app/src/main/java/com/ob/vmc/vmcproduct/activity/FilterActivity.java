package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.andoblib.log.CustomLogHandler;
import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.communicator.FilterCommunicator;
import com.ob.vmc.vmcproduct.communicator.OnFilterTypeClick;
import com.ob.vmc.vmcproduct.constant.AppConstant;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.fragment.FilterAttributeFragment;
import com.ob.vmc.vmcproduct.fragment.FilterTypeFragment;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import java.util.ArrayList;
import java.util.List;

public class FilterActivity extends VirtualBaseActivity implements OnCompleteListener, OnFilterTypeClick, FilterCommunicator {

    public static final String EXTRA_FILTER_CATEGORY_ORIGINAL = "originalCategory";
    public static final String EXTRA_FILTER_PARAMS = "filterParams";
    private static final String TAG = FilterActivity.class.getSimpleName();
    private Toolbar mToolbar;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private TextView tvApply, tvClearAll;
    private List<SuppliersVO.DataVo.SuppliersVo> suppliersVOList;
    private FilterAttributeFragment currentFragment;
    private Fragment leftFragment;
    private SuppliersVO suppliersVO;
    private ArrayList<Object> list;
    private View fab_cancle;

    private String mOriginalCategory = null;
    private String mSelectedCategory;
    private boolean isAnySelected = false;
    private boolean isCleared = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        Bundle extra = getIntent().getExtras();
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle(R.string.app_name);

        mToolbar.setNavigationIcon(R.drawable.menu);
        bindLeftFragment(savedInstanceState);
        fab_cancle = findViewById(R.id.apl_fabCancle);
        fab_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mSelectedCategory = extra.getString(ProductListingActivity.EXTRA_FILTER_SELECTED_CATEGORY);
        isAnySelected = !TextUtils.isEmpty(mSelectedCategory);

        tvApply = (TextView) findViewById(R.id.af_tvApply);
        tvApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra(ProductListingActivity.EXTRA_FILTER_SELECTED_CATEGORY, mSelectedCategory);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        tvClearAll = (TextView) findViewById(R.id.af_tvClearAll);
        tvClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAnySelected)
                    isCleared = true;

                mSelectedCategory = null;

                if (currentFragment != null && !currentFragment.isRemoving() && currentFragment.isAdded())
                    currentFragment.notifyClear();
            }
        });

    }

    private void bindLeftFragment(Bundle savedInstanceState) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (savedInstanceState == null) {
            leftFragment = FilterTypeFragment.newInstance();
            addFragment(R.id.af_flLeftContainer, false, leftFragment, FilterTypeFragment.TAG);
            findViewById(R.id.af_flLeftContainer).setVisibility(View.VISIBLE);
            callFilterAPI();
        } else {
            leftFragment = fragmentManager.findFragmentById(R.id.af_flLeftContainer);
        }
    }

    private void callFilterAPI() {
        CommonUtil.showProgressDialog(this, null, null, false, null, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL, getSupportFragmentManager());
        String url = WSUrlConstant.urlAppendWithBaseUrl(WSUrlConstant.API_SUPPLIER);

        String supplierId= AppSetting.getString(this, SharePrefConstant.KEY_SUPPLIER_ID,"");
        List<NameValuePair> postParams=new ArrayList<>();
        postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID,supplierId));

        FormHttpCaller formHttpCaller = new FormHttpCaller(getBaseContext(), url, APIType.METHOD_GET, postParams, WSRequestCodeConstant.REQUEST_SUPPLIER, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();

        BaseVo baseVo = (BaseVo) itemObj;
        suppliersVO = (SuppliersVO) itemObj;
        if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                if (requestCode == WSRequestCodeConstant.REQUEST_SUPPLIER) {

                    suppliersVOList = suppliersVO.getData().getSuppliers();

                    list = new ArrayList<>();
                    for (int i = 0; i < suppliersVOList.size(); i++) {
                        String supplierName = suppliersVOList.get(i).getSupplierName();
                        list.add(supplierName);

                    }
                }
        }
    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        BaseVo baseVo = (BaseVo) itemObj;
        CommonUtil.showSimpleDialog(this, getString(R.string.title_error), ((BaseVo) itemObj).getCustomException().getMessage(), "OK", false, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL, null, getSupportFragmentManager());
    }

    @Override
    public void onError(Object itemObj) {
        BaseVo baseVo = (BaseVo) itemObj;
        CommonUtil.showSimpleDialog(this, getString(R.string.title_error), ((BaseVo) itemObj).getCustomException().getMessage(), "OK", false, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL, null, getSupportFragmentManager());
    }

    @Override
    public void onFilterTypeClick(int position) {
        Bundle extraArgs = new Bundle();
        extraArgs.putString(FilterAttributeFragment.EXTRA_FILTER_ITEMS_SELECTED, mSelectedCategory);
        View v = findViewById(R.id.af_flRightContainer);
        if (v.getVisibility() == View.GONE)
            v.setVisibility(View.VISIBLE);
        currentFragment = FilterAttributeFragment.newInstance(suppliersVOList, extraArgs);
        replaceFragment(R.id.af_flRightContainer, false, currentFragment, FilterAttributeFragment.TAG);

    }

    @Override
    public void onAttributeClick(String value, String position) {
        if (value != null && value.length() > 0) {
            CustomLogHandler.printInfo(TAG, value);
        }
        mSelectedCategory = position;

    }
}
