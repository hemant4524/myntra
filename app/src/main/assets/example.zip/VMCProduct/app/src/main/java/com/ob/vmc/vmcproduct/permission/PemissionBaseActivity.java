package com.ob.vmc.vmcproduct.permission;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import java.util.List;


/**
 * Created by Ishan4452 on 10/29/2015.
 */
public abstract class PemissionBaseActivity extends AppCompatActivity
{
   


    OnPermissionActionListner onPermissionActionListner;


    @TargetApi(Build.VERSION_CODES.M)
    public void checkSinglePermission(Context context, String permissionNeed, String permissionMessage, int requestCode)
    {
        onPermissionActionListner = (OnPermissionActionListner) context;
        checkPermissions(this, new PermissionVo(new String[]{permissionNeed}, permissionMessage), requestCode);

    }

    @TargetApi(Build.VERSION_CODES.M)
    public void checkMultiplePermission(Fragment context, PermissionVo permissionVos, int requestCode)
    {
        onPermissionActionListner = (OnPermissionActionListner) context;
        checkPermissions(this, permissionVos, requestCode);

    }


    @TargetApi(Build.VERSION_CODES.M)
    public void checkMultiplePermission(Context context, PermissionVo permissionVos, int requestCode)
    {
        onPermissionActionListner = (OnPermissionActionListner) context;
        checkPermissions(this, permissionVos, requestCode);

    }
/*

    public void checkAllPermission(int requestCode) {
        checkPermissions(requestCode, Utils.getAllApplicationPermission());
    }
*/

    @TargetApi(Build.VERSION_CODES.M)
    private void checkPermissions(Context context, final PermissionVo permissionVo, final int requestCode)
    {



        if (PermissionUtils.hasSelfPermissions(this, permissionVo.getPermissionName()))
        {
            onPermissionActionListner.permissionGranted(requestCode);
        }
        else
        {
            if (PermissionUtils.shouldShowRequestPermissionRationale(context, permissionVo.getPermissionName()))
            {
                showRationaleDialog(context, permissionVo, requestCode);
            }
            else
            {
                requestPermissions( permissionVo.getPermissionName(), requestCode);
            }
        }



    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener, DialogInterface.OnClickListener cancelListener)
    {
        new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", okListener).setNegativeButton("Cancel", cancelListener).create().show();
    }

    @TargetApi(Build.VERSION_CODES.M)
    private boolean addPermission(List<String> permissionsList, String permission)
    {
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED)
        {
            permissionsList.add(permission);
            // Check for Rationale Option
            if (!shouldShowRequestPermissionRationale(permission))
            {
                return false;
            }
        }
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        if (PermissionUtils.getTargetSdkVersion(this) < 23 && !PermissionUtils.hasSelfPermissions(this, permissions))
        {
            onPermissionActionListner.permissionDenied(requestCode);
            return;
        }


        if (PermissionUtils.verifyPermissions(grantResults))
        {
            onPermissionActionListner.permissionGranted(requestCode);
        }
        else
        {
            if (!PermissionUtils.shouldShowRequestPermissionRationale(this, permissions))
            {
                onPermissionActionListner.permissionNeverAsked(requestCode);
            }
            else
            {
                onPermissionActionListner.permissionDenied(requestCode);
            }
        }


/*
        Map<String, Integer> perms = Utils.getAllApplicationPermissionNeededResult();

        for (int i = 0; i < permissions.length; i++)
            perms.put(permissions[i], grantResults[i]);*/

        //        permissionGranted(requestCode, perms);

       /* switch (requestCode) {
            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS: {
                // Fill with results
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);

                permissionGranted(perms);

            }
            break;
            case REQUEST_CODE_ASK_SINGLE_PERMISSIONS:
                    perms.put(permissions[0],grantResults[0]);
                    permissionGranted(perms);
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }*/
    }


    private void showRationaleDialog(final Context context, final PermissionVo permissionVo, final int requestCode)
    {
        new AlertDialog.Builder(this).setPositiveButton("Allow", new DialogInterface.OnClickListener()
        {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(@NonNull DialogInterface dialog, int which)
            {

                requestPermissions(permissionVo.getPermissionName(), requestCode);
            }
        }).setNegativeButton("Deny", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(@NonNull DialogInterface dialog, int which)
            {
                onPermissionActionListner.permissionDenied(requestCode);
            }
        }).setCancelable(false).setMessage(permissionVo.getPermissionMessage()).show();
    }



    public void openAppSettingDialog(final Activity context, String message)
    {
        new AlertDialog.Builder(this).setPositiveButton("GO", new DialogInterface.OnClickListener()
        {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(@NonNull DialogInterface dialog, int which)
            {
                startInstalledAppDetailsActivity(context);
            }
        }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(@NonNull DialogInterface dialog, int which)
            {

            }
        }).setCancelable(false).setMessage(message).show();
    }

    public void startInstalledAppDetailsActivity(final Activity context) {
        if (context == null) {
            return;
        }
        final Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" + context.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        context.startActivity(i);
    }

}

