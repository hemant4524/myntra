package com.ob.vmc.vmcproduct.model.httpmodel;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by khyati5403 on 10/19/2016.
 */

public class Product {

    /**
     * productId : 1920
     * sku : 4097
     * supportedCulture : ["en_us"]
     * personalized : 1
     * supplierId : 309
     * category : {"id":"2657","en_us":"Plush & Unique"}
     * productTitle : Star Shape Stress Reliever
     * color : Yellow
     * productImage : http://virtualmarketingcart.com/Virtual/54607c1317207c5f03d63af1/583e831a85eff468187d1cd5/ProductMaster/main/4097_yellow-500x500.jpg
     * thumbImage : http://virtualmarketingcart.com/Virtual/54607c1317207c5f03d63af1/583e831a85eff468187d1cd5/ProductMaster/main/4097_yellow-100x100.jpg
     */

    @SerializedName("productId")
    private String productId;
    @SerializedName("sku")
    private String sku;
    @SerializedName("personalized")
    private int personalized;
    @SerializedName("supplierId")
    private String supplierId;
    @SerializedName("category")
    private CategoryVo category;
    @SerializedName("productTitle")
    private String productTitle;
    @SerializedName("color")
    private String color;
    @SerializedName("productImage")
    private String productImage;
    @SerializedName("thumbImage")
    private String thumbImage;
    @SerializedName("supportedCulture")
    private List<String> supportedCulture;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public int getPersonalized() {
        return personalized;
    }

    public void setPersonalized(int personalized) {
        this.personalized = personalized;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public CategoryVo getCategory() {
        return category;
    }

    public void setCategory(CategoryVo category) {
        this.category = category;
    }

    public String getProductTitle() {
        return productTitle;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getThumbImage() {
        return thumbImage;
    }

    public void setThumbImage(String thumbImage) {
        this.thumbImage = thumbImage;
    }

    public List<String> getSupportedCulture() {
        return supportedCulture;
    }

    public void setSupportedCulture(List<String> supportedCulture) {
        this.supportedCulture = supportedCulture;
    }

    public static class CategoryVo {
        /**
         * id : 2657
         * en_us : Plush & Unique
         */

        @SerializedName("id")
        private String id;
        @SerializedName("en_us")
        private String enUs;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getEnUs() {
            return enUs;
        }

        public void setEnUs(String enUs) {
            this.enUs = enUs;
        }
    }
}

