package com.ob.vmc.vmcproduct.customviews;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;

import com.ob.vmc.vmcproduct.R;

/**
 * Created by khyati5403 on 11/16/2016.
 */

public class ShowView extends View {
    private float mFontSize = 22;
    private DisplayMetrics dm;
    private String mStr = "";
    private Paint mPaintText;
    private Paint mPaint;
    private RectF mRectF;
    private Paint.FontMetrics fm;

    public ShowView(Context context) {
        super(context);
        initShowView(context, null);
    }

    public ShowView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initShowView(context, attrs);
    }

    public ShowView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initShowView(context, attrs);
    }


    private void initShowView(Context context, AttributeSet attr) {
        dm = getResources().getDisplayMetrics();
        // Initialize a new Paint instance to draw the rounded rectangle
        mPaintText = new Paint();
        mPaintText.setStyle(Paint.Style.FILL);
//        mPaintText.setColor(Color.argb(176,155,155,157));
        mPaintText.setColor(Color.WHITE);
        mPaintText.setAntiAlias(true);
        mPaintText.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, mFontSize, dm));

        fm = new Paint.FontMetrics();
        mPaintText.getFontMetrics(fm);

        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setColor(context.getResources().getColor(R.color.show_view_color));

        mRectF = new RectF();
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int parentWidth = MeasureSpec.getSize(widthMeasureSpec);
        int parentHeight = MeasureSpec.getSize(heightMeasureSpec);
        this.setMeasuredDimension(parentWidth, parentHeight);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);


        float viewWidth = getWidth() / 2;
        float viewX = viewWidth / 2;

        float textWidth = mPaintText.measureText(mStr);

        float textX = viewWidth - (textWidth / 2);
        float margin = 15;

        mRectF.set(viewX, 100f + fm.top - margin,
                viewX + viewWidth, 100f + fm.bottom
                        + margin);

        canvas.drawRoundRect(mRectF, 50, 50, mPaint);

        canvas.drawText(mStr, textX, 100, mPaintText);


    }

    public void setText(String text) {
        mStr = text;
        invalidate();
    }


    public void showView() {
     setVisibility(VISIBLE);

    }

    public void hideView(final Activity context) {
        this.postDelayed(new Runnable() {
            @Override
            public void run() {

                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setVisibility(GONE);
                    }
                });
            }
        },1500);

    }
}
