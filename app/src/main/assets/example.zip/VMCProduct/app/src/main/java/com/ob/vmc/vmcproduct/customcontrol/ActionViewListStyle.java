package com.ob.vmc.vmcproduct.customcontrol;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.LayoutTransition;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.utils.Util;


/**
 * Created by Anuj4453 on 7/23/2015.
 */
public class ActionViewListStyle extends RelativeLayout
{
    private AnimatorSet mAnimatorSet;
    private ImageView visibleImageView, hiddenImageView;
    private boolean firstVisible = true;
    public static final int ANIMATION_DURATION = 500;

    public ActionViewListStyle(Context context)
    {
        this(context, null);

    }

    public ActionViewListStyle(Context context, AttributeSet attrs)
    {
        this(context, attrs, 0);
    }

    public ActionViewListStyle(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr, 0);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public ActionViewListStyle(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes)
    {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs, defStyleAttr, defStyleRes);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void init(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes)
    {
        this.setMinimumHeight(getContext().getResources().getDimensionPixelOffset(R.dimen.reg_dimen_48dp));
        this.setMinimumWidth(getContext().getResources().getDimensionPixelOffset(R.dimen.reg_dimen_48dp));
        LayoutTransition layoutTransition = new LayoutTransition();
        this.setLayoutTransition(layoutTransition);
        TypedArray ta = context.getTheme().obtainStyledAttributes(attrs, R.styleable.ActionViewListStyle, defStyleAttr, defStyleRes);
        int iconResId = ta.getResourceId(R.styleable.ActionViewListStyle_styleIcon, -1);

        LayoutParams layoutParams1 = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        layoutParams1.addRule(CENTER_IN_PARENT, TRUE);

        LayoutParams layoutParams2 = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        layoutParams2.addRule(CENTER_IN_PARENT, TRUE);

        RelativeLayout mParentContainer = new RelativeLayout(getContext());
        LayoutParams layoutParams3 = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        layoutParams3.addRule(CENTER_IN_PARENT, TRUE);
        mParentContainer.setLayoutParams(layoutParams3);

        visibleImageView = new ImageView(getContext());
        if (iconResId != -1)
        {
            visibleImageView.setImageResource(iconResId);
        }
        visibleImageView.setVisibility(View.VISIBLE);
        visibleImageView.setLayoutParams(layoutParams1);

        hiddenImageView = new ImageView(getContext());
        hiddenImageView.setVisibility(View.GONE);
        hiddenImageView.setLayoutParams(layoutParams2);

        mParentContainer.addView(visibleImageView);
        mParentContainer.addView(hiddenImageView);
        this.addView(mParentContainer);

        /*
        int color = Util.getColor(getResources(), R.color.colorPrimary);

        int colorAlpha = Color.alpha(color) >> 1;
        int greenCol = Color.green(color) >> 1;
        int blueCol = Color.blue(color) >> 1;
        int redCol = Color.red(color) >> 1;


        int colorAlpha1 = Color.alpha(color) << 1;
        int greenCol1 = Color.green(color) << 1;
        int blueCol1 = Color.blue(color) << 1;
        int redCol1 = Color.red(color) << 1;*/

        StateListDrawable stateList = new StateListDrawable();
        stateList.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(Color.parseColor("#19000000")));
        stateList.addState(new int[]{}, new ColorDrawable(Util.getColor(getResources(), R.color.colorPrimary)));

        if (Util.atLeast16())
        {
            this.setBackground(stateList);
        }
        else
        {
            //noinspection deprecation
            this.setBackgroundDrawable(stateList);
        }
    }

    /**
     * Method to change icon of this Action View
     *
     * @param newResId icon Resource id
     */
    public void changeIcon(final int newResId)
    {
        if(!isEnabled())
            return;
        mAnimatorSet = new AnimatorSet();
        mAnimatorSet.setDuration(ANIMATION_DURATION);
        if (firstVisible)
        {
            mAnimatorSet.playTogether(ObjectAnimator.ofFloat(visibleImageView, "y", 0, -100), ObjectAnimator.ofFloat(visibleImageView, "alpha", 1, 0, 0), ObjectAnimator.ofFloat(hiddenImageView, "y", 50, 0), ObjectAnimator.ofFloat(hiddenImageView, "alpha", 0, 1, 1));
            mAnimatorSet.addListener(new DefaultAnimationListener()
            {
                @Override
                public void onAnimationEnd(Animator animation)
                {
                    ActionViewListStyle.this.setClickable(true);
                    ActionViewListStyle.this.setEnabled(true);
                    visibleImageView.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationStart(Animator animation)
                {
                    ActionViewListStyle.this.setClickable(false);
                    ActionViewListStyle.this.setEnabled(false);
                    hiddenImageView.setImageResource(newResId);
                    hiddenImageView.setVisibility(View.VISIBLE);
                    firstVisible = false;
                }
            });
        }
        else
        {
            mAnimatorSet.playTogether(ObjectAnimator.ofFloat(hiddenImageView, "y", 0, -100), ObjectAnimator.ofFloat(hiddenImageView, "alpha", 1, 0, 0), ObjectAnimator.ofFloat(visibleImageView, "y", 100, 0), ObjectAnimator.ofFloat(visibleImageView, "alpha", 0, 1, 1));
            mAnimatorSet.addListener(new DefaultAnimationListener()
            {
                @Override
                public void onAnimationEnd(Animator animation)
                {
                    hiddenImageView.setVisibility(View.GONE);
                    ActionViewListStyle.this.setClickable(true);
                    ActionViewListStyle.this.setEnabled(true);
                }

                @Override
                public void onAnimationStart(Animator animation)
                {
                    ActionViewListStyle.this.setClickable(false);
                    ActionViewListStyle.this.setEnabled(false);
                    visibleImageView.setImageResource(newResId);
                    visibleImageView.setVisibility(View.VISIBLE);
                    firstVisible = true;
                }
            });
        }
        mAnimatorSet.start();
    }

    /**
     * Method to check if any previous animation is currently performing
     *
     * @return true if previous animation has not yet stopped, false otherwise
     */
    public boolean isAnimationPerforming()
    {
        return mAnimatorSet != null && mAnimatorSet.isRunning();
    }


    class DefaultAnimationListener implements Animator.AnimatorListener
    {
        @Override
        public void onAnimationStart(Animator animation)
        {
        }

        @Override
        public void onAnimationEnd(Animator animation)
        {
        }

        @Override
        public void onAnimationCancel(Animator animation)
        {
        }

        @Override
        public void onAnimationRepeat(Animator animation)
        {
        }
    }
}
