package com.ob.vmc.vmcproduct.adapter;

import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.List;

/**
 * Created by khyati5403 on 11/4/2016.
 */
public class ProductDetailPagerAdapter extends PagerAdapter {

    private final LayoutInflater inf;

    private List<ProductDetailVo.DataVo.SidesVo> mProductSidesList;
    private int mPColorIndex;


    public ProductDetailPagerAdapter(Activity pActivity, int pProductColorIndex) {
        inf = pActivity.getLayoutInflater();
        mPColorIndex=pProductColorIndex;

    }

    @Override
    public int getCount() {
        return mProductSidesList==null ? 0:mProductSidesList.size();
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout)object);
    }

    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View bannerView = inf.inflate(R.layout.item_product_image, container, false);
        container.addView(bannerView);

        Util.loadImageByFresco((SimpleDraweeView) bannerView.findViewById(R.id.ipi_sdvProductImage), mProductSidesList.get(position).getSideImage().get(mPColorIndex).getProductImage(), null);
        bannerView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

            }
        });
        return bannerView;
    }


    public ProductDetailPagerAdapter setProductSidesList(List<ProductDetailVo.DataVo.SidesVo> mProductSidesList) {
        this.mProductSidesList = mProductSidesList;
        return this;
    }

    public ProductDetailPagerAdapter setPColorIndex(int mPColorIndex) {
        this.mPColorIndex = mPColorIndex;
        return this;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == (RelativeLayout) object;
    }
}
