package com.ob.vmc.vmcproduct.communicator;

import com.ob.vmc.vmcproduct.model.httpmodel.Product;

/**
 * Created by khyati5403 on 10/12/2016.
 */

public interface OnItemClickListener {

    void onItemClick(Product product);
}
