package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.customviews.CircleView;
import com.ob.vmc.vmcproduct.model.appmodel.PmshexcolorVo;

import java.util.List;

import static android.content.ContentValues.TAG;

/**
 * Created by khyati5403 on 12/5/2016.
 */

public class SingleColorAdapter extends RecyclerView.Adapter<SingleColorAdapter.SingleColorViewHolder> {

    private Context pContext;
    private List<PmshexcolorVo> colorList;
    private int pSelectedColor = 0;
    private OnSingleColorClickListener pOnColorClickListener;
    public LayoutInflater inflater;
    private int prevPostion = -1;
    private EffectTypes mEffectTypes;

    public SingleColorAdapter(Context mContext, EffectTypes effectTypes, List<PmshexcolorVo> listColor, int mSelectedColor, OnSingleColorClickListener mOnColorClickListener) {
        this.inflater = LayoutInflater.from(mContext);
        this.pContext = mContext;
        this.colorList = listColor;
        this.pOnColorClickListener = mOnColorClickListener;
        this.mEffectTypes = effectTypes;
    }

    @Override
    public SingleColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new SingleColorViewHolder(inflater.inflate(R.layout.color_list, parent, false));
    }

    public void setListener(OnSingleColorClickListener mListener) {
        this.pOnColorClickListener = mListener;
    }


    @Override
    public void onBindViewHolder(final SingleColorViewHolder holder, final int position) {

        holder.parent.setTag(R.id.tagKey_position, position);
        final String colorCode = colorList.get(position).getHex();
        holder.mCircleView.setFillColor(Color.parseColor("#" + colorCode));
        holder.mCircleView.setStrokeColor(Color.WHITE);

        //Default 0 selection
        if (prevPostion < 0 && position == 0) {
            colorList.get(position).setSelected(true);
//            pOnColorClickListener.onSingleColorClick(colorCode);
        }

        final boolean isSelected = colorList.get(position).isSelected();
        if (isSelected) {
            prevPostion = position;
            CustomLogHandler.printInfo(TAG, "Selected:--" + position);
        }
        holder.mCircleView.setSelected(isSelected);
        holder.mCircleView.invalidate();
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                pOnColorClickListener.onSingleColorClick(colorCode);
//                pOnColorClickListener.onEmbroidaryEffectClick(colorCode);
//                pOnColorClickListener.onToneOnToneEffectClick(colorCode);

                colorList.get(prevPostion).setSelected(false);
                prevPostion = position;
                colorList.get(position).setSelected(true);
                notifyDataSetChanged();

/*                int prevPostion=pSelectedColor;
                pSelectedColor=position;
                notifyItemChanged(prevPostion);
                notifyItemChanged(pSelectedColor);
                holder.mCircleView.setSelected(true);
                holder.mCircleView.notifyView();*/
            }
        });
    }

    @Override
    public int getItemCount() {
        return colorList.size();
    }


    public class SingleColorViewHolder extends RecyclerView.ViewHolder {

        private final View parent;
        private CircleView mCircleView;

        public SingleColorViewHolder(View itemView) {
            super(itemView);
            parent = itemView;
            mCircleView = (CircleView) parent.findViewById(R.id.cl_cvColorList);
        }
    }

    public EffectTypes getmEffectTypes() {
        return mEffectTypes;
    }

    public void setmEffectTypes(EffectTypes mEffectTypes) {
        this.mEffectTypes = mEffectTypes;
    }

    public interface OnSingleColorClickListener {
        void onSingleColorClick(String colorCode);

        void onEmbroidaryEffectClick(String colorCode);

        void onToneOnToneEffectClick(String colorCode);
    }
}
