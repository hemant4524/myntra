package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public  class PmshexcolorVo implements Parcelable {
            /**
             * pms : 7527 C
             * hex : D6D2C4
             */

            @SerializedName("pms")
            private String pms;
            @SerializedName("hex")
            private String hex;

    private boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getPms() {
                return pms;
            }

            public void setPms(String pms) {
                this.pms = pms;
            }

            public String getHex() {
                return hex;
            }

            public void setHex(String hex) {
                this.hex = hex;
            }

    public PmshexcolorVo() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.pms);
        dest.writeString(this.hex);
        dest.writeByte(this.isSelected ? (byte) 1 : (byte) 0);
    }

    protected PmshexcolorVo(Parcel in) {
        this.pms = in.readString();
        this.hex = in.readString();
        this.isSelected = in.readByte() != 0;
    }

    public static final Creator<PmshexcolorVo> CREATOR = new Creator<PmshexcolorVo>() {
        @Override
        public PmshexcolorVo createFromParcel(Parcel source) {
            return new PmshexcolorVo(source);
        }

        @Override
        public PmshexcolorVo[] newArray(int size) {
            return new PmshexcolorVo[size];
        }
    };
}