package com.ob.vmc.vmcproduct.fragment;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

public class EcommerceBaseFragment extends BaseContainerFragment
{
    protected void startActivity(@NonNull Class activityToStart)
    {
        Intent startIntent = new Intent(getActivity(), activityToStart);
        startActivity(startIntent);
    }

    /**
     * Method to replace {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to replace {@link Fragment}
     * @param addToBackStack whether to add transition to back stack or not
     * @param fragToReplace  Fragment to be replaced
     */
    protected void replaceFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToReplace)
    {
        replaceFragment(layoutResId, addToBackStack, fragToReplace, null);
    }

    /**
     * Method to replace {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to replace {@link Fragment}
     * @param addToBackStack whether to add transition to back stack or not
     * @param fragToReplace  Fragment to be replaced
     * @param tag            String TAG to be used in transition and back stack name
     */
    protected void replaceFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToReplace, @Nullable String tag)
    {
        FragmentManager manager = getActivity().getSupportFragmentManager();
        FragmentTransaction transition = manager.beginTransaction();

        if (tag != null)
            transition.replace(layoutResId, fragToReplace, tag);
        else
            transition.replace(layoutResId, fragToReplace, fragToReplace.getClass().getSimpleName());

        if (addToBackStack)
            transition.addToBackStack(tag);
        transition.commit();
    }

    /**
     * Method to remove a fragment which was previously added.
     * @param pFragment Added fragment
     */
    protected void removeFragment(Fragment pFragment)
    {
        if(pFragment == null)
            return;
        FragmentManager manager = getActivity().getSupportFragmentManager();
        FragmentTransaction transition  = manager.beginTransaction();
        transition.remove(pFragment);
        transition.commit();
    }

    /**
     * Method to remove multiple added fragments
     * @param pFragment Array of added fragments
     */
    protected void removeFragment(Fragment[] pFragment)
    {
        if(pFragment == null || pFragment.length == 0)
            return;

        FragmentManager manager = getActivity().getSupportFragmentManager();
        FragmentTransaction transition  = manager.beginTransaction();

        for(Fragment f : pFragment)
        {
            transition.remove(f);
        }

        transition.commit();
    }
}
