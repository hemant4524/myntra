package com.ob.vmc.vmcproduct.communicator;

/**
 * Created by Ishan4452 on 12/1/2015.
 */
public interface RefreshCallBack {

    void onRefreshOnClick();
}
