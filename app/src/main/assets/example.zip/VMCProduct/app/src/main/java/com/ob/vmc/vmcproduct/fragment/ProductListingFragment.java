package com.ob.vmc.vmcproduct.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.andoblib.listener.ProgressOnCancelListener;
import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.activity.ProductDetailActivity;
import com.ob.vmc.vmcproduct.activity.ProductListingActivity;
import com.ob.vmc.vmcproduct.adapter.ProductListAdapter;
import com.ob.vmc.vmcproduct.communicator.OnItemClickListener;
import com.ob.vmc.vmcproduct.constant.AppConstant;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WSValueConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.customcontrol.CategoryDividerItemDecoration;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.httpmodel.Product;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductVo;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.ArrayList;
import java.util.List;

import static com.ob.vmc.vmcproduct.activity.ProductListingActivity.REQUEST_CODE_FILTER_ACTIVITY;

/**
 * Created by khyati5403 on 10/19/2016.
 */
public class ProductListingFragment extends EcommerceBaseFragment implements OnCompleteListener, OnItemClickListener, ProgressOnCancelListener{

    private static final int MAX_LIMIT = 10;
    private RecyclerView rvGetProductList;
    private ProductListAdapter mProductListAdapter;
    List<SuppliersVO.DataVo.SuppliersVo> suppliersVOList;
    private boolean isProductView = true;
    private Context mContext;

    public String mSelectedCategory;
    private boolean mIsLoadMore = true;

    private boolean mIsLoading = false;

//    private boolean mIsData = true;
    private FormHttpCaller mproductListHttpCaller;
    private int startIndex=1;


    public static ProductListingFragment newInstance(Bundle extraArgs) {
        ProductListingFragment instance = new ProductListingFragment();
        if (extraArgs != null) {
            instance.setArguments(extraArgs);
        }
        return instance;
    }

    public static ProductListingFragment newInstance() {
        return newInstance(null);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product_listing, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        View rootView = getView();
        if (rootView == null){
            return;
        }

        rvGetProductList = (RecyclerView) rootView.findViewById(R.id.fpl_rvGetProductList);
        rvGetProductList.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.VERTICAL_LIST,
                Util.getDrawable(getActivity(), R.drawable.list_divider)));

        rvGetProductList.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.HORIZONTAL_VERTICAL_MIDDLE_DIVIDER, Util.getDrawable(getActivity(), R.drawable.list_divider)));
        rvGetProductList.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.HORIZONTAL_VERTICAL_TOP_BOTTOM_END_DIVIDER, Util.getDrawable(getActivity(), R.drawable.list_divider)));
        rvGetProductList.setItemAnimator(new DefaultItemAnimator());
        mIsLoadMore = true;
        final String supplierId= AppSetting.getString(getActivity(), SharePrefConstant.KEY_SUPPLIER_ID,"");


        callSupplierListAPI(supplierId);
    }




    private ProductListingActivity getParentActivity() {
        return (ProductListingActivity) getActivity();
    }

    public void notifyDataSetChange() {
        if (mProductListAdapter != null)
            mProductListAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(Product product) {
        Intent detailIntent = new Intent(getContext(), ProductDetailActivity.class);
        detailIntent.putExtra(ProductDetailActivity.SUPPLIER_ID, product.getSupplierId());
        detailIntent.putExtra(ProductDetailActivity.PRODUCT_NAME, product.getProductTitle());
        detailIntent.putExtra(ProductDetailActivity.PRODUCT_SKU, product.getSku());

        startActivity(detailIntent);
    }

    private void callSupplierListAPI(String id) {
        if (!mIsLoading ){
            mIsLoading=true;
            CommonUtil.showProgressDialog(getActivity(), null, null, false, null, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL, getFragmentManager());

            final String supplierType;

            if (id == AppSetting.getString(getActivity(), SharePrefConstant.KEY_SUPPLIER_ID,"")){
                supplierType= AppSetting.getString(getActivity(), SharePrefConstant.KEY_SUPPLIER_TYPE,"");
            }else {
//                supplierType = suppliersVOList.get(0).getSupplierType();
                supplierType = "Supplier";
            }
            List<NameValuePair> postParams=new ArrayList<>();
            postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID ,id));
            postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_TYPE,supplierType));
//            postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID ,"698"));
//            postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_TYPE,"Supplier"));
            postParams.add(new NameValuePair(WSKeyConstant.KEY_LOCALE, WSValueConstant.EN_US));
            postParams.add(new NameValuePair(WSKeyConstant.KEY_START, startIndex));
            postParams.add(new NameValuePair(WSKeyConstant.KEY_LIMIT, MAX_LIMIT));

            mproductListHttpCaller = new FormHttpCaller(getContext(), WSUrlConstant.productAPIUrl(), APIType.METHOD_GET, postParams, WSRequestCodeConstant.REQUEST_GET_PRODUCT, new ResponseHandler(this));
            mproductListHttpCaller.execute();
        }
    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        mIsLoading=false;
        BaseVo baseVo = (BaseVo) itemObj;
        if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                ProductVo.Data data = ((ProductVo) itemObj).getData();
                if (data != null) {
                    if (requestCode == WSRequestCodeConstant.REQUEST_SUPPLIER) {
                        SuppliersVO suppliersVO = (SuppliersVO) itemObj;
                        List<SuppliersVO.DataVo.SuppliersVo> dataVO = ((SuppliersVO) itemObj).getData().getSuppliers();

                        suppliersVOList = suppliersVO.getData().getSuppliers();

                        List<String> list = new ArrayList<>();
                        for (int i = 0; i < suppliersVOList.size(); i++) {
                            String supplierName = suppliersVOList.get(i).getSupplierName();
                            list.add(supplierName);
                        }

                    } else if (requestCode == WSRequestCodeConstant.REQUEST_GET_PRODUCT) {
                        List<Product> productList;
                        productList = data.getProducts();
                        if (mProductListAdapter==null) {
                            mProductListAdapter = new ProductListAdapter(productList, getContext(), this);
                            setLayoutManager(false);
                            rvGetProductList.setAdapter(mProductListAdapter);
                            showView(mProductListAdapter.getItemCount());
                            setLoadMore();
                        }else
                        {
                            mProductListAdapter.addItem(productList);
                            mProductListAdapter.notifyDataSetChanged();
                        }

                        if (data.count<=mProductListAdapter.getItemCount())
                            mIsLoadMore=false;
                        else
                            startIndex++;
                    }

                } else {
                    mIsLoadMore = false;
                }

        }
    }

    public void setLoadMore() {
        final String supplierId= AppSetting.getString(getActivity(), SharePrefConstant.KEY_SUPPLIER_ID,"");
        rvGetProductList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (recyclerView.getAdapter() == null)
                    return;

                if (recyclerView.getAdapter().getItemCount() == 0)
                    return;

                final RecyclerView pRecyclerView = recyclerView;
                pRecyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        int visibleItemCount = pRecyclerView.getLayoutManager().getChildCount();
                        int totalItemCount = pRecyclerView.getLayoutManager().getItemCount();
                        int pastVisibleItems = ((LinearLayoutManager) pRecyclerView.getLayoutManager()).findFirstVisibleItemPosition();

                        if ((visibleItemCount + pastVisibleItems) >= totalItemCount) {
                            callSupplierListAPI(supplierId);                        }
                    }
                });
            }
        });

    }

    private void setLayoutManager(final boolean isGridStyle) {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        GridLayoutManager mLayoutManager1 = new GridLayoutManager(getActivity(), 2);
     /*   mLayoutManager1.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (isGridStyle) {
                    return 1;
                }else
                 return 2;

            }
        });
*/
        rvGetProductList.setLayoutManager(isGridStyle ? mLayoutManager1 : mLayoutManager);
//        rvGetProductList.setLayoutManager(mLayoutManager1);
    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        CommonUtil.showSimpleDialog(getActivity(), getString(R.string.title_error),((BaseVo) itemObj).getCustomException().getMessage() , "OK", false, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL,null, getFragmentManager());
        mIsLoadMore =false;
    }

    @Override
    public void onError(Object itemObj) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo= (BaseVo) itemObj;
        CommonUtil.showSimpleDialog(getActivity(), getString(R.string.title_error),((BaseVo) itemObj).getCustomException().getMessage() , "OK", false, AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL,null, getFragmentManager());
        mIsLoadMore = false;
    }

    public void changeListingViewStyle() {
        if (mProductListAdapter!=null) {

            int scrollPosition=0;
            // If a layout manager has already been set, get current scroll position.
            if (rvGetProductList.getLayoutManager() != null) {
                scrollPosition = ((LinearLayoutManager) rvGetProductList.getLayoutManager())
                        .findFirstCompletelyVisibleItemPosition();
            }


            boolean listViewStyle = !mProductListAdapter.isGridStyle();
            setLayoutManager(listViewStyle);
            mProductListAdapter.setGridStyle(listViewStyle);

//            showView(mProductListAdapter.getItemCount());
//            rvGetProductList.setAdapter(mProductListAdapter);

//        mProductListAdapter.notifyDataSetChanged();

            rvGetProductList.scrollToPosition(scrollPosition);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_FILTER_ACTIVITY){

            Bundle extra = data.getExtras();
            if (extra == null){
                return;
            }
            mSelectedCategory = extra.getString(ProductListingActivity.EXTRA_FILTER_SELECTED_CATEGORY);

            mIsLoadMore = true;
            callSupplierListAPI(mSelectedCategory);
//            callProductListFromSupplier(mSelectedCategory);
        notifyDataSetChange();
        }
    }

    @Override
    public void onProgressDialogCancelled(int pRequestCode) {
        if (pRequestCode == AppConstant.REQUEST_CODE_SEARCH_PROGRESS_CANCEL) {
            if (mproductListHttpCaller != null) {
                mIsLoading = false;
                mproductListHttpCaller.cancel(true);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Cancel Web-Service call
        if (mproductListHttpCaller != null && mproductListHttpCaller.isTaskRunning()) {
            mproductListHttpCaller.cancel(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Pause Web-Service call
        if (mproductListHttpCaller != null && mproductListHttpCaller.isTaskRunning()) {
            mproductListHttpCaller.cancel(true);
            CommonUtil.dismissProgressDialog();
        }



    }

    public void showView(int count) {
        if (count > 0)
            hideEmptyView();
        else
            showEmptyView();
    }


    private void showEmptyView() {
        View rootView = getView();
        if (rootView == null)
            return;
        rootView.findViewById(R.id.fpl_EmptyView).setVisibility(View.VISIBLE);
        rvGetProductList.setVisibility(View.GONE);
    }

    private void hideEmptyView() {
        View rootView = getView();
        if (rootView == null)
            return;
        rootView.findViewById(R.id.fpl_EmptyView).setVisibility(View.GONE);
        rvGetProductList.setVisibility(View.VISIBLE);
    }


}

