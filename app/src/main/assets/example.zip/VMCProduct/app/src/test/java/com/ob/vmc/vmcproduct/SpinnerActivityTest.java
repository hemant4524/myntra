package com.ob.vmc.vmcproduct;

import android.test.ActivityInstrumentationTestCase2;

import com.ob.vmc.vmcproduct.activity.MainActivity;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import org.junit.Test;

/**
 * Created by khyati5403 on 10/14/2016.
 */

public class SpinnerActivityTest extends ActivityInstrumentationTestCase2<MainActivity> {

    private MainActivity mainAc;
    private SuppliersVO mSuppliersVO;

    public SpinnerActivityTest() {
        super(MainActivity.class);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        mainAc = getActivity();
//        mSuppliersVO = new SuppliersVO();
    }

    @Test
    public void testSupplierNotNull(){
        assertNotNull(mSuppliersVO);
    }

    @Test
    public void testSupplierListNotNull(){
        assertNull(mSuppliersVO.getData().getSuppliers());
    }
}
