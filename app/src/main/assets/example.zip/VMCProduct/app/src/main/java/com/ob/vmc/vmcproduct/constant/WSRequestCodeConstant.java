package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 6/7/2016.
 */

/*List of  Request API Unique ResponseCode*/
public class WSRequestCodeConstant {

    public static final int REQUEST_PRODUCT_SETTING = 1;
    public static final int REQUEST_GUEST_ACCESS_TOKEN=0;

    public static final int REQUEST_SUPPLIER = 2;
    public static final int REQUEST_GET_PRODUCT = 3;
    public static final int REQUEST_POST_LOGIN = 4;
    public static final int REQUEST_GET_PRODUCT_DETAIL = 5;
    public static final int REQUEST_GET_PMS_COLOR = 6;
    public static final int REQUEST_GET_RELATED_PMS_COLOR = 7;
    public static final int REQUEST_POST_VIRTUAL_UPLOAD = 8;
    public static final int REQUEST_GET_SUPPLIER_DETAIL = 9;
}
