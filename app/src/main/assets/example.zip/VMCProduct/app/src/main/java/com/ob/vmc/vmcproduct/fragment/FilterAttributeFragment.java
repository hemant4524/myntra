package com.ob.vmc.vmcproduct.fragment;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.FilterAttributeAdapter;
import com.ob.vmc.vmcproduct.communicator.FilterCommunicator;
import com.ob.vmc.vmcproduct.communicator.OnFilterAttributeClickListener;
import com.ob.vmc.vmcproduct.customcontrol.CategoryDividerItemDecoration;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by khyati5403 on 10/20/2016.
 */
public class FilterAttributeFragment extends Fragment implements OnFilterAttributeClickListener{

    public static final String TAG = FilterAttributeFragment.class.getSimpleName();
    public static final String EXTRA_FILTER_ITEMS_SELECTED = "filterItemsSelected";
    private RecyclerView mRecyclerView;
    private FilterAttributeAdapter mAdapter;
    List<SuppliersVO.DataVo.SuppliersVo> list;
    private FilterCommunicator mFilterCommunicator;
    OnFilterAttributeClickListener  listener;
    private EditText etSearch;
    private String mSelectedCategory;

    public static FilterAttributeFragment newInstance(List<SuppliersVO.DataVo.SuppliersVo> suppliersVOList, Bundle bundle) {
        FilterAttributeFragment attributeFragment = new FilterAttributeFragment();
        attributeFragment.list = suppliersVOList;
        attributeFragment.setArguments(bundle);
        return attributeFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mFilterCommunicator = (FilterCommunicator) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null){
            String selected = getArguments().getString(EXTRA_FILTER_ITEMS_SELECTED, null);
            if (selected != null){
                mSelectedCategory = selected;
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_filter_attribute, container, false);
        mRecyclerView = (RecyclerView)view.findViewById(R.id.ffa_rvFilterAttribute);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
//        mRecyclerView.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.VERTICAL_LIST,
//                Util.getDrawable(getActivity(), R.drawable.divider)));
//        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                super.onDraw(c, parent, state);

            }
        });
        mAdapter = new FilterAttributeAdapter(getActivity(), list, this, mSelectedCategory);
        mRecyclerView.setAdapter(mAdapter);
        etSearch = (EditText)view.findViewById(R.id.ffa_etSearch);
        addSearchSupplierListListener();
        return view;
    }

    private void addSearchSupplierListListener() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                s = s.toString().toLowerCase();

                final List<SuppliersVO.DataVo.SuppliersVo> filteredList = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {

                    final String text = list.get(i).getSupplierName().toLowerCase();
                    if (text.contains(s)) {
                        filteredList.add(list.get(i));
                    }
                }
                mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                mRecyclerView.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.VERTICAL_LIST,
                        Util.getDrawable(getActivity(), R.drawable.divider)));
                mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                mAdapter = new FilterAttributeAdapter(getActivity(), filteredList, FilterAttributeFragment.this , mSelectedCategory);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    @Override
    public void onCommonItemSelect(ArrayList<SuppliersVO.DataVo.SuppliersVo> vo, String selectedPositions) {
        String value;
        value = getCommaSeparatedValues(vo, true);
        mFilterCommunicator.onAttributeClick(value, selectedPositions);

        CustomLogHandler.printInfo(TAG, String.valueOf(vo));
        CustomLogHandler.printInfo(TAG, selectedPositions);

    }

    String getCommaSeparatedValues(ArrayList<SuppliersVO.DataVo.SuppliersVo> vo, boolean fetchId) {
        StringBuilder sb = new StringBuilder();
        boolean isFirst = true;
        for (SuppliersVO.DataVo.SuppliersVo v : vo) {
            if (isFirst)
                isFirst = false;
            else
                sb.append(",");
            sb.append(fetchId ? v.getId() : v.getSupplierName());
        }
        //CustomLogHandler.printVerbose(TAG,"Filter List:-->"+sb.toString());
        return sb.toString();
    }

    public void notifyClear() {
        mAdapter.clearSelectedPos();
        mAdapter.notifyDataSetChanged();
    }
}
