package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 1/9/2017.
 */
public enum AlignmentType {

    LEFT,
    CENTER,
    RIGHT,

}
