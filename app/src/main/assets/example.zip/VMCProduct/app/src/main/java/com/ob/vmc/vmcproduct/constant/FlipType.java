package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 1/4/2017.
 */

public enum FlipType {

    NONE,
    VERTICAL,
    HORIZONTAL,
    VERTICAL_HORIZONTAL,

}
