package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

import java.io.File;
import java.io.IOException;

/**
 * Created by khyati5403 on 3/31/2016.
 */
public class SharpenEffectAsync extends AsyncTask<Void, Void, Bitmap> {

    private Bitmap srcBitmap;
    private Context mContext;
    private SharphenEventResult mSharpenEventResult;
    private String error;
    private Paint mFontPaint;
    private android.graphics.Canvas canvas;
    private Matrix matrix;
    private String  mBitmapPath;
    private double mWeight;

    public SharpenEffectAsync(Context mContext, SharphenEventResult sharphenEffectsAsync, String bitmapPath, double pWeight) {
        this.mContext = mContext;
        this.mSharpenEventResult = sharphenEffectsAsync;
        this.mBitmapPath = bitmapPath;
        this.mWeight =pWeight;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;

        /**
         * Get bitmap from URI
         */
        try {
            Uri uri=Uri.fromFile(new File(mBitmapPath));
            srcBitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
            bitmap = BitmapProcessing.sharpen(srcBitmap, mWeight);
//            bitmap = BitmapProcessing.cfilter(srcBitmap,50,100,150);
//            bitmap = BitmapProcessing.cdepth(srcBitmap,128);
//            bitmap = BitmapProcessing.noise(srcBitmap);
//            bitmap = BitmapProcessing.brightness(srcBitmap,150);
//            bitmap = BitmapProcessing.contrast(srcBitmap,80);
//            bitmap = BitmapProcessing.sepia(srcBitmap);
//            bitmap = BitmapProcessing.gamma(srcBitmap, 10, 20, 30);
//            bitmap = BitmapProcessing.saturation(srcBitmap,80);
//            bitmap = BitmapProcessing.grayscale(srcBitmap);
//            bitmap = BitmapProcessing.vignette(srcBitmap);
//            bitmap = BitmapProcessing.hue(srcBitmap,270);
//            bitmap = BitmapProcessing.tint(srcBitmap, Color.TRANSPARENT);
//            bitmap = BitmapProcessing.invert(srcBitmap);
//            bitmap = BitmapProcessing.boost(srcBitmap,2,120);
//            bitmap = BitmapProcessing.sketch(srcBitmap);
//            mUri = Uri.fromFile(FileUtils.saveBitmap(bitmap, mContext));
//            mUri = Uri.fromFile((new File(FileUtils.saveBitmapToLocal(bitmap, mContext))));

        } catch (IOException e) {
            error = e.getMessage();
            e.printStackTrace();
        }


        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mSharpenEventResult.onSharpenEventComplete(bitmap);
        } else {
            mSharpenEventResult.onSharpenEventFail(error);
        }
    }

    public interface SharphenEventResult {
        void onSharpenEventComplete(Bitmap bitmap);

        void onSharpenEventFail(String exceptionMsg);
    }


}