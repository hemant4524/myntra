package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.List;

/**
 * Created by khyati5403 on 11/2/2016.
 */

public class ProductDetailColorAdapter extends RecyclerView.Adapter<ProductDetailColorAdapter.ProductDetailColorViewHolder> {


    private List<ProductDetailVo.DataVo.SidesVo.SideImageVo> productSideList;
    private final Context mContext;
    public LayoutInflater inflater;
    public onColorClick onColorClick;
    private int mColorIndex = 0;
    private int mSelected;

    public ProductDetailColorAdapter(Context context,  int pSideIndex , onColorClick colorClick) {

        this.inflater = LayoutInflater.from(context);
        this.mContext = context;
        this.onColorClick = colorClick;
        this.mColorIndex = pSideIndex;

    }

    @Override
    public ProductDetailColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ProductDetailColorViewHolder(inflater.inflate(R.layout.item_prosuct_color, parent, false));
    }

    public void setColorIndex(int mSideIndex) {
        this.mColorIndex = mSideIndex;
    }


    /*
    public void setSelectedItem(int position) {

        final int mPreviousSelected = mColorIndex;
        mColorIndex = position;
        if (mPreviousSelected != -1)
            notifyItemChanged(mPreviousSelected);
        notifyItemChanged(mColorIndex);

    }*/


    public ProductDetailColorAdapter setProductSideList(List<ProductDetailVo.DataVo.SidesVo.SideImageVo> productSideList) {
        this.productSideList = productSideList;
        return this;
    }


    public ProductDetailColorAdapter setSelected(int pSelected) {
        this.mSelected = pSelected;
        return this;
    }

    @Override
    public void onBindViewHolder(final ProductDetailColorViewHolder holder, final int position) {

        holder.parent.setTag(R.id.tagKey_position, position);
        ProductDetailVo.DataVo.SidesVo.SideImageVo sideImageVo= productSideList.get(position);
        Util.loadImageByFresco(holder.colorProductImage, sideImageVo.getThumbImage(), null);

        holder.colorProductImage.setSelected(mColorIndex == position);

        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selected = (int) v.getTag(R.id.tagKey_position);
                onColorClick.onItemColorSelect(selected);
                int prevPostion=mColorIndex;
                mColorIndex=position;
                notifyItemChanged(prevPostion);
                notifyItemChanged(mColorIndex);
            }
        });
    }

    @Override
    public int getItemCount() {

        return productSideList==null ?0:productSideList.size();
    }

    public class ProductDetailColorViewHolder extends RecyclerView.ViewHolder{

        private SimpleDraweeView colorProductImage;
        View parent;
        public ProductDetailColorViewHolder(View itemView) {
            super(itemView);
            parent = itemView;
            colorProductImage = (SimpleDraweeView) parent.findViewById(R.id.ipc_sdProductColorItem);
        }

    }

    public interface onColorClick{
        void onItemColorSelect(int position);
    }
}
