package com.ob.vmc.vmcproduct.model.httpmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Ishan4452 on 11/22/2016.
 */

public class PointVo implements Parcelable {
    /**
     * x : 178.00000042724608
     * y : 233.00000012207028
     */

    @SerializedName("x")
    private String x;
    @SerializedName("y")
    private String y;

    public Float getX() {
        return Float.parseFloat(x);
    }

    public void setX(String x) {
        this.x = x;
    }

    public Float getY() {
        return Float.parseFloat(y);
    }

    public void setY(String y) {
        this.y = y;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.x);
        dest.writeString(this.y);
    }

    public PointVo() {
    }

    protected PointVo(Parcel in) {
        this.x = in.readString();
        this.y = in.readString();
    }

    public static final Parcelable.Creator<PointVo> CREATOR = new Parcelable.Creator<PointVo>() {
        @Override
        public PointVo createFromParcel(Parcel source) {
            return new PointVo(source);
        }

        @Override
        public PointVo[] newArray(int size) {
            return new PointVo[size];
        }
    };
}
