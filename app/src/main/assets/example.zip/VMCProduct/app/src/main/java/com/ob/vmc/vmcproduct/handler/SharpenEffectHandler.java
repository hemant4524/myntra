package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/2/2016.
 */

public class SharpenEffectHandler {

    private Context mContext;

    public SharpenEffectHandler(Context pContext) {
        mContext=pContext;
    }

    public Bitmap executeProcess(Bitmap srcBitmap, double pWeight) {
//        new SharpenEffectAsync(mContext, mSharpenEventResult, mBitmapPath, pWeight).execute();


        try {
            srcBitmap = BitmapProcessing.sharpen(srcBitmap, pWeight);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return srcBitmap;

    }
}
