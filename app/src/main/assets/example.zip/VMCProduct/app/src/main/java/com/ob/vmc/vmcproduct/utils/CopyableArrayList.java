package com.ob.vmc.vmcproduct.utils;

import android.support.annotation.NonNull;

import com.ob.ecommercelibrary.utils.Copyable;

import java.util.ArrayList;
import java.util.Collection;

public class CopyableArrayList<Type> extends ArrayList<Type>
{
    public CopyableArrayList()
    {
        super();
    }

    public CopyableArrayList(Collection<? extends Type> collection)
    {
        super(collection);
    }

    public
    @NonNull
    CopyableArrayList<Type> copy()
    {
        CopyableArrayList<Type> list = new CopyableArrayList<>();
        for (Type item : this)
        {
            try
            {
                //noinspection unchecked
                Copyable<Type> copy = (Copyable<Type>) item;
                item = copy.copy();
            }
            catch (ClassCastException ignore){}
            list.add(item);
        }
        return list;
    }
}
