package com.ob.vmc.vmcproduct.activity;

import android.app.Instrumentation;
import android.test.ActivityInstrumentationTestCase2;
import android.test.ViewAsserts;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import org.junit.After;
import org.junit.Test;

/**
 * Created by khyati5403 on 10/14/2016.
 */
public class MainActivityLocalTest extends ActivityInstrumentationTestCase2<MainActivity> {
    private Spinner sp_Supplier;
    private SuppliersVO mSuppliersVO;
    private ArrayAdapter<String> dataAdapter;

    private MainActivity mainActivity;
    public static final int TEST_POSITION = 5;
    public static final int ADAPTER_COUNT = 9;

    private String mSelection;
    private int mPos;
    private Instrumentation mInstrumentation;

    public MainActivityLocalTest() {
        super("com.ob.vmc.vmcproduct.activity", MainActivity.class);
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        try{
            setActivityInitialTouchMode(false);
            mInstrumentation = getInstrumentation();
            mainActivity = getActivity();
//            mSuppliersVO = new SuppliersVO();
            sp_Supplier = (Spinner) mainActivity.findViewById(R.id.cm_spSupplierList);
            dataAdapter = (ArrayAdapter<String>) sp_Supplier.getAdapter();

        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Test
    public void testSupplierNotNull(){
        assertNotNull(mSuppliersVO);
    }


    @Test
    public void testLoadData(){
        View view =  mainActivity.getWindow().getDecorView();
        ViewAsserts.assertOnScreen(view, sp_Supplier);

    }

    @Test
    public void testSupplierListNotNull(){
        assertNull(mSuppliersVO.getSuppliers());
    }

    @Test
    public void testSpinnerUI(){

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                sp_Supplier.requestFocus();
                sp_Supplier.setSelection(AdapterView.INVALID_POSITION);
            }
        });

        this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);
        for (int i=1; i < TEST_POSITION; i++){
            this.sendKeys(KeyEvent.KEYCODE_DPAD_DOWN);
        }
        this.sendKeys(KeyEvent.KEYCODE_DPAD_CENTER);

        mPos = sp_Supplier.getSelectedItemPosition();
        mSelection = (String)sp_Supplier.getItemAtPosition(mPos);

        TextView resultView =
                (TextView) mainActivity.findViewById(
                        R.id.af_tvClearAll
                );

        String resultText = (String) resultView.getText();

        assertEquals(resultText,mSelection);
    }

    public void testPreConditions() {
        assertTrue(sp_Supplier.getOnItemSelectedListener() != null);
        assertTrue(dataAdapter != null);
        assertEquals(dataAdapter.getCount(),ADAPTER_COUNT);
    }

    @After
    public void tearDown() throws Exception {

        super.tearDown();
    }

}