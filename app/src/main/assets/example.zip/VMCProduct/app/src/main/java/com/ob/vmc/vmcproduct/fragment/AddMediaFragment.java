package com.ob.vmc.vmcproduct.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ob.vmc.vmcproduct.R;

/**
 * Created by Ishan4452 on 11/25/2016.
 */

public class AddMediaFragment extends Fragment {


    public static final int ACTION_FROM_CAMERA = 0;
    public static final int ACTION_FROM_GALLERY = 1;
    private OnAddMediaActionListner mOnImageActionFromListner;

    public static AddMediaFragment newInstance() {

        Bundle args = new Bundle();

        AddMediaFragment fragment = new AddMediaFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return  inflater.inflate(R.layout.fragment_add_media,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        view.findViewById(R.id.fam_tvCamera).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnImageActionFromListner!=null)
                mOnImageActionFromListner.onAddMediaAction(ACTION_FROM_CAMERA);
            }
        });

        view.findViewById(R.id.fam_tvGallery).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnImageActionFromListner!=null) {
                    mOnImageActionFromListner.onAddMediaAction(ACTION_FROM_GALLERY);
                }

            }
        });


    }

    public void setOnImageActionFromListner(OnAddMediaActionListner mOnImageActionFromListner) {
        this.mOnImageActionFromListner = mOnImageActionFromListner;
    }

    public interface OnAddMediaActionListner {
    void onAddMediaAction(int actionCode);
    }



}
