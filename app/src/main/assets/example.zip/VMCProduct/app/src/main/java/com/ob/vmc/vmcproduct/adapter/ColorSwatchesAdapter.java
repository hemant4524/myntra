package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.customviews.CircleView;
import com.ob.vmc.vmcproduct.model.appmodel.PmshexcolorVo;

import java.util.List;

import static android.content.ContentValues.TAG;

/**
 * Created by khyati5403 on 12/9/2016.
 */

public class ColorSwatchesAdapter extends RecyclerView.Adapter<ColorSwatchesAdapter.ColorViewHolder> {

    private Context pContext;
    private List<PmshexcolorVo> colorList;

    private onColorSwatchesListener pOnColorClickListener;
    public LayoutInflater inflater;
    private int prevPostion = -1;
    private EffectTypes mEffectTypes;

    public ColorSwatchesAdapter(Context mContext, EffectTypes types, List<PmshexcolorVo> listColor, int mSelectedColor, onColorSwatchesListener mOnColorClickListener) {
        this.inflater = LayoutInflater.from(mContext);
        this.pContext = mContext;
        this.colorList = listColor;
        this.pOnColorClickListener = mOnColorClickListener;
        this.mEffectTypes = types;
    }


    @Override
    public ColorSwatchesAdapter.ColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ColorSwatchesAdapter.ColorViewHolder(inflater.inflate(R.layout.color_list, parent, false));
    }

    @Override
    public void onBindViewHolder(final ColorSwatchesAdapter.ColorViewHolder holder, final int position) {

        holder.parent.setTag(R.id.tagKey_position, position);
        final String colorCode = "#" + colorList.get(position).getHex();
        holder.mCircleView.setFillColor(Color.parseColor(colorCode));
        holder.mCircleView.setStrokeColor(Color.WHITE);

        //Default 0 selection
        if (prevPostion < 0 && position == 0) {
            colorList.get(position).setSelected(true);
            pOnColorClickListener.onColorSwatchesClick(colorCode, mEffectTypes);
        }


        final boolean isSelected = colorList.get(position).isSelected();
        if (isSelected) {
            prevPostion = position;
            CustomLogHandler.printInfo(TAG, "Selected:--" + position);
        }
        holder.mCircleView.setSelected(isSelected);

        holder.mCircleView.invalidate();
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pOnColorClickListener.onColorSwatchesClick(colorCode, mEffectTypes);

                colorList.get(prevPostion).setSelected(false);
                prevPostion = position;
                colorList.get(position).setSelected(true);
//                notifyItemChanged(prevPostion);
//                notifyItemChanged(position);
                notifyDataSetChanged();
//                setSelectedItem(selected);

            }
        });
    }


    @Override
    public int getItemCount() {
        return colorList.size();
    }

    public class ColorViewHolder extends RecyclerView.ViewHolder {

        private final View parent;
        private CircleView mCircleView;

        public ColorViewHolder(View itemView) {
            super(itemView);
            parent = itemView;
            mCircleView = (CircleView) parent.findViewById(R.id.cl_cvColorList);
        }
    }

    public interface onColorSwatchesListener {
        void onColorSwatchesClick(String colorCode, EffectTypes effectTypes);
    }
}

