package com.ob.vmc.vmcproduct.customviews;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build;
import android.support.v4.view.MotionEventCompat;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.widget.ImageView;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.AlignmentType;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;
import com.ob.vmc.vmcproduct.model.appmodel.BubblePropertyModel;
import com.ob.vmc.vmcproduct.model.appmodel.BubbleTextVo;

/**
 * Created by Abner on 15/6/7.
 * QQ 230877476
 * Email nimengbo@gmail.com
 */
public class BubbleTextView extends ImageView {
    private static final String TAG = "BubbleTextView";
    private static final float BITMAP_SCALE = 1f;
    //Finger moving distance must exceed this value
    private final float pointerLimitDis = 20f;
    private final float pointerZoomCoeff = 0.09f;
    private final float moveLimitDis = 0.5f;
    /**
     * Text Of
     */
    private final String defaultStr;
    //Font size Default 16sp
    private final float mDefultSize = 22;
    //Maximum and minimum size
    private final float mMaxFontSize = 60;
    private final float mMinFontSize = 8;
    //Distance from the next word
    private final float mDefaultMargin = 20;
    private final long bubbleId;
    private final long doubleClickTimeLimit = 200;
    boolean isInit = true;
    int mTextWidth, mTextHeight; // Our calculated text bounds
    private Bitmap topBitmap;
    private Bitmap resizeBitmap;
    private Bitmap mBitmap;
    private Bitmap originBitmap;
    private Rect dst_delete; //dst_top
    private Rect dst_resize;
    private Rect dst_flipV;
    private Rect dst_top; //dst_delete
    private int deleteBitmapWidth;
    private int deleteBitmapHeight;
    private int resizeBitmapWidth;
    private int resizeBitmapHeight;
    private int flipVBitmapWidth;
    private int flipVBitmapHeight;
    //Sticky
    private int topBitmapWidth;
    private int topBitmapHeight;
    private Paint localPaint;
    private int mScreenwidth, mScreenHeight;
    private PointF mid = new PointF();
    private OperationListener operationListener;
    private float lastRotateDegree;
    //Is the second finger down
    private boolean isPointerDown = false;
    /**
     * The length of the diagonal
     */
    private float lastLength;
    private boolean isInResize = false;
    private Matrix matrix = new Matrix();
    /**
     * Whether the four lines inside
     */
    private boolean isInSide;
    private float lastX, lastY;
    /**
     * Is in edit mode
     */
    private boolean isInEdit = true;
    private float MIN_SCALE = 0.5f;
    private float MAX_SCALE = 1.5f;
    private double halfDiagonalLength;
    private float oringinWidth = 0;
    private DisplayMetrics dm;
    //String displayed
    private String mStr = "";
    private float mMargin = 20;
    //Draw Text brush
    private TextPaint mFontPaint;
    //    private Canvas canvasText;
    private Paint.FontMetrics fm;
    //Since the system is based on the bottom of the font to draw text, plus all the required height of the font.
    private float baseline;
    //Pinch to zoom when the initial distance
    private float oldDis;
    //Are Mobile
    private boolean isMove = false;
    private int fontColor;
    private Path mArc;
    private float TEXT_PADDING = 0;
    private EffectTypes mEffectType;
    private int opa = 255;
    private boolean mIsProductpreview;
    private EmbossMaskFilter emboss_filter, deboss_filter;
    private int pRadius;
    private Context mContext;
    private BubbleTextVo mFontVo;
    private long preClicktime;


    public BubbleTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = Color.BLACK;
        bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context) {
        super(context);
        mContext = context;
        defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = Color.BLACK;
        bubbleId = 0;
        init();
    }

    public BubbleTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = Color.BLACK;
        bubbleId = 0;
        init();
    }

    /**
     * @param context
     * @param fontColor
     * @param bubbleId  some fuck id
     */
    public BubbleTextView(Context context, int fontColor, long bubbleId) {
        super(context);
        mContext = context;
        defaultStr = getContext().getString(R.string.double_click_input_text);
        this.fontColor = fontColor;
        this.bubbleId = bubbleId;
        init();
    }

    //Find Longest String
    public static String getLongestString(String[] array) {
        int maxLength = 0;
        String longestString = null;
        for (String s : array) {
            if (s.length() > maxLength) {
                maxLength = s.length();
                longestString = s;
            }
        }
        return longestString;
    }

    //Multiline text Wrap
    public static void drawTextAndBreakLine(final Canvas canvas, final Paint paint,
                                            final float x, final float y, final float maxWidth, final String text) {
        String textToDisplay = text;
        //String tempText = "";
        char[] chars;
        float textHeight = paint.descent() - paint.ascent();
        float lastY = y;
        int nextPos = 0;
        int lengthBeforeBreak = textToDisplay.length();
        do {
            for (String tempText : text.split("\n")) {
                if (TextUtils.isEmpty(text)) {
                    continue;
                }
                lengthBeforeBreak = textToDisplay.length();
                chars = textToDisplay.toCharArray();
                nextPos = paint.breakText(chars, 0, chars.length, maxWidth, null);
                tempText = textToDisplay.substring(0, nextPos);
                textToDisplay = textToDisplay.substring(nextPos, textToDisplay.length());
                canvas.drawText(tempText, x, lastY, paint);
                lastY += textHeight;
            }
        } while (nextPos < lengthBeforeBreak);
    }

    public BubbleTextVo getmFontVo() {
        return mFontVo;
    }

    private void init() {
        mFontVo = new BubbleTextVo();
        dm = getResources().getDisplayMetrics();
        dst_delete = new Rect();
        dst_resize = new Rect();
        dst_flipV = new Rect();
        dst_top = new Rect();
        localPaint = new Paint();
//        localPaint.setColor(getResources().getColor(R.color.red_e73a3d));
        localPaint.setAntiAlias(true);
        localPaint.setDither(true);
        localPaint.setStyle(Paint.Style.STROKE);
        localPaint.setStrokeWidth(2.0f);
        mScreenwidth = dm.widthPixels;
        mScreenHeight = dm.heightPixels;

        String defaultFontTypePath = "fonts/AbrilFatface-Regular.otf";

        mFontPaint = new TextPaint();
        mFontPaint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, mDefultSize, dm));
        mFontPaint.setTypeface(Typeface.createFromAsset(getContext().getAssets(), defaultFontTypePath));
        mFontPaint.setColor(fontColor);
        mFontPaint.setTextAlign(Paint.Align.CENTER);
        mFontPaint.setAntiAlias(true);

        mArc = new Path();


        emboss_filter = new EmbossMaskFilter(new float[]{1f, 1f, 1f}, // direction of the light source
                0.5f, // ambient light between 0 to 1
                0.5f, // specular highlights
                2.7f // blur before applying lighting
        );
        deboss_filter = new EmbossMaskFilter(new float[]{0f, -1f, 0.5f}, 0.8f, 15f, 1f);


        mFontVo.setFontSize(mDefultSize);
        mFontVo.setFontTypeName(defaultFontTypePath);
        mFontVo.setOpacity(255);

//        initBitmaps();

    }

    public TextPaint getmFontPaint() {
        return mFontPaint;
    }

    public Paint.FontMetrics getFontMatrics() {
        return fm;
    }

    //For Matrix
/*    will probably be what you are looking for. the values given will be as followed:

    0 : Scale X

    1 : Skew X

    2 : Translate X

    3 : Scale Y

    4 : Skew Y

    5 : Translate Y

    6 : Perspective 0

    7 : Perspective 1

    8 : Perspective 2*/
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onDraw(Canvas canvas) {

        if (mBitmap != null) {

            float[] arrayOfFloat = new float[9];
            matrix.getValues(arrayOfFloat);
            float f1 = 0.0F * arrayOfFloat[0] + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
            float f2 = 0.0F * arrayOfFloat[3] + 0.0F * arrayOfFloat[4] + arrayOfFloat[5];
            float f3 = arrayOfFloat[0] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
            float f4 = arrayOfFloat[3] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[4] + arrayOfFloat[5];
            float f5 = 0.0F * arrayOfFloat[0] + arrayOfFloat[1] * this.mBitmap.getHeight() + arrayOfFloat[2];
            float f6 = 0.0F * arrayOfFloat[3] + arrayOfFloat[4] * this.mBitmap.getHeight() + arrayOfFloat[5];
            float f7 = arrayOfFloat[0] * this.mBitmap.getWidth() + arrayOfFloat[1] * this.mBitmap.getHeight() + arrayOfFloat[2];
            float f8 = arrayOfFloat[3] * this.mBitmap.getWidth() + arrayOfFloat[4] * this.mBitmap.getHeight() + arrayOfFloat[5];
            canvas.save();
            //First to the text on the drawing
//            mBitmap = originBitmap.copy(Bitmap.Config.ARGB_8888, true);
//            canvas.setBitmap(mBitmap);

//            canvasText.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
//            canvas.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
            float left = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 15, dm);
            float scalex = arrayOfFloat[Matrix.MSCALE_X];
            float skewy = arrayOfFloat[Matrix.MSKEW_Y];
            float rScale = (float) Math.sqrt(scalex * scalex + skewy * skewy);
            float rAngle = Math.round(Math.atan2(arrayOfFloat[Matrix.MSKEW_X], arrayOfFloat[Matrix.MSCALE_X]) * (180 / Math.PI));
            float yAngle = Math.round(Math.atan2(arrayOfFloat[Matrix.MSKEW_Y], arrayOfFloat[Matrix.MSCALE_Y]) * (180 / Math.PI));

            /*mEffectType = mFontVo.getEffectType();

            if (mEffectType==EffectTypes.EMBOSS) {
                mFontPaint.setColor(Color.GRAY);
                mFontPaint.setMaskFilter(emboss_filter);
                canvas.drawBitmap(mBitmap, matrix, mFontPaint);
            } else if (mEffectType==EffectTypes.DEBOSS) {
                mFontPaint.setColor(Color.GRAY);
                mFontPaint.setMaskFilter(deboss_filter);
                canvas.drawBitmap(mBitmap, matrix, mFontPaint);

            } else {
                mFontPaint.setMaskFilter(null);

                if (mEffectType==EffectTypes.SINGLE_COLOR) {
                    mFontPaint.setColor(mFontVo.getSingleColorCode());
                } else {
                    int mFontColor = mFontVo.getFontColorCode();
                    mFontPaint.setColor(mFontColor);
                }
            }*/

//            float top = calculateTopX(canvasText, mStr);

  /*          for (String text : mStr.split("\n")) {

                if (TextUtils.isEmpty(text)) {
                    continue;
                }
                // canvasText.drawText(text, canvasText.getWidth()/2,top,mFontPaint);  //In the upper left corner as the origin coordinate control
                int xPos = (canvasText.getWidth() / 2);
                pRadius = mFontVo.getCurveDegree();
                if (pRadius != 0) {
//                    canvasText.drawTextOnPath(mStr, mArc, 0, 20, mFontPaint); //Curved Text

                    int offsetX = 0;
                    int offsetY = 0;

                    int x = offsetX;
                    int y = offsetY;
                    String t;
                    float kerning = 1.0f;
                    float scale = 1.0f;
                    float kerningValue;
                    int textOffsetX = x;
                    int textOffsetY = y;
                    float innerOffsetX = 0.0f;
                    float innerOffsetY = 0.0f;
                    float totalWidth = ((float) canvasText.getWidth()) * scale;

                    int startAngle;
                    t = mStr.replace("\n", " ");
                    int aCurvingAngle = pRadius + 6;
                    if (pRadius >= 360) {
                        aCurvingAngle = 359;
                    } else if (pRadius <= -360) {
                        aCurvingAngle = -359;
                    }
                    kerningValue = 0.0f;
                    if (kerning != 0.0f) {
                        kerningValue = ((kerning * 20.0f) * scale) / ((float) (t.length() - 1));
                    }
                    float hOffset = 0.0f;
                    float lineWidth = mFontPaint.measureText(t) + (((float) (t.length() - 1)) * kerningValue);
                    if (mFontPaint.getStrokeWidth() > 0.0f) {
                        lineWidth += mFontPaint.getStrokeWidth() * 2.0f;
                        hOffset = 0.0f + mFontPaint.getStrokeWidth();
                    }
                    float diameter = (float) (((double) ((360.0f * lineWidth) / ((float) Math.abs(aCurvingAngle)))) / Math.PI);
                    textOffsetX = offsetX;
                    textOffsetY = offsetY;

                    int baseWidth = 1;
                    int baseHeight = 1;

                    innerOffsetX = (((float) (canvasText.getWidth() - baseWidth)) * 0.5f) * scale;
                    innerOffsetY = (((float) (canvasText.getHeight() - baseHeight)) * 0.5f) * scale;

                    textOffsetX += (int) innerOffsetX;
                    textOffsetY += (int) innerOffsetY;

                    float left1 = ((float) textOffsetX) + (((totalWidth - (2.0f * innerOffsetX)) - diameter) / 2.0f);
                    float top1 = (float) textOffsetY;
                    //    aCurvingAngle = aCurvingAngle * (-1); // Reverse curve
                    if (aCurvingAngle > 0) {
                        startAngle = 270;
                    } else {
                        top1 += (((((float) canvasText.getHeight()) * scale) - (2.0f * innerOffsetY)) - diameter) - 10;
                        if (mFontPaint.getStrokeWidth() > 0.0f) {
                            top1 -= mFontPaint.getStrokeWidth();
                        }
                        startAngle = 90;
                    }
                    mArc.reset();
                    RectF rectf = new RectF(left1, top1, left1 + diameter, top1 + diameter);
                    mArc.addArc(rectf, (float) (startAngle - (aCurvingAngle / 2)), (float) aCurvingAngle);
                    canvasText.drawTextOnPath(t, mArc, hOffset, 0.0f, mFontPaint);
                } else {
                    canvasText.drawText(text, xPos, top + 5, mFontPaint);
                    top += baseline - fm.leading; //Add font line spacing
                }
            }

            opa = mFontVo.getOpacity();
            adjustOpacity(mBitmap, opa);


            if (mEffectType == EffectTypes.ENGRAVE) {
                mBitmap = BitmapProcessing.doEngrave(mBitmap);
            }

            if (mEffectType == EffectTypes.SATIN_EACH) {
                mBitmap = BitmapProcessing.doSatinEach(mBitmap);
            }
            if (mEffectType == EffectTypes.WOODEN) {
                Bitmap mask = BitmapFactory.decodeResource(getResources(), R.drawable.wooden_mask);
                mBitmap = BitmapProcessing.woodenEffect(mBitmap, mask);
            }
            if (mEffectType == EffectTypes.WOODEN) {
                Bitmap mask = BitmapFactory.decodeResource(getResources(), R.drawable.texture1);
                int embroidaryColor = mFontVo.getEmbroideryColorCode();
                mBitmap = BitmapProcessing.embroideryEffect(embroidaryColor, mBitmap, mask);
            }
            FlipType flipType = mFontVo.getFlipType();
            if (flipType == FlipType.VERTICAL || flipType == FlipType.VERTICAL_HORIZONTAL) {
                mBitmap = BitmapProcessing.flip(mBitmap, false, true);
            }
            if (flipType == FlipType.HORIZONTAL || flipType == FlipType.VERTICAL_HORIZONTAL) {
                mBitmap = BitmapProcessing.flip(mBitmap, true, false);
            }
*/

            Paint paint = new Paint();
            paint.setAlpha(opa);
            canvas.drawBitmap(mBitmap, matrix, paint);
            //Remove the upper right corner
            /*dst_delete.left = (int) (f3 - deleteBitmapWidth / 2);
            dst_delete.right = (int) (f3 + deleteBitmapWidth / 2);
            dst_delete.top = (int) (f4 - deleteBitmapHeight / 2);
            dst_delete.bottom = (int) (f4 + deleteBitmapHeight / 2);*/

            /*dst_delete.left = (int) (f3 - deleteBitmapWidth / 2);
            dst_delete.right = (int) (f3 + deleteBitmapWidth / 2);
            dst_delete.top = (int) (f4 - deleteBitmapHeight / 2);
            dst_delete.bottom = (int) (f4 + deleteBitmapHeight / 2);*/
            //Stretching and other operations in the lower right corner
            dst_resize.left = (int) (f7 - resizeBitmapWidth / 2);
            dst_resize.right = (int) (f7 + resizeBitmapWidth / 2);
            dst_resize.top = (int) (f8 - resizeBitmapHeight / 2);
            dst_resize.bottom = (int) (f8 + resizeBitmapHeight / 2);
            //Top in the upper left corner
            dst_delete.left = (int) (f1 - topBitmapWidth / 2);
            dst_delete.right = (int) (f1 + topBitmapWidth / 2);
            dst_delete.top = (int) (f2 - topBitmapHeight / 2);
            dst_delete.bottom = (int) (f2 + topBitmapHeight / 2);

            /*dst_top.left = (int) (f1 - topBitmapWidth / 2);
            dst_top.right = (int) (f1 + topBitmapWidth / 2);
            dst_top.top = (int) (f2 - topBitmapHeight / 2);
            dst_top.bottom = (int) (f2 + topBitmapHeight / 2);*/
            //Horizontal mirror image in the lower right corner
//          dst_flipV.left = (int) (f5 - topBitmapWidth / 2);
//          dst_flipV.right = (int) (f5 + topBitmapWidth / 2);
//          dst_flipV.top = (int) (f6 - topBitmapHeight / 2);
//          dst_flipV.bottom = (int) (f6 + topBitmapHeight / 2);
            if (isInEdit && resizeBitmap!=null && topBitmap!=null) {
                canvas.drawLine(f1, f2, f3, f4, localPaint);
                canvas.drawLine(f3, f4, f7, f8, localPaint);
                canvas.drawLine(f5, f6, f7, f8, localPaint);
                canvas.drawLine(f5, f6, f1, f2, localPaint);
//                canvas.drawBitmap(deleteBitmap, null, dst_delete, null);
                canvas.drawBitmap(resizeBitmap, null, dst_resize, null);
//              canvas.drawBitmap(flipVBitmap, null, dst_flipV, null);
                canvas.drawBitmap(topBitmap, null, dst_delete, null);
            }
            canvas.restore();
        }
    }

    public float calculateTopX(int pHeight, String pText) {

        float top = pHeight / 2;

        //Based on the bottom line began to draw
        float lineCount = (pText.split("\n").length) / 2;
        top -= (baseline - fm.leading) * lineCount;
        return top;
    }

    public long getBubbleId() {
        return bubbleId;
    }

    public Paint getTestPaint() {
        return mFontPaint;
    }

    public void setText(String text, int width, int height) {
        mStr = text;
        mFontVo.setLabelText(text);
        setBubbleWidthHeight(width, height);
//        setBitmap();
    }
/*
    public void setBitmap(float x, float y) {
        *//*originBitmap = bitmap;
        originBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight()/2, Bitmap.Config.ARGB_8888);*//*

        float fontSize = mFontVo.getFontSize();

        final TextView textView = new TextView(getContext());
        Rect bounds = new Rect();
        Paint textPaint = textView.getPaint();
        textPaint.getTextBounds(mStr, 0, mStr.length(), bounds);
        int padding = 15;
        float width;
        String[] str = mStr.split("\n");
        String longestString = getLongestString(str);
        width = mFontPaint.measureText(longestString, 0, longestString.length());
        float height = (str.length * fontSize);
        originBitmap = Bitmap.createBitmap((int) width, (int) (DensityUtils.dip2px(getContext(), height + padding)), Bitmap.Config.ARGB_8888);
        mBitmap = originBitmap.copy(Bitmap.Config.ARGB_8888, true);
        canvasText = new Canvas(mBitmap);
        setDiagonalLength();
        initBitmaps();
        int w = mBitmap.getWidth();
        int h = mBitmap.getHeight();
        oringinWidth = w;
        //Y coordinates (Figure top action bar + square) / 2

//        matrix.postTranslate(mScreenwidth / 2 - w / 2,mScreenwidth / 2 - h / 2);
//        matrix.postTranslate(mScreenwidth / 2, mScreenwidth / 2);
        matrix.postTranslate(x, y);
        invalidate();
    }*/

    public void setBubbleWidthHeight(int width, int height) {
        matrix.reset();
        //Otherwise, use a copy of the resource file references will be modified
//        setBitmap(Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888));
    }

    @Override
    public void setImageResource(int resId) {
        matrix.reset();
        //Otherwise, use a copy of the resource file references will be modified
        //    setBitmap(BitmapFactory.decodeResource(getResources(), resId));
    }

    public BubblePropertyModel calculate(BubblePropertyModel model) {
        float[] v = new float[9];
        matrix.getValues(v);
        // translation is simple
        float tx = v[Matrix.MTRANS_X];
        float ty = v[Matrix.MTRANS_Y];
        Log.d(TAG, "tx : " + tx + " ty : " + ty);
        // calculate real scale
        float scalex = v[Matrix.MSCALE_X];
        float skewy = v[Matrix.MSKEW_Y];
        float rScale = (float) Math.sqrt(scalex * scalex + skewy * skewy);
        Log.d(TAG, "rScale : " + rScale);
        // calculate the degree of rotation
        float rAngle = Math.round(Math.atan2(v[Matrix.MSKEW_X], v[Matrix.MSCALE_X]) * (180 / Math.PI));
        Log.d(TAG, "rAngle : " + rAngle);

        float minX = (dst_top.centerX() + dst_resize.centerX()) / 2;
        float minY = (dst_top.centerY() + dst_resize.centerY()) / 2;

        Log.d(TAG, "midX : " + minX + " midY : " + minY);

        model.setDegree((float) Math.toRadians(rAngle));
        model.setBubbleId(bubbleId);
        //TODO ??????
        float precentWidth = (mBitmap.getWidth() * rScale) / mScreenwidth;
        //float precentWidth = (mFontSize*mStr.length() * rScale) / mScreenwidth;
        model.setScaling(precentWidth);
        Log.d(TAG, " x " + (minX / mScreenwidth) + " y " + (minY / mScreenwidth));
//        model.setxLocation(minX / mScreenwidth);
//        model.setyLocation(minY / mScreenHeight);
        model.setxLocation(tx);
        model.setyLocation(ty);
        model.setText(mStr);


        model.setViewWidth(mBitmap.getWidth());
        model.setViewHeight(mBitmap.getHeight());
        model.setmFontVo(mFontVo);
        return model;
    }

    public void setBitmap(Bitmap bitmap, BubblePropertyModel model) {

        mFontVo = model.getmFontVo();

        int bitmapWidth = Math.max(1, model.getViewWidth());
        int bitmapHeight = Math.max(1, model.getViewHeight());
        originBitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        mBitmap = originBitmap.copy(Bitmap.Config.ARGB_8888, true);


        setDiagonalLength();
        initBitmaps();
        int w = mBitmap.getWidth();
        //int w = (int) (mFontSize*mStr.length());
        int h = mBitmap.getHeight();
        oringinWidth = w;


        mStr = model.getmFontVo().getLabelText();
        float scale = model.getScaling() * mScreenwidth / mBitmap.getWidth();
        //float scale = model.getScaling() * mScreenwidth / mFontSize*mStr.length();
        if (scale > MAX_SCALE) {
            scale = MAX_SCALE;
        } else if (scale < MIN_SCALE) {
            scale = MIN_SCALE;
        }
        matrix.postTranslate(model.getxLocation(), model.getyLocation());

        float degree = (float) Math.toDegrees(model.getDegree());
        matrix.postRotate(-degree, w >> 1, h >> 1);
        matrix.postScale(scale, scale, w >> 1, h >> 1);
        float midX = model.getxLocation() * mScreenwidth;
        float midY = model.getyLocation() * mScreenwidth;
        float offset = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 22, dm);
        midX = midX - (w * scale) / 2 - offset;
        midY = midY - (h * scale) / 2 - offset;
//        matrix.postTranslate(midX, midY);
        float[] v = new float[9];
        matrix.getValues(v);
        // translation is simple
        float mtx = v[Matrix.MTRANS_X];
        float mty = v[Matrix.MTRANS_Y];

        mFontPaint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, mFontVo.getFontSize(), dm));
        mFontPaint.setColor(mFontVo.getFontColorCode());
        String stylePath = mFontVo.getFontTypeName();
        if (stylePath != null && stylePath.length() > 0)
            mFontPaint.setTypeface(Typeface.createFromAsset(getContext().getAssets(), stylePath));

        fm = mFontPaint.getFontMetrics();

        matrix.postTranslate(model.getxLocation() - mtx, model.getyLocation() - mty);


//        invalidate();
    }
/*
    public void setBitmap() {
        final int padding = 15;
        final TextView textView = new TextView(getContext());
        textView.setText(mStr);
        textView.postDelayed(new Runnable() {
            @Override
            public void run() {
                float width;
                String[] str = mStr.split("\n");
                String longestString = getLongestString(str);
                width = mFontPaint.measureText(longestString, 0, longestString.length());
                if (longestString.length() < 5) {
                    String tempStr = "Sample";
                    float extra = mFontPaint.measureText(tempStr, 0, tempStr.length());
                    width = width + extra;
                }
                float height = (str.length * mFontVo.getFontSize());
                if (pRadius != 0) {
                    width = mFontPaint.measureText(mStr, 0, mStr.length());
                    height = mFontPaint.measureText(mStr, 0, mStr.length()) / 2;
                }
                originBitmap = Bitmap.createBitmap((int) width + padding, (int) (DensityUtils.dip2px(getContext(), height + padding)), Bitmap.Config.ARGB_8888);
//                mBitmap = originBitmap.copy(Bitmap.Config.ARGB_8888, true);
//                canvasText = new Canvas(mBitmap);
                oringinWidth = width;
//                invalidate();
            }
        }, 500);
    }*/
/*
    public void setBitmap(Bitmap bitmap) {
        originBitmap = bitmap;
        mBitmap = originBitmap.copy(Bitmap.Config.ARGB_8888, true);
        setDiagonalLength();
        initBitmaps();
        int w = mBitmap.getWidth();
        int h = mBitmap.getHeight();
        oringinWidth = w;
        float topbarHeight = DensityUtils.dip2px(getContext(), 50);
        // Y coordinates of (top operation bar + square) / 2
        matrix.postTranslate(mScreenwidth / 2 - w / 2, (mScreenwidth) / 2 - h / 2);
        invalidate();
    }*/

    private void setDiagonalLength() {
        halfDiagonalLength = Math.hypot(mBitmap.getWidth(), mBitmap.getHeight()) / 2;
        //halfDiagonalLength = Math.hypot((int)mFontSize*mStr.length(), mBitmap.getHeight())/2;
    }

    private void initBitmaps() {
        float minWidth = mScreenwidth / 5;
        if (mBitmap.getWidth() < minWidth) {
            MIN_SCALE = 1f;
        } else {
            MIN_SCALE = 1.0f * minWidth / mBitmap.getWidth();
        }
        if (mBitmap.getWidth() > mScreenwidth) {
            MAX_SCALE = 1;
        } else {
            MAX_SCALE = 1.0f * mScreenwidth / mBitmap.getWidth();
        }
        Bitmap deleteBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.rotate_normal);
        topBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.remove_normal);

        Bitmap flipVBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.rotate_normal);
        resizeBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.scale_normal);

        deleteBitmapWidth = (int) (deleteBitmap.getWidth() * BITMAP_SCALE);
        deleteBitmapHeight = (int) (deleteBitmap.getHeight() * BITMAP_SCALE);

        resizeBitmapWidth = (int) (resizeBitmap.getWidth() * BITMAP_SCALE);
        resizeBitmapHeight = (int) (resizeBitmap.getHeight() * BITMAP_SCALE);

        flipVBitmapWidth = (int) (flipVBitmap.getWidth() * BITMAP_SCALE);
        flipVBitmapHeight = (int) (flipVBitmap.getHeight() * BITMAP_SCALE);

        topBitmapWidth = (int) (topBitmap.getWidth() * BITMAP_SCALE);
        topBitmapHeight = (int) (topBitmap.getHeight() * BITMAP_SCALE);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = MotionEventCompat.getActionMasked(event);
        boolean handled = true;
        boolean isInBitmap = false;
        if (!mIsProductpreview) {
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    if (isInBitmap(event)) {
                        if (operationListener != null) {
                            operationListener.onClick(this);
                        }
                    }
                    boolean isDown;
                    boolean isUp;
                    if (isInButton(event, dst_delete)) {
                        if (operationListener != null) {
                            operationListener.onDeleteClick(this);
                        }
                        isDown = false;
                    } else if (isInResize(event)) {
                        isInResize = true;
                        lastRotateDegree = rotationToStartPoint(event);
                        midPointToStartPoint(event);
                        lastLength = diagonalLength(event);
                        isDown = false;
                    } else if (isInButton(event, dst_flipV)) {
                        PointF localPointF = new PointF();
                        midDiagonalPoint(localPointF);
                        matrix.postScale(-1.0F, 1.0F, localPointF.x, localPointF.y);

                        isDown = false;
                        invalidate();
                    } else if (isInButton(event, dst_top)) {
                        //Sticky
                        bringToFront();
                        if (operationListener != null) {
                            operationListener.onTop(this);
                        }
                        isDown = false;
                    } else if (isInBitmap(event)) {
                        isInSide = true;
                        lastX = event.getX(0);
                        lastY = event.getY(0);
                        isDown = true;
                        isMove = false;
                        isPointerDown = false;
                        isUp = false;
                        isInBitmap = true;

                        long currentTime = System.currentTimeMillis();
//                    Log.d(TAG, (currentTime - preClicktime) + "");
                        if (currentTime - preClicktime > doubleClickTimeLimit) {
                            preClicktime = currentTime;
                        } else {
                            if (operationListener != null) {
                                operationListener.onDoubleClick(this);
                            }
                        }

                    } else {
                        handled = false;
                    }
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (spacing(event) > pointerLimitDis) {
                        oldDis = spacing(event);
                        isPointerDown = true;
                        midPointToStartPoint(event);
                    } else {
                        isPointerDown = false;
                    }
                    isInSide = false;
                    isInResize = false;
                    break;
                case MotionEvent.ACTION_MOVE:
                    //Pinch to zoom
                    if (isPointerDown) {
                        float scale;
                        float disNew = spacing(event);
                        if (disNew == 0 || disNew < pointerLimitDis) {
                            scale = 1;
                        } else {
                            scale = disNew / oldDis;
                            //Zoom slowly
                            scale = (scale - 1) * pointerZoomCoeff + 1;
                        }
                        float scaleTemp = (scale * Math.abs(dst_flipV.left - dst_resize.left)) / oringinWidth;
                        if (((scaleTemp <= MIN_SCALE)) && scale < 1 ||
                                (scaleTemp >= MAX_SCALE) && scale > 1) {
                            scale = 1;
                        } else {
                            lastLength = diagonalLength(event);
                        }
                        matrix.postScale(scale, scale, mid.x, mid.y);
                        invalidate();
                    } else if (isInResize) {
                        matrix.postRotate((rotationToStartPoint(event) - lastRotateDegree) * 2, mid.x, mid.y);
                        lastRotateDegree = rotationToStartPoint(event);

                        float scale = diagonalLength(event) / lastLength;

                        if (((diagonalLength(event) / halfDiagonalLength <= MIN_SCALE)) && scale < 1 ||
                                (diagonalLength(event) / halfDiagonalLength >= MAX_SCALE) && scale > 1) {
                            scale = 1;
                            if (!isInResize(event)) {
                                isInResize = false;
                            }
                        } else {
                            lastLength = diagonalLength(event);
                        }
                        matrix.postScale(scale, scale, mid.x, mid.y);

                        invalidate();
                    } else if (isInSide) {
                        //TODO Moving beyond the screen area can not judge
                        float x = event.getX(0);
                        float y = event.getY(0);
                        //Analyzing finger shaking distance plus isMove judgment is true as long as moved
                        if (!isMove && Math.abs(x - lastX) < moveLimitDis
                                && Math.abs(y - lastY) < moveLimitDis) {
                            isMove = false;
                        } else {
                            isMove = true;
                        }
                        matrix.postTranslate(x - lastX, y - lastY);
                        lastX = x;
                        lastY = y;
                        invalidate();
                    }
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    isInResize = false;
                    isInSide = false;
                    isPointerDown = false;
                    isUp = true;
                    break;

            }
            if (handled && operationListener != null) {
                operationListener.onEdit(this);
            }
        }
        return handled;
    }

    /**
     * Whether the four lines inside
     *
     * @return
     */
    private boolean isInBitmap(MotionEvent event) {
        if (mBitmap!=null) {

            float[] arrayOfFloat1 = new float[9];
            this.matrix.getValues(arrayOfFloat1);
            //The upper left corner
            float f1 = 0.0F * arrayOfFloat1[0] + 0.0F * arrayOfFloat1[1] + arrayOfFloat1[2];
            float f2 = 0.0F * arrayOfFloat1[3] + 0.0F * arrayOfFloat1[4] + arrayOfFloat1[5];
            //Upper right corner
            float f3 = arrayOfFloat1[0] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat1[1] + arrayOfFloat1[2];
            float f4 = arrayOfFloat1[3] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat1[4] + arrayOfFloat1[5];
            //Lower left corner
            float f5 = 0.0F * arrayOfFloat1[0] + arrayOfFloat1[1] * this.mBitmap.getHeight() + arrayOfFloat1[2];
            float f6 = 0.0F * arrayOfFloat1[3] + arrayOfFloat1[4] * this.mBitmap.getHeight() + arrayOfFloat1[5];
            //Bottom right corner
            float f7 = arrayOfFloat1[0] * this.mBitmap.getWidth() + arrayOfFloat1[1] * this.mBitmap.getHeight() + arrayOfFloat1[2];
            float f8 = arrayOfFloat1[3] * this.mBitmap.getWidth() + arrayOfFloat1[4] * this.mBitmap.getHeight() + arrayOfFloat1[5];

            float[] arrayOfFloat2 = new float[4];
            float[] arrayOfFloat3 = new float[4];
            //Determining the range of the X-direction
            arrayOfFloat2[0] = f1;//Left left
            arrayOfFloat2[1] = f3;//Top right right
            arrayOfFloat2[2] = f7;//Right lower right
            arrayOfFloat2[3] = f5;//Left left
            //Determining the range of the Y-direction
            arrayOfFloat3[0] = f2;//On the left
            arrayOfFloat3[1] = f4;//On the upper right
            arrayOfFloat3[2] = f8;
            arrayOfFloat3[3] = f6;
            return pointInRect(arrayOfFloat2, arrayOfFloat3, event.getX(0), event.getY(0));
        }
        return false;
    }

    /**
     * Determine whether a point inside the rectangle
     *
     * @param xRange
     * @param yRange
     * @param x
     * @param y
     * @return
     */
    private boolean pointInRect(float[] xRange, float[] yRange, float x, float y) {
        //The length of the four sides
        double a1 = Math.hypot(xRange[0] - xRange[1], yRange[0] - yRange[1]);
        double a2 = Math.hypot(xRange[1] - xRange[2], yRange[1] - yRange[2]);
        double a3 = Math.hypot(xRange[3] - xRange[2], yRange[3] - yRange[2]);
        double a4 = Math.hypot(xRange[0] - xRange[3], yRange[0] - yRange[3]);
        //Measuring point distance to four points
        double b1 = Math.hypot(x - xRange[0], y - yRange[0]);
        double b2 = Math.hypot(x - xRange[1], y - yRange[1]);
        double b3 = Math.hypot(x - xRange[2], y - yRange[2]);
        double b4 = Math.hypot(x - xRange[3], y - yRange[3]);

        double u1 = (a1 + b1 + b2) / 2;
        double u2 = (a2 + b2 + b3) / 2;
        double u3 = (a3 + b3 + b4) / 2;
        double u4 = (a4 + b4 + b1) / 2;

        //Area of a rectangle
        double s = a1 * a2;
        double ss = Math.sqrt(u1 * (u1 - a1) * (u1 - b1) * (u1 - b2))
                + Math.sqrt(u2 * (u2 - a2) * (u2 - b2) * (u2 - b3))
                + Math.sqrt(u3 * (u3 - a3) * (u3 - b3) * (u3 - b4))
                + Math.sqrt(u4 * (u4 - a4) * (u4 - b4) * (u4 - b1));
        return Math.abs(s - ss) < 0.5;
    }

    private boolean isInButton(MotionEvent event, Rect rect) {
        int left = rect.left;
        int right = rect.right;
        int top = rect.top;
        int bottom = rect.bottom;
        return event.getX(0) >= left && event.getX(0) <= right && event.getY(0) >= top && event.getY(0) <= bottom;
    }

    private boolean isInResize(MotionEvent event) {
        int left = -20 + this.dst_resize.left;
        int top = -20 + this.dst_resize.top;
        int right = 20 + this.dst_resize.right;
        int bottom = 20 + this.dst_resize.bottom;
        return event.getX(0) >= left && event.getX(0) <= right && event.getY(0) >= top && event.getY(0) <= bottom;
    }

    private void midPointToStartPoint(MotionEvent event) {
        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float f1 = 0.0f * arrayOfFloat[0] + 0.0f * arrayOfFloat[1] + arrayOfFloat[2];
        float f2 = 0.0f * arrayOfFloat[3] + 0.0f * arrayOfFloat[4] + arrayOfFloat[5];
        float f3 = f1 + event.getX(0);
        float f4 = f2 + event.getY(0);
        mid.set(f3 / 2, f4 / 2);
    }

    private void midDiagonalPoint(PointF paramPointF) {
        float[] arrayOfFloat = new float[9];
        this.matrix.getValues(arrayOfFloat);
        float f1 = 0.0F * arrayOfFloat[0] + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float f2 = 0.0F * arrayOfFloat[3] + 0.0F * arrayOfFloat[4] + arrayOfFloat[5];
        float f3 = arrayOfFloat[0] * this.mBitmap.getWidth() + arrayOfFloat[1] * this.mBitmap.getHeight() + arrayOfFloat[2];
        float f4 = arrayOfFloat[3] * this.mBitmap.getWidth() + arrayOfFloat[4] * this.mBitmap.getHeight() + arrayOfFloat[5];
        float f5 = f1 + f3;
        float f6 = f2 + f4;
        paramPointF.set(f5 / 2.0F, f6 / 2.0F);
    }

    /**
     * Sliding a car in X, Y will not change, here minus Y, minus X, in fact, is equivalent to X, Y as the origin
     *
     * @param event
     * @return
     */
    private float rotationToStartPoint(MotionEvent event) {

        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float x = 0.0f * arrayOfFloat[0] + 0.0f * arrayOfFloat[1] + arrayOfFloat[2];
        float y = 0.0f * arrayOfFloat[3] + 0.0f * arrayOfFloat[4] + arrayOfFloat[5];
        double arc = Math.atan2(event.getY(0) - y, event.getX(0) - x);
        return (float) Math.toDegrees(arc);
    }

    /**
     * From the rectangle center point to the touch
     *
     * @param event
     * @return
     */
    private float diagonalLength(MotionEvent event) {
        float diagonalLength = (float) Math.hypot(event.getX(0) - mid.x, event.getY(0) - mid.y);
        return diagonalLength;
    }

    /**
     * Determine the space between the first two fingers
     */
    private float spacing(MotionEvent event) {
        if (event.getPointerCount() == 2) {
            float x = event.getX(0) - event.getX(1);
            float y = event.getY(0) - event.getY(1);
            return (float) Math.sqrt(x * x + y * y);
        } else {
            return 0;
        }
    }

    public void viewLeftAlign(int pointX, int pointY) {
        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float viewStartXPos = arrayOfFloat[Matrix.MTRANS_X];
        float translateX = pointX - viewStartXPos;
        matrix.postTranslate(translateX, pointY);
        mFontVo.setAlignmentStyle(AlignmentType.LEFT);

        invalidate();
    }

    public void viewRightAlign(int pointX, int pointY) {
        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float f1 = 0.0F * arrayOfFloat[0] + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float f3 = arrayOfFloat[0] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float viewWidth = Math.abs(f3 - f1);
        float viewEndXPos = arrayOfFloat[Matrix.MTRANS_X] + viewWidth;
        float translateX = pointX - viewEndXPos;
        matrix.postTranslate(translateX, pointY);
        mFontVo.setAlignmentStyle(AlignmentType.RIGHT);
        invalidate();
    }

    public void viewCenterAlign(int moveXTrans) {
        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float f1 = 0.0F * arrayOfFloat[0] + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float f3 = arrayOfFloat[0] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float viewWidth = Math.abs(f3 - f1);
        float viewCenterWidth = viewWidth / 2;
        float viewStartXPos = moveXTrans - viewCenterWidth;
        float viewXPos = arrayOfFloat[Matrix.MTRANS_X];
        float translateX = viewStartXPos - viewXPos;
        matrix.postTranslate(translateX, 0);
        mFontVo.setAlignmentStyle(AlignmentType.CENTER);
        invalidate();
    }

    public void setObjectHeightWidth(int width, int height) {
        if (width < mScreenwidth)
            mScreenwidth = width;

        if (height < mScreenHeight)
            mScreenHeight = height;
    }

  /*  public void setLabelText(float x, float y) {
        matrix.reset();
        //Otherwise, use a copy of the resource file references will be modified
        setBitmap(x, y);
    }*/

    public void rotationBaseImprintAre(double degree, float point1, float point2) {
        lastRotateDegree = (float) degree;
        CustomLogHandler.printVerbose(TAG, "mid.x:--" + point1 + "mid.Y:--" + point2);
        matrix.postRotate((float) degree, point1, point2);
//        matrix.postTranslate(point1,point2);
/*
        if(deg>0)2
            matrix.postTranslate(mScreenwidth / 2 ,0);
*/
        invalidate();
    }

    public void rotateView(boolean isClockwise) {

        float[] arrayOfFloat = new float[9];
        matrix.getValues(arrayOfFloat);
        float f1 = 0.0F * arrayOfFloat[0] + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float f2 = 0.0F * arrayOfFloat[3] + 0.0F * arrayOfFloat[4] + arrayOfFloat[5];
        float f3 = arrayOfFloat[0] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[1] + arrayOfFloat[2];
        float f4 = arrayOfFloat[3] * this.mBitmap.getWidth() + 0.0F * arrayOfFloat[4] + arrayOfFloat[5];
        float f5 = 0.0F * arrayOfFloat[0] + arrayOfFloat[1] * this.mBitmap.getHeight() + arrayOfFloat[2];
        float f6 = 0.0F * arrayOfFloat[3] + arrayOfFloat[4] * this.mBitmap.getHeight() + arrayOfFloat[5];
        float f7 = arrayOfFloat[0] * this.mBitmap.getWidth() + arrayOfFloat[1] * this.mBitmap.getHeight() + arrayOfFloat[2];
        float f8 = arrayOfFloat[3] * this.mBitmap.getWidth() + arrayOfFloat[4] * this.mBitmap.getHeight() + arrayOfFloat[5];


        float scalex = arrayOfFloat[Matrix.MSCALE_X];
        float skewy = arrayOfFloat[Matrix.MSKEW_Y];
        float rScale = (float) Math.sqrt(scalex * scalex + skewy * skewy);
        float rAngle = Math.round(Math.atan2(arrayOfFloat[Matrix.MSKEW_X], arrayOfFloat[Matrix.MSCALE_X]) * (180 / Math.PI));
        float yAngle = Math.round(Math.atan2(arrayOfFloat[Matrix.MSKEW_Y], arrayOfFloat[Matrix.MSCALE_Y]) * (180 / Math.PI));
        CustomLogHandler.printVerbose(TAG, "yAngle:-" + yAngle);
        CustomLogHandler.printVerbose(TAG, "rAngle:-" + rAngle);

        float fX = f1 + f3;
        float fY = f2 + f6;

        if (rAngle == 0.0 && yAngle == 0.0) {
            fX = f1 + f7;
            fY = f2 + f8;
        } else if (yAngle >= 0 && yAngle <= 90) {
            fX = f5 + f3;
            fY = f6 + f4;
        } else if (rAngle >= 0 && rAngle <= 90) {
            fX = f3 + f5;
            fY = f4 + f6;
        } else if (rAngle >= 90 && rAngle <= 180) {
            fX = f5 + f3;
            fY = f8 + f2;
        } else if (yAngle >= 90 && yAngle <= 180) {
            fX = f5 + f3;
            fY = f8 + f2;
        }
        mid.set(fX / 2, fY / 2);

        CustomLogHandler.printVerbose(TAG, "fX:-" + fX);
        CustomLogHandler.printVerbose(TAG, "fY:-" + fY);
        CustomLogHandler.printVerbose(TAG, "lastRotateDegree:-" + lastRotateDegree);

        matrix.postRotate(isClockwise ? 90 : -90, mid.x, mid.y);

        invalidate();
    }

    public void setInPreviewMode(boolean isProductPreview) {
        mIsProductpreview = isProductPreview;
    }

    public void setMoveUp() {
        bringToFront();
        if (operationListener != null)
            operationListener.onTop(this);
    }

    public void setChangeEffectBitmap(Bitmap bitmapResult) {
        mBitmap = bitmapResult;
        setDiagonalLength();
        initBitmaps();

    }

    public void setOperationListener(OperationListener operationListener) {
        this.operationListener = operationListener;
    }

    public void setInEdit(boolean isInEdit) {
        this.isInEdit = isInEdit;
        invalidate();
    }

    public boolean isInEditMode() {
        return this.isInEdit;
    }

    /**
     * Automatic Segmentation of text
     *
     * @param content We need to split text
     * @param p       Brush, depending on the font used to measure the width of the text
     * @param width   Specified width
     * @return A string array, save the text of each line
     */
    private String[] autoSplit(String content, Paint p, float width) {
        int length = content.length();
        float textWidth = p.measureText(content);
        if (textWidth <= width) {
            return new String[]{content};
        }

        int start = 0, end = 1, i = 0;
        int lines = (int) Math.ceil(textWidth / width); //Calculate the number of rows
        String[] lineTexts = new String[lines];
        while (start < length) {
            if (p.measureText(content, start, end) > width) { //When the text is wider than the width of the control
                lineTexts[i++] = (String) content.subSequence(start, end);
                start = end;
            }
            if (end == length) { //Less than one line of text
                lineTexts[i] = (String) content.subSequence(start, end);
                break;
            }
            end += 1;
        }
        return lineTexts;
    }

    public String getmStr() {
        return mStr;
    }

    //Set Text Bold
    public void setBold() {
        boolean isBold = mFontVo.isFontStyleBold();
        if (!isBold) {
            mFontPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        } else {
            mFontPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        }
        mFontVo.setFontStyleBold(!isBold);
//        setBitmap();
//        invalidate();
    }

    //Set Text Italic
    public void setItalic() {
        boolean isItalic = mFontVo.isFontStyleItalic();
        if (!isItalic) {
            mFontPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));
        } else {
            mFontPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        }
        mFontVo.setFontStyleItalic(!isItalic);
//        setBitmap();
//        invalidate();
    }

    //Set Text Underline
    public void setUnderline() {
        boolean isUnderline = mFontVo.isFontStyleUnderLine();
        if (!isUnderline) {
            mFontPaint.setUnderlineText(true);
        } else {
            mFontPaint.setUnderlineText(false);
        }
        mFontVo.setFontStyleUnderLine(!isUnderline);
//        setBitmap();
//        invalidate();
    }

    //Set Font Type
    public void setFontType(String fontPath) {
        mFontVo.setFontTypeName(fontPath);
        mFontPaint.setTypeface(Typeface.createFromAsset(getContext().getAssets(), fontPath));
//        setBitmap();
//        invalidate();
    }

    //Set Font Size
    public void setFontsize(float pFontSize) {
        mFontVo.setFontSize(pFontSize);
        mFontPaint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, pFontSize, dm));
        fm = mFontPaint.getFontMetrics();
//        setBitmap();
//        setDiagonalLength();
//        initBitmaps();
//        setBitmap();
//        invalidate();
    }

    public int getTextOpacity() {
        return opa;
    }

    //Set Text Opacity
    public void setTextOpacity(int p) {
        opa = p;
        mFontVo.setOpacity(opa);
//        invalidate();
    }

    //Set Font Color
    public void setFontColor(int color) {
        fontColor = color;
        mFontVo.setEffectType(EffectTypes.MULTICOLOR);
        mFontVo.setFontColorCode(color);
        mFontPaint.setColor(color);
//        invalidate();
    }

    public void setCurve(int mRadius) {
        pRadius = mRadius;
        mFontVo.setCurveDegree(pRadius);
//        setBitmap();
    }

    /**
     * @param bitmap  The source bitmap.
     * @param opacity a value between 0 (completely transparent) and 255 (completely
     *                opaque).
     * @return The opacity-adjusted bitmap.  If the source bitmap is mutable it will be
     * adjusted and returned, otherwise a new bitmap is created.
     */
    private Bitmap adjustOpacity(Bitmap bitmap, int opacity) {
        Bitmap mutableBitmap = bitmap.isMutable()
                ? bitmap
                : bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(mutableBitmap);
        int colour = (opacity & 0xFF) << 24;
        canvas.drawColor(colour, PorterDuff.Mode.DST_IN);
        return mutableBitmap;
    }

    public void changeFlipText(FlipType flipType) {
        FlipType type = mFontVo.getFlipType();
        if ((type == FlipType.VERTICAL && flipType == FlipType.HORIZONTAL) || (type == FlipType.HORIZONTAL && flipType == FlipType.VERTICAL)) {
            mFontVo.setFlipType(FlipType.VERTICAL_HORIZONTAL);
        } else if (type == FlipType.VERTICAL_HORIZONTAL && flipType == FlipType.VERTICAL) {
            mFontVo.setFlipType(FlipType.HORIZONTAL);
        } else if (type == FlipType.VERTICAL_HORIZONTAL && flipType == FlipType.HORIZONTAL) {
            mFontVo.setFlipType(FlipType.VERTICAL);
        } else if ((type == FlipType.VERTICAL && flipType == FlipType.VERTICAL) || (type == FlipType.HORIZONTAL && flipType == FlipType.HORIZONTAL)) {
            mFontVo.setFlipType(FlipType.NONE);
        } else {
            mFontVo.setFlipType(flipType);
        }

//        setBitmap();

    }

/*
    public void setFilpVerticalText(boolean b) {
        if (!isVFlip) {
            isVFlip = b;
            mFontVo.setVFlip(isVFlip);
        } else {
            mFontVo.setVFlip(false);
        }
        setBitmap();
    }

    public void setFilpHorizontalText(boolean b) {

        if (!isHFlip) {
            isHFlip = b;
            mFontVo.setHFlip(isHFlip);
        } else {
            mFontVo.setHFlip(false);
        }
        setBitmap();
    }*/

    public void setEffectType(EffectTypes effectType) {
        mFontVo.setEffectType(effectType);

        mFontPaint.setMaskFilter(null);
        if (mEffectType == EffectTypes.EMBOSS) {
            mFontPaint.setColor(Color.GRAY);
            mFontPaint.setMaskFilter(emboss_filter);
        } else if (mEffectType == EffectTypes.DEBOSS) {
            mFontPaint.setColor(Color.GRAY);
            mFontPaint.setMaskFilter(deboss_filter);
        } else {
            mFontPaint.setColor(fontColor);
        }
    }

    public void setSingleColor() {
        setSingleColorWithColorCode(Color.BLACK);
    }

    public void setSingleColorWithColorCode(int mColor) {
            mFontVo.setEffectType(EffectTypes.SINGLE_COLOR);
            mFontVo.setSingleColorCode(mColor);

        mFontPaint.setColor(mColor);

    }

    public void setEmbroideryEffect() {
        setEmbroideryEffectWithColor(Color.CYAN);
    }

    public void setEmbroideryEffectWithColor(int colorCode) {
        mFontVo.setEmbroideryColorCode(colorCode);
    }

    public void setToneOnToneEffect(int colorShade) {

        mFontVo.setToneOnToneColorCode(colorShade);
        mFontVo.setEffectType(EffectTypes.TONE_ON_TONE);
    }

    public void setLeatherEngraveEffect(int colorShade){
        mFontVo.setLeatherEngravedColorCode(colorShade);
        mFontVo.setEffectType(EffectTypes.LEATHER_ENGRAVED);
    }

    public interface OperationListener {
        void onDeleteClick(BubbleTextView bubbleTextView);

        void onEdit(BubbleTextView bubbleTextView);

        void onDoubleClick(BubbleTextView bubbleTextView);

        void onTop(BubbleTextView bubbleTextView);

        void onClick(BubbleTextView bubbleTextView);
    }
/*

    public void setEmbossEffect(boolean isEmboss) {
        mFontVo.setEffectType(EffectTypes.EMBOSS);;
        CommonUtil.dismissProgressDialog();
        invalidate();
    }

    public void setDebossEffect(boolean isDeboss) {
        mFontVo.setEffectType(EffectTypes.DEBOSS);;
        CommonUtil.dismissProgressDialog();
        invalidate();
    }

    public void setEngraveEffect(boolean isEngrave) {
        mFontVo.setEffectType(EffectTypes.ENGRAVE);;
        invalidate();
    }

    public void setSatinEachEffect(boolean issSatinEachEffect) {
        mFontVo.setEffectType(EffectTypes.SATIN_EACH);;
        invalidate();
    }


    public void setWoodenEffect(boolean isWooden) {
        mFontVo.setEffectType(EffectTypes.WOODEN);;
        invalidate();
    }

    public void setEmbroidery(boolean isEmbroidary, int colorCode) {
        mFontVo.setEffectType(EffectTypes.EMBROIDERY);;
        mFontVo.setEmbroideryColorCode(colorCode);
        invalidate();
    }*/

}