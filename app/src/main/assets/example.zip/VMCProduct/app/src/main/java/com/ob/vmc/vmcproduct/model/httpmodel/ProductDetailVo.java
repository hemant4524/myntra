package com.ob.vmc.vmcproduct.model.httpmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ishan4452 on 11/22/2016.
 */
public class ProductDetailVo extends BaseVo {


    /**
     * data : {"basicInformation":{"vmcProductId":"55b85008204e7852688b516e","sku":"TSB7","personalized":1,"productType":"single","suplier":{"supplierId":4,"supplierName":"Adnart"},"configurationOptions":{"wraparound":0}},"productInformation":{"title":"SHAKE IT BABY"},"imprintInfo":[{"locationId":"inboard_0","locationName":"inboard","locationKey":"inboard","imprintParam":{"imprint_title":"inboard","imprint_image_size":"134.05968740221X193.01036241548","product_template_object_shape":"mug2","imptintPoints":{"point1":{"x":"178.00000042724608","y":"233.00000012207028"},"point2":{"x":"311.9999996337891","y":"237"},"point3":{"x":"309.9999996337891","y":"428"},"point4":{"x":"180.0000003662109","y":"426.0000001220703"},"curveTop":{"x":"245","y":"432"},"curveBottom":{"x":"241","y":"241"}}},"imprintSettings":{"fabric":0,"giftset":0,"combinearea":0,"horizontalmug":0,"combineareadifferentlogo":0,"addtext":1,"addimage":1,"bottomtotoprotate":0,"toptobottomrotate":0},"imprintMethod":{"deboss":"0","emboss":"0","embroidery":"0","glass":"0","plain":"1","single_color":"1","wooden":"0"},"order":1,"defaultImprintMethod":"plain"},{"locationId":"outboard_0","locationName":"outboard","locationKey":"outboard","imprintParam":{"imprint_title":"outboard","imprint_image_size":"121.01652779683X193.01036241611","product_template_object_shape":"mug2","imptintPoints":{"point1":{"x":"192","y":"235"},"point2":{"x":"313","y":"237"},"point3":{"x":"311","y":"427"},"point4":{"x":"194","y":"428"},"curveTop":{"x":"252","y":"432"},"curveBottom":{"x":"248","y":"241"}}},"imprintSettings":{"fabric":0,"giftset":0,"combinearea":0,"horizontalmug":0,"combineareadifferentlogo":0,"addtext":1,"addimage":1,"bottomtotoprotate":0,"toptobottomrotate":0},"imprintMethod":{"deboss":"0","emboss":"0","embroidery":"0","glass":"0","plain":"1","single_color":"1","wooden":"0"},"order":2,"defaultImprintMethod":"plain"}],"sides":[{"locationKey":"inboard","side_image":[{"colorId":17,"colorName":"Clear","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-100x100.jpg"},{"colorId":24,"colorName":"Graphite","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-100x100.jpg"},{"colorId":10,"colorName":"Green","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-100x100.jpg"},{"colorId":7,"colorName":"Red","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-100x100.jpg"},{"colorId":8,"colorName":"Blue","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-100x100.jpg"}]},{"locationKey":"outboard","side_image":[{"colorId":17,"colorName":"Clear","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/outboard/TSB7_WHITE-back-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/outboard/TSB7_WHITE-back-100x100.jpg"},{"colorId":24,"colorName":"Graphite","productImage":"noimage","thumbImage":"noimage"},{"colorId":10,"colorName":"Green","productImage":"noimage","thumbImage":"noimage"},{"colorId":7,"colorName":"Red","productImage":"noimage","thumbImage":"noimage"},{"colorId":8,"colorName":"Blue","productImage":"noimage","thumbImage":"noimage"}]}]}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo implements Parcelable {
        /**
         * basicInformation : {"vmcProductId":"55b85008204e7852688b516e","sku":"TSB7","personalized":1,"productType":"single","suplier":{"supplierId":4,"supplierName":"Adnart"},"configurationOptions":{"wraparound":0}}
         * productInformation : {"title":"SHAKE IT BABY"}
         * imprintInfo : [{"locationId":"inboard_0","locationName":"inboard","locationKey":"inboard","imprintParam":{"imprint_title":"inboard","imprint_image_size":"134.05968740221X193.01036241548","product_template_object_shape":"mug2","imptintPoints":{"point1":{"x":"178.00000042724608","y":"233.00000012207028"},"point2":{"x":"311.9999996337891","y":"237"},"point3":{"x":"309.9999996337891","y":"428"},"point4":{"x":"180.0000003662109","y":"426.0000001220703"},"curveTop":{"x":"245","y":"432"},"curveBottom":{"x":"241","y":"241"}}},"imprintSettings":{"fabric":0,"giftset":0,"combinearea":0,"horizontalmug":0,"combineareadifferentlogo":0,"addtext":1,"addimage":1,"bottomtotoprotate":0,"toptobottomrotate":0},"imprintMethod":{"deboss":"0","emboss":"0","embroidery":"0","glass":"0","plain":"1","single_color":"1","wooden":"0"},"order":1,"defaultImprintMethod":"plain"},{"locationId":"outboard_0","locationName":"outboard","locationKey":"outboard","imprintParam":{"imprint_title":"outboard","imprint_image_size":"121.01652779683X193.01036241611","product_template_object_shape":"mug2","imptintPoints":{"point1":{"x":"192","y":"235"},"point2":{"x":"313","y":"237"},"point3":{"x":"311","y":"427"},"point4":{"x":"194","y":"428"},"curveTop":{"x":"252","y":"432"},"curveBottom":{"x":"248","y":"241"}}},"imprintSettings":{"fabric":0,"giftset":0,"combinearea":0,"horizontalmug":0,"combineareadifferentlogo":0,"addtext":1,"addimage":1,"bottomtotoprotate":0,"toptobottomrotate":0},"imprintMethod":{"deboss":"0","emboss":"0","embroidery":"0","glass":"0","plain":"1","single_color":"1","wooden":"0"},"order":2,"defaultImprintMethod":"plain"}]
         * sides : [{"locationKey":"inboard","side_image":[{"colorId":17,"colorName":"Clear","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-100x100.jpg"},{"colorId":24,"colorName":"Graphite","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-100x100.jpg"},{"colorId":10,"colorName":"Green","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-100x100.jpg"},{"colorId":7,"colorName":"Red","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-100x100.jpg"},{"colorId":8,"colorName":"Blue","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-100x100.jpg"}]},{"locationKey":"outboard","side_image":[{"colorId":17,"colorName":"Clear","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/outboard/TSB7_WHITE-back-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/outboard/TSB7_WHITE-back-100x100.jpg"},{"colorId":24,"colorName":"Graphite","productImage":"noimage","thumbImage":"noimage"},{"colorId":10,"colorName":"Green","productImage":"noimage","thumbImage":"noimage"},{"colorId":7,"colorName":"Red","productImage":"noimage","thumbImage":"noimage"},{"colorId":8,"colorName":"Blue","productImage":"noimage","thumbImage":"noimage"}]}]
         */

        @SerializedName("basicInformation")
        private BasicInformationVo basicInformation;
        @SerializedName("productInformation")
        private ProductInformationVo productInformation;
        @SerializedName("imprintInfo")
        private List<ImprintInfoVo> imprintInfo;
        @SerializedName("sides")
        private List<SidesVo> sides;

        public BasicInformationVo getBasicInformation() {
            return basicInformation;
        }

        public void setBasicInformation(BasicInformationVo basicInformation) {
            this.basicInformation = basicInformation;
        }

        public ProductInformationVo getProductInformation() {
            return productInformation;
        }

        public void setProductInformation(ProductInformationVo productInformation) {
            this.productInformation = productInformation;
        }

        public List<ImprintInfoVo> getImprintInfo() {
            return imprintInfo;
        }

        public void setImprintInfo(List<ImprintInfoVo> imprintInfo) {
            this.imprintInfo = imprintInfo;
        }

        public List<SidesVo> getSides() {
            return sides;
        }

        public void setSides(List<SidesVo> sides) {
            this.sides = sides;
        }

        public static class BasicInformationVo implements Parcelable {


            /**
             * vmcProductId : 55b85008204e7852688b516e
             * sku : TSB7
             * personalized : 1
             * productType : single
             * suplier : {"supplierId":4,"supplierName":"Adnart"}
             * configurationOptions : {"wraparound":0}
             */

            @SerializedName("vmcProductId")
            private String vmcProductId;
            @SerializedName("sku")
            private String sku;
            @SerializedName("personalized")
            private int personalized;
            @SerializedName("productType")
            private String productType;
            @SerializedName("suplier")
            private SuplierVo suplier;
            @SerializedName("configurationOptions")
            private ConfigurationOptionsVo configurationOptions;

            public String getVmcProductId() {
                return vmcProductId;
            }

            public void setVmcProductId(String vmcProductId) {
                this.vmcProductId = vmcProductId;
            }

            public String getSku() {
                return sku;
            }

            public void setSku(String sku) {
                this.sku = sku;
            }

            public int getPersonalized() {
                return personalized;
            }

            public void setPersonalized(int personalized) {
                this.personalized = personalized;
            }

            public String getProductType() {
                return productType;
            }

            public void setProductType(String productType) {
                this.productType = productType;
            }

            public SuplierVo getSuplier() {
                return suplier;
            }

            public void setSuplier(SuplierVo suplier) {
                this.suplier = suplier;
            }

            public ConfigurationOptionsVo getConfigurationOptions() {
                return configurationOptions;
            }

            public void setConfigurationOptions(ConfigurationOptionsVo configurationOptions) {
                this.configurationOptions = configurationOptions;
            }

            public static class SuplierVo implements Parcelable {
                /**
                 * supplierId : 4
                 * supplierName : Adnart
                 */

                @SerializedName("supplierId")
                private int supplierId;
                @SerializedName("supplierName")
                private String supplierName;

                public int getSupplierId() {
                    return supplierId;
                }

                public void setSupplierId(int supplierId) {
                    this.supplierId = supplierId;
                }

                public String getSupplierName() {
                    return supplierName;
                }

                public void setSupplierName(String supplierName) {
                    this.supplierName = supplierName;
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeInt(this.supplierId);
                    dest.writeString(this.supplierName);
                }

                public SuplierVo() {
                }

                protected SuplierVo(Parcel in) {
                    this.supplierId = in.readInt();
                    this.supplierName = in.readString();
                }

                public static final Creator<SuplierVo> CREATOR = new Creator<SuplierVo>() {
                    @Override
                    public SuplierVo createFromParcel(Parcel source) {
                        return new SuplierVo(source);
                    }

                    @Override
                    public SuplierVo[] newArray(int size) {
                        return new SuplierVo[size];
                    }
                };
            }

            public static class ConfigurationOptionsVo implements Parcelable {
                /**
                 * wraparound : 0
                 */

                @SerializedName("wraparound")
                private int wraparound;

                public int getWraparound() {
                    return wraparound;
                }

                public void setWraparound(int wraparound) {
                    this.wraparound = wraparound;
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeInt(this.wraparound);
                }

                public ConfigurationOptionsVo() {
                }

                protected ConfigurationOptionsVo(Parcel in) {
                    this.wraparound = in.readInt();
                }

                public static final Creator<ConfigurationOptionsVo> CREATOR = new Creator<ConfigurationOptionsVo>() {
                    @Override
                    public ConfigurationOptionsVo createFromParcel(Parcel source) {
                        return new ConfigurationOptionsVo(source);
                    }

                    @Override
                    public ConfigurationOptionsVo[] newArray(int size) {
                        return new ConfigurationOptionsVo[size];
                    }
                };
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.vmcProductId);
                dest.writeString(this.sku);
                dest.writeInt(this.personalized);
                dest.writeString(this.productType);
                dest.writeParcelable(this.suplier, flags);
                dest.writeParcelable(this.configurationOptions, flags);
            }

            public BasicInformationVo() {
            }

            protected BasicInformationVo(Parcel in) {
                this.vmcProductId = in.readString();
                this.sku = in.readString();
                this.personalized = in.readInt();
                this.productType = in.readString();
                this.suplier = in.readParcelable(SuplierVo.class.getClassLoader());
                this.configurationOptions = in.readParcelable(ConfigurationOptionsVo.class.getClassLoader());
            }

            public static final Creator<BasicInformationVo> CREATOR = new Creator<BasicInformationVo>() {
                @Override
                public BasicInformationVo createFromParcel(Parcel source) {
                    return new BasicInformationVo(source);
                }

                @Override
                public BasicInformationVo[] newArray(int size) {
                    return new BasicInformationVo[size];
                }
            };
        }

        public static class ProductInformationVo implements Parcelable {
            /**
             * title : SHAKE IT BABY
             */

            @SerializedName("title")
            private String title;
            @SerializedName("description")
            private String description;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }


            public String getDescription() {
                return description;
            }

            public ProductInformationVo setDescription(String description) {
                this.description = description;
                return this;
            }

            public ProductInformationVo() {
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.title);
                dest.writeString(this.description);
            }

            protected ProductInformationVo(Parcel in) {
                this.title = in.readString();
                this.description = in.readString();
            }

            public static final Creator<ProductInformationVo> CREATOR = new Creator<ProductInformationVo>() {
                @Override
                public ProductInformationVo createFromParcel(Parcel source) {
                    return new ProductInformationVo(source);
                }

                @Override
                public ProductInformationVo[] newArray(int size) {
                    return new ProductInformationVo[size];
                }
            };
        }

        public static class ImprintInfoVo implements Parcelable {
            /**
             * locationId : inboard_0
             * locationName : inboard
             * locationKey : inboard
             * imprintParam : {"imprint_title":"inboard","imprint_image_size":"134.05968740221X193.01036241548","product_template_object_shape":"mug2","imptintPoints":{"point1":{"x":"178.00000042724608","y":"233.00000012207028"},"point2":{"x":"311.9999996337891","y":"237"},"point3":{"x":"309.9999996337891","y":"428"},"point4":{"x":"180.0000003662109","y":"426.0000001220703"},"curveTop":{"x":"245","y":"432"},"curveBottom":{"x":"241","y":"241"}}}
             * imprintSettings : {"fabric":0,"giftset":0,"combinearea":0,"horizontalmug":0,"combineareadifferentlogo":0,"addtext":1,"addimage":1,"bottomtotoprotate":0,"toptobottomrotate":0}
             * imprintMethod : {"deboss":"0","emboss":"0","embroidery":"0","glass":"0","plain":"1","single_color":"1","wooden":"0"}
             * order : 1
             * defaultImprintMethod : plain
             */

            @SerializedName("locationId")
            private String locationId;
            @SerializedName("locationName")
            private String locationName;
            @SerializedName("locationKey")
            private String locationKey;
            @SerializedName("imprintParam")
            private ImprintParamVo imprintParam;
            @SerializedName("imprintSettings")
            private ImprintSettingsVo imprintSettings;
            @SerializedName("imprintMethod")
            private ImprintMethodVo imprintMethod;
            @SerializedName("order")
            private int order;
            @SerializedName("defaultImprintMethod")
            private String defaultImprintMethod;

            public String getLocationId() {
                return locationId;
            }

            public void setLocationId(String locationId) {
                this.locationId = locationId;
            }

            public String getLocationName() {
                return locationName;
            }

            public void setLocationName(String locationName) {
                this.locationName = locationName;
            }

            public String getLocationKey() {
                return locationKey;
            }

            public void setLocationKey(String locationKey) {
                this.locationKey = locationKey;
            }

            public ImprintParamVo getImprintParam() {
                return imprintParam;
            }

            public void setImprintParam(ImprintParamVo imprintParam) {
                this.imprintParam = imprintParam;
            }

            public ImprintSettingsVo getImprintSettings() {
                return imprintSettings;
            }

            public void setImprintSettings(ImprintSettingsVo imprintSettings) {
                this.imprintSettings = imprintSettings;
            }

            public ImprintMethodVo getImprintMethod() {
                return imprintMethod;
            }

            public void setImprintMethod(ImprintMethodVo imprintMethod) {
                this.imprintMethod = imprintMethod;
            }

            public int getOrder() {
                return order;
            }

            public void setOrder(int order) {
                this.order = order;
            }

            public String getDefaultImprintMethod() {
                return defaultImprintMethod;
            }

            public void setDefaultImprintMethod(String defaultImprintMethod) {
                this.defaultImprintMethod = defaultImprintMethod;
            }

            public static class ImprintParamVo implements Parcelable {
                /**
                 * imprint_title : inboard
                 * imprint_image_size : 134.05968740221X193.01036241548
                 * product_template_object_shape : mug2
                 * imptintPoints : {"point1":{"x":"178.00000042724608","y":"233.00000012207028"},"point2":{"x":"311.9999996337891","y":"237"},"point3":{"x":"309.9999996337891","y":"428"},"point4":{"x":"180.0000003662109","y":"426.0000001220703"},"curveTop":{"x":"245","y":"432"},"curveBottom":{"x":"241","y":"241"}}
                 */

                @SerializedName("imprint_title")
                private String imprintTitle;
                @SerializedName("imprint_image_size")
                private String imprintImageSize;
                @SerializedName("product_template_object_shape")
                private String productTemplateObjectShape;
                @SerializedName("imptintPoints")
                private ImptintPointsVo imptintPoints;

                public String getImprintTitle() {
                    return imprintTitle;
                }

                public void setImprintTitle(String imprintTitle) {
                    this.imprintTitle = imprintTitle;
                }

                public String getImprintImageSize() {
                    return imprintImageSize;
                }

                public void setImprintImageSize(String imprintImageSize) {
                    this.imprintImageSize = imprintImageSize;
                }

                public String getProductTemplateObjectShape() {
                    return productTemplateObjectShape;
                }

                public void setProductTemplateObjectShape(String productTemplateObjectShape) {
                    this.productTemplateObjectShape = productTemplateObjectShape;
                }

                public ImptintPointsVo getImptintPoints() {
                    return imptintPoints;
                }

                public void setImptintPoints(ImptintPointsVo imptintPoints) {
                    this.imptintPoints = imptintPoints;
                }

                public static class ImptintPointsVo implements Parcelable {
                    /**
                     * point1 : {"x":"178.00000042724608","y":"233.00000012207028"}
                     * point2 : {"x":"311.9999996337891","y":"237"}
                     * point3 : {"x":"309.9999996337891","y":"428"}
                     * point4 : {"x":"180.0000003662109","y":"426.0000001220703"}
                     * curveTop : {"x":"245","y":"432"}
                     * curveBottom : {"x":"241","y":"241"}
                     * "radius": 25.495,
                     * "originpoint": {
                     * "x": 210.55,
                     * "y": 35.058023376465
                     * }
                     */

                    @SerializedName("point1")
                    private PointVo point1;
                    @SerializedName("point2")
                    private PointVo point2;
                    @SerializedName("point3")
                    private PointVo point3;
                    @SerializedName("point4")
                    private PointVo point4;
                    @SerializedName("curveTop")
                    private PointVo curveTop;
                    @SerializedName("curveBottom")
                    private PointVo curveBottom;
                    @SerializedName("radius")
                    private String radius;
                    @SerializedName("originpoint")
                    private PointVo circlePoints;

                    public PointVo getPoint1() {
                        return point1;
                    }

                    public Float getRadius() {
                        return Float.parseFloat(radius);
                    }

                    public ImptintPointsVo setRadius(String radius) {
                        this.radius = radius;
                        return this;
                    }

                    public PointVo getCirclePoints() {
                        return circlePoints;
                    }

                    public ImptintPointsVo setCirclePoints(PointVo circlePoints) {
                        this.circlePoints = circlePoints;
                        return this;
                    }

                    public void setPoint1(PointVo point1) {
                        this.point1 = point1;
                    }

                    public PointVo getPoint2() {
                        return point2;
                    }

                    public void setPoint2(PointVo point2) {
                        this.point2 = point2;
                    }

                    public PointVo getPoint3() {
                        return point3;
                    }

                    public void setPoint3(PointVo point3) {
                        this.point3 = point3;
                    }

                    public PointVo getPoint4() {
                        return point4;
                    }

                    public void setPoint4(PointVo point4) {
                        this.point4 = point4;
                    }

                    public PointVo getCurveTop() {
                        return curveTop;
                    }

                    public void setCurveTop(PointVo curveTop) {
                        this.curveTop = curveTop;
                    }

                    public PointVo getCurveBottom() {
                        return curveBottom;
                    }

                    public void setCurveBottom(PointVo curveBottom) {
                        this.curveBottom = curveBottom;
                    }


                    public ImptintPointsVo() {
                    }

                    @Override
                    public int describeContents() {
                        return 0;
                    }

                    @Override
                    public void writeToParcel(Parcel dest, int flags) {
                        dest.writeParcelable(this.point1, flags);
                        dest.writeParcelable(this.point2, flags);
                        dest.writeParcelable(this.point3, flags);
                        dest.writeParcelable(this.point4, flags);
                        dest.writeParcelable(this.curveTop, flags);
                        dest.writeParcelable(this.curveBottom, flags);
                        dest.writeString(this.radius);
                        dest.writeParcelable(this.circlePoints, flags);
                    }

                    protected ImptintPointsVo(Parcel in) {
                        this.point1 = in.readParcelable(PointVo.class.getClassLoader());
                        this.point2 = in.readParcelable(PointVo.class.getClassLoader());
                        this.point3 = in.readParcelable(PointVo.class.getClassLoader());
                        this.point4 = in.readParcelable(PointVo.class.getClassLoader());
                        this.curveTop = in.readParcelable(PointVo.class.getClassLoader());
                        this.curveBottom = in.readParcelable(PointVo.class.getClassLoader());
                        this.radius = in.readString();
                        this.circlePoints = in.readParcelable(PointVo.class.getClassLoader());
                    }

                    public static final Creator<ImptintPointsVo> CREATOR = new Creator<ImptintPointsVo>() {
                        @Override
                        public ImptintPointsVo createFromParcel(Parcel source) {
                            return new ImptintPointsVo(source);
                        }

                        @Override
                        public ImptintPointsVo[] newArray(int size) {
                            return new ImptintPointsVo[size];
                        }
                    };
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeString(this.imprintTitle);
                    dest.writeString(this.imprintImageSize);
                    dest.writeString(this.productTemplateObjectShape);
                    dest.writeParcelable(this.imptintPoints, flags);
                }

                public ImprintParamVo() {
                }

                protected ImprintParamVo(Parcel in) {
                    this.imprintTitle = in.readString();
                    this.imprintImageSize = in.readString();
                    this.productTemplateObjectShape = in.readString();
                    this.imptintPoints = in.readParcelable(ImptintPointsVo.class.getClassLoader());
                }

                public static final Creator<ImprintParamVo> CREATOR = new Creator<ImprintParamVo>() {
                    @Override
                    public ImprintParamVo createFromParcel(Parcel source) {
                        return new ImprintParamVo(source);
                    }

                    @Override
                    public ImprintParamVo[] newArray(int size) {
                        return new ImprintParamVo[size];
                    }
                };
            }

            public static class ImprintSettingsVo implements Parcelable {
                /**
                 * fabric : 0
                 * giftset : 0
                 * combinearea : 0
                 * horizontalmug : 0
                 * combineareadifferentlogo : 0
                 * addtext : 1
                 * addimage : 1
                 * bottomtotoprotate : 0
                 * toptobottomrotate : 0
                 */

                @SerializedName("fabric")
                private int fabric;
                @SerializedName("giftset")
                private int giftset;
                @SerializedName("combinearea")
                private int combinearea;
                @SerializedName("horizontalmug")
                private int horizontalmug;
                @SerializedName("combineareadifferentlogo")
                private int combineareadifferentlogo;
                @SerializedName("addtext")
                private int addtext;
                @SerializedName("addimage")
                private int addimage;
                @SerializedName("bottomtotoprotate")
                private int bottomtotoprotate;
                @SerializedName("toptobottomrotate")
                private int toptobottomrotate;

                public int getFabric() {
                    return fabric;
                }

                public void setFabric(int fabric) {
                    this.fabric = fabric;
                }

                public int getGiftset() {
                    return giftset;
                }

                public void setGiftset(int giftset) {
                    this.giftset = giftset;
                }

                public int getCombinearea() {
                    return combinearea;
                }

                public void setCombinearea(int combinearea) {
                    this.combinearea = combinearea;
                }

                public int getHorizontalmug() {
                    return horizontalmug;
                }

                public void setHorizontalmug(int horizontalmug) {
                    this.horizontalmug = horizontalmug;
                }

                public int getCombineareadifferentlogo() {
                    return combineareadifferentlogo;
                }

                public void setCombineareadifferentlogo(int combineareadifferentlogo) {
                    this.combineareadifferentlogo = combineareadifferentlogo;
                }

                public int getAddtext() {
                    return addtext;
                }

                public void setAddtext(int addtext) {
                    this.addtext = addtext;
                }

                public int getAddimage() {
                    return addimage;
                }

                public void setAddimage(int addimage) {
                    this.addimage = addimage;
                }

                public int getBottomtotoprotate() {
                    return bottomtotoprotate;
                }

                public void setBottomtotoprotate(int bottomtotoprotate) {
                    this.bottomtotoprotate = bottomtotoprotate;
                }

                public int getToptobottomrotate() {
                    return toptobottomrotate;
                }

                public void setToptobottomrotate(int toptobottomrotate) {
                    this.toptobottomrotate = toptobottomrotate;
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeInt(this.fabric);
                    dest.writeInt(this.giftset);
                    dest.writeInt(this.combinearea);
                    dest.writeInt(this.horizontalmug);
                    dest.writeInt(this.combineareadifferentlogo);
                    dest.writeInt(this.addtext);
                    dest.writeInt(this.addimage);
                    dest.writeInt(this.bottomtotoprotate);
                    dest.writeInt(this.toptobottomrotate);
                }

                public ImprintSettingsVo() {
                }

                protected ImprintSettingsVo(Parcel in) {
                    this.fabric = in.readInt();
                    this.giftset = in.readInt();
                    this.combinearea = in.readInt();
                    this.horizontalmug = in.readInt();
                    this.combineareadifferentlogo = in.readInt();
                    this.addtext = in.readInt();
                    this.addimage = in.readInt();
                    this.bottomtotoprotate = in.readInt();
                    this.toptobottomrotate = in.readInt();
                }

                public static final Creator<ImprintSettingsVo> CREATOR = new Creator<ImprintSettingsVo>() {
                    @Override
                    public ImprintSettingsVo createFromParcel(Parcel source) {
                        return new ImprintSettingsVo(source);
                    }

                    @Override
                    public ImprintSettingsVo[] newArray(int size) {
                        return new ImprintSettingsVo[size];
                    }
                };
            }

            public static class ImprintMethodVo implements Parcelable {
                /**
                 * deboss : 0
                 * emboss : 0
                 * embroidery : 0
                 * glass : 0
                 * plain : 1
                 * single_color : 1
                 * leather_engrave: 1
                 * wooden : 0
                 */

                @SerializedName("deboss")
                private String deboss;
                @SerializedName("emboss")
                private String emboss;
                @SerializedName("embroidery")
                private String embroidery;
                @SerializedName("glass")
                private String glass;
                @SerializedName("plain")
                private String plain;
                @SerializedName("single_color")
                private String singleColor;
                @SerializedName("wooden")
                private String wooden;
                @SerializedName("tone_on_tone")
                public String tone_on_tone;
                @SerializedName("leather_engrave")
                public String leather_engrave;
                @SerializedName("engraved")
                public String engraved;


                public String getDeboss() {
                    return deboss;
                }

                public void setDeboss(String deboss) {
                    this.deboss = deboss;
                }

                public String getEmboss() {
                    return emboss;
                }

                public void setEmboss(String emboss) {
                    this.emboss = emboss;
                }

                public String getEmbroidery() {
                    return embroidery;
                }

                public void setEmbroidery(String embroidery) {
                    this.embroidery = embroidery;
                }

                public String getGlass() {
                    return glass;
                }

                public void setGlass(String glass) {
                    this.glass = glass;
                }

                public String getPlain() {
                    return plain;
                }

                public void setPlain(String plain) {
                    this.plain = plain;
                }

                public String getSingleColor() {
                    return singleColor;
                }

                public void setSingleColor(String singleColor) {
                    this.singleColor = singleColor;
                }

                public String getWooden() {
                    return wooden;
                }

                public void setWooden(String wooden) {
                    this.wooden = wooden;
                }

                public String getTone_on_tone() {
                    return tone_on_tone;
                }

                public void setTone_on_tone(String tone_on_tone) {
                    this.tone_on_tone = tone_on_tone;
                }

                public String getLeather_engrave() {
                    return leather_engrave;
                }

                public void setLeather_engrave(String leather_engrave) {
                    this.leather_engrave = leather_engrave;
                }

                public String getEngraved() {
                    return engraved;
                }

                public void setEngraved(String engraved) {
                    this.engraved = engraved;
                }

                public ImprintMethodVo() {
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeString(this.deboss);
                    dest.writeString(this.emboss);
                    dest.writeString(this.embroidery);
                    dest.writeString(this.glass);
                    dest.writeString(this.plain);
                    dest.writeString(this.singleColor);
                    dest.writeString(this.wooden);
                    dest.writeString(this.tone_on_tone);
                    dest.writeString(this.leather_engrave);
                    dest.writeString(this.engraved);
                }

                protected ImprintMethodVo(Parcel in) {
                    this.deboss = in.readString();
                    this.emboss = in.readString();
                    this.embroidery = in.readString();
                    this.glass = in.readString();
                    this.plain = in.readString();
                    this.singleColor = in.readString();
                    this.wooden = in.readString();
                    this.tone_on_tone = in.readString();
                    this.leather_engrave = in.readString();
                    this.engraved = in.readString();
                }

                public static final Creator<ImprintMethodVo> CREATOR = new Creator<ImprintMethodVo>() {
                    @Override
                    public ImprintMethodVo createFromParcel(Parcel source) {
                        return new ImprintMethodVo(source);
                    }

                    @Override
                    public ImprintMethodVo[] newArray(int size) {
                        return new ImprintMethodVo[size];
                    }
                };
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.locationId);
                dest.writeString(this.locationName);
                dest.writeString(this.locationKey);
                dest.writeParcelable(this.imprintParam, flags);
                dest.writeParcelable(this.imprintSettings, flags);
                dest.writeParcelable(this.imprintMethod, flags);
                dest.writeInt(this.order);
                dest.writeString(this.defaultImprintMethod);
            }

            public ImprintInfoVo() {
            }

            protected ImprintInfoVo(Parcel in) {
                this.locationId = in.readString();
                this.locationName = in.readString();
                this.locationKey = in.readString();
                this.imprintParam = in.readParcelable(ImprintParamVo.class.getClassLoader());
                this.imprintSettings = in.readParcelable(ImprintSettingsVo.class.getClassLoader());
                this.imprintMethod = in.readParcelable(ImprintMethodVo.class.getClassLoader());
                this.order = in.readInt();
                this.defaultImprintMethod = in.readString();
            }

            public static final Creator<ImprintInfoVo> CREATOR = new Creator<ImprintInfoVo>() {
                @Override
                public ImprintInfoVo createFromParcel(Parcel source) {
                    return new ImprintInfoVo(source);
                }

                @Override
                public ImprintInfoVo[] newArray(int size) {
                    return new ImprintInfoVo[size];
                }
            };
        }

        public static class SidesVo implements Parcelable {
            /**
             * locationKey : inboard
             * side_image : [{"colorId":17,"colorName":"Clear","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-100x100.jpg"},{"colorId":24,"colorName":"Graphite","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175430-100x100.jpg"},{"colorId":10,"colorName":"Green","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175431-100x100.jpg"},{"colorId":7,"colorName":"Red","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14289175432-100x100.jpg"},{"colorId":8,"colorName":"Blue","productImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-500x500.jpg","thumbImage":"http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/14295251740-100x100.jpg"}]
             */

            @SerializedName("locationKey")
            private String locationKey;
            @SerializedName("side_image")
            private List<SideImageVo> sideImage;

            public String getLocationKey() {
                return locationKey;
            }

            public void setLocationKey(String locationKey) {
                this.locationKey = locationKey;
            }

            public List<SideImageVo> getSideImage() {
                return sideImage;
            }

            public void setSideImage(List<SideImageVo> sideImage) {
                this.sideImage = sideImage;
            }

            public static class SideImageVo implements Parcelable {

                /**
                 * colorId : 17
                 * colorName : Clear
                 * productImage : http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-500x500.jpg
                 * thumbImage : http://172.16.116.31/virtual/web/Virtual/54607c1317207c5f03d63af1/55b85008204e7852688b516e/ProductMaster/inboard/TSB7_WHITE-100x100.jpg
                 */

                @SerializedName("colorId")
                private String colorId;
                @SerializedName("colorName")
                private String colorName;
                @SerializedName("productImage")
                private String productImage;
                @SerializedName("thumbImage")
                private String thumbImage;
                @SerializedName("is_default")
                private String isDefault;

                public String getIsDefault() {
                    return isDefault;
                }

                public SideImageVo setIsDefault(String isDefault) {
                    this.isDefault = isDefault;
                    return this;
                }

                public String getColorId() {
                    return colorId;
                }

                public void setColorId(String colorId) {
                    this.colorId = colorId;
                }

                public String getColorName() {
                    return colorName;
                }

                public void setColorName(String colorName) {
                    this.colorName = colorName;
                }

                public String getProductImage() {
                    return productImage;
                }

                public void setProductImage(String productImage) {
                    this.productImage = productImage;
                }

                public String getThumbImage() {
                    return thumbImage;
                }

                public void setThumbImage(String thumbImage) {
                    this.thumbImage = thumbImage;
                }

                public SideImageVo() {
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel dest, int flags) {
                    dest.writeString(this.colorId);
                    dest.writeString(this.colorName);
                    dest.writeString(this.productImage);
                    dest.writeString(this.thumbImage);
                    dest.writeString(this.isDefault);
                }

                protected SideImageVo(Parcel in) {
                    this.colorId = in.readString();
                    this.colorName = in.readString();
                    this.productImage = in.readString();
                    this.thumbImage = in.readString();
                    this.isDefault = in.readString();
                }

                public static final Creator<SideImageVo> CREATOR = new Creator<SideImageVo>() {
                    @Override
                    public SideImageVo createFromParcel(Parcel source) {
                        return new SideImageVo(source);
                    }

                    @Override
                    public SideImageVo[] newArray(int size) {
                        return new SideImageVo[size];
                    }
                };
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.locationKey);
                dest.writeList(this.sideImage);
            }

            public SidesVo() {
            }

            protected SidesVo(Parcel in) {
                this.locationKey = in.readString();
                this.sideImage = new ArrayList<SideImageVo>();
                in.readList(this.sideImage, SideImageVo.class.getClassLoader());
            }

            public static final Creator<SidesVo> CREATOR = new Creator<SidesVo>() {
                @Override
                public SidesVo createFromParcel(Parcel source) {
                    return new SidesVo(source);
                }

                @Override
                public SidesVo[] newArray(int size) {
                    return new SidesVo[size];
                }
            };
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeParcelable(this.basicInformation, flags);
            dest.writeParcelable(this.productInformation, flags);
            dest.writeList(this.imprintInfo);
            dest.writeList(this.sides);
        }

        public DataVo() {
        }

        protected DataVo(Parcel in) {
            this.basicInformation = in.readParcelable(BasicInformationVo.class.getClassLoader());
            this.productInformation = in.readParcelable(ProductInformationVo.class.getClassLoader());
            this.imprintInfo = new ArrayList<ImprintInfoVo>();
            in.readList(this.imprintInfo, ImprintInfoVo.class.getClassLoader());
            this.sides = new ArrayList<SidesVo>();
            in.readList(this.sides, SidesVo.class.getClassLoader());
        }

        public static final Parcelable.Creator<DataVo> CREATOR = new Parcelable.Creator<DataVo>() {
            @Override
            public DataVo createFromParcel(Parcel source) {
                return new DataVo(source);
            }

            @Override
            public DataVo[] newArray(int size) {
                return new DataVo[size];
            }
        };
    }
}
