package com.ob.vmc.vmcproduct.fragment;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;


public class BaseContainerFragment extends Fragment {

    public void replaceFragment(FragmentTransaction transaction, Fragment fragment, int frameRsId, boolean addToBackStack, String tag) {
        //FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        if (addToBackStack) {
            transaction.addToBackStack(null);
        }

        transaction.replace(frameRsId, fragment,tag);
        transaction.commit();
        getChildFragmentManager().executePendingTransactions();
    }


    public void addFragment(FragmentTransaction transaction, Fragment fragment, int frameRsId, boolean addToBackStack, String tag) {
        //FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        if (addToBackStack) {
            transaction.addToBackStack(null);
        }

        transaction.add(frameRsId, fragment,tag);
        transaction.commit();
        getChildFragmentManager().executePendingTransactions();
    }

    public boolean popFragment() {
        boolean isPop = false;
        if (getChildFragmentManager().getBackStackEntryCount() > 0) {
            isPop = true;
            getChildFragmentManager().popBackStack( getChildFragmentManager().getBackStackEntryAt(0).getId(), 0);
            getChildFragmentManager().popBackStack();
        }
        return isPop;
    }

}