package com.ob.vmc.vmcproduct.model.httpmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

/**
 * Created by khyati5403 on 1/2/2017.
 */

public class GetSupplierDetailVo extends BaseVo {
    /**
     * status : 1
     * message : success
     * data : {"supplierDetail":{"supplierName":"This Promo Works","configurationOptions":{"addtext":1,"addimage":1,"addclipart":0,"logoeverything":0,"removewhite":1,"removeblack":1,"removewhitedefault":1,"zoom":1,"download":1,"mail":1,"flyer":0,"video":0,"virtuallibrary":0,"loginsignup":0,"imprintcolor":0,"pmscolor":1,"wraparound":0,"imprintmethods":0,"transparentproductimage":1,"instanceProofing":0,"rotate":"radio","customswatches":0,"showvirtualwithoutimprint":0,"showwalkthrough":0,"showdenyusertoupload":0,"donotoverlapwork":0},"isSyncProductsWithCron":false,"supplierCustomCss":"virtual_tpw.css","supplierLogoOnProductUrl":"distributor.officebeacon.com/app_dev.php/en_us/logo-on-product/{sequenceid}/{productColor}","supplierLogoeverythingUrl":"www.google.com","supplierType":"Association","supplierVersion":"v3","supplierVirtualHtml":"<a class=\"opn obv-modale-open virtual-button\" data-toggle=\"modal\" href=\"javascript:void(0);\" data-target=\".obvirtual-modal-div\" onclick=\"javascript:openVirtualTool()\"><i class=\"fa\"><\/i>Virtual<\/a><div id=\"virtual_bg_site\" class=\"bg_site\"><div id=\"uploadModal\" data-backdrop=\"static\" class=\"modal fade obvirtual-modal-div\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myLargeModalLabel\" data-keyboard=\"false\"><\/div><\/div>","supportedCultures":"en_us"}}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo {
        /**
         * supplierDetail : {"supplierName":"This Promo Works","configurationOptions":{"addtext":1,"addimage":1,"addclipart":0,"logoeverything":0,"removewhite":1,"removeblack":1,"removewhitedefault":1,"zoom":1,"download":1,"mail":1,"flyer":0,"video":0,"virtuallibrary":0,"loginsignup":0,"imprintcolor":0,"pmscolor":1,"wraparound":0,"imprintmethods":0,"transparentproductimage":1,"instanceProofing":0,"rotate":"radio","customswatches":0,"showvirtualwithoutimprint":0,"showwalkthrough":0,"showdenyusertoupload":0,"donotoverlapwork":0},"isSyncProductsWithCron":false,"supplierCustomCss":"virtual_tpw.css","supplierLogoOnProductUrl":"distributor.officebeacon.com/app_dev.php/en_us/logo-on-product/{sequenceid}/{productColor}","supplierLogoeverythingUrl":"www.google.com","supplierType":"Association","supplierVersion":"v3","supplierVirtualHtml":"<a class=\"opn obv-modale-open virtual-button\" data-toggle=\"modal\" href=\"javascript:void(0);\" data-target=\".obvirtual-modal-div\" onclick=\"javascript:openVirtualTool()\"><i class=\"fa\"><\/i>Virtual<\/a><div id=\"virtual_bg_site\" class=\"bg_site\"><div id=\"uploadModal\" data-backdrop=\"static\" class=\"modal fade obvirtual-modal-div\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myLargeModalLabel\" data-keyboard=\"false\"><\/div><\/div>","supportedCultures":"en_us"}
         */

        @SerializedName("supplierDetail")
        private SupplierDetailVo supplierDetail;

        public SupplierDetailVo getSupplierDetail() {
            return supplierDetail;
        }

        public void setSupplierDetail(SupplierDetailVo supplierDetail) {
            this.supplierDetail = supplierDetail;
        }

        public static class SupplierDetailVo implements Parcelable {
            /**
             * supplierName : This Promo Works
             * configurationOptions : {"addtext":1,"addimage":1,"addclipart":0,"logoeverything":0,"removewhite":1,"removeblack":1,"removewhitedefault":1,"zoom":1,"download":1,"mail":1,"flyer":0,"video":0,"virtuallibrary":0,"loginsignup":0,"imprintcolor":0,"pmscolor":1,"wraparound":0,"imprintmethods":0,"transparentproductimage":1,"instanceProofing":0,"rotate":"radio","customswatches":0,"showvirtualwithoutimprint":0,"showwalkthrough":0,"showdenyusertoupload":0,"donotoverlapwork":0}
             * isSyncProductsWithCron : false
             * supplierCustomCss : virtual_tpw.css
             * supplierLogoOnProductUrl : distributor.officebeacon.com/app_dev.php/en_us/logo-on-product/{sequenceid}/{productColor}
             * supplierLogoeverythingUrl : www.google.com
             * supplierType : Association
             * supplierVersion : v3
             * supplierVirtualHtml : <a class="opn obv-modale-open virtual-button" data-toggle="modal" href="javascript:void(0);" data-target=".obvirtual-modal-div" onclick="javascript:openVirtualTool()"><i class="fa"></i>Virtual</a><div id="virtual_bg_site" class="bg_site"><div id="uploadModal" data-backdrop="static" class="modal fade obvirtual-modal-div" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" data-keyboard="false"></div></div>
             * supportedCultures : en_us
             */

            @SerializedName("supplierName")
            private String supplierName;
            @SerializedName("configurationOptions")
            private ConfigurationOptionsVo configurationOptions;
            @SerializedName("isSyncProductsWithCron")
            private boolean isSyncProductsWithCron;
            @SerializedName("supplierCustomCss")
            private String supplierCustomCss;
            @SerializedName("supplierLogoOnProductUrl")
            private String supplierLogoOnProductUrl;
            @SerializedName("supplierLogoeverythingUrl")
            private String supplierLogoeverythingUrl;
            @SerializedName("supplierType")
            private String supplierType;
            @SerializedName("supplierVersion")
            private String supplierVersion;
            @SerializedName("supplierVirtualHtml")
            private String supplierVirtualHtml;
            @SerializedName("supportedCultures")
            private String supportedCultures;

            public String getSupplierName() {
                return supplierName;
            }

            public void setSupplierName(String supplierName) {
                this.supplierName = supplierName;
            }

            public ConfigurationOptionsVo getConfigurationOptions() {
                return configurationOptions;
            }

            public void setConfigurationOptions(ConfigurationOptionsVo configurationOptions) {
                this.configurationOptions = configurationOptions;
            }

            public boolean isIsSyncProductsWithCron() {
                return isSyncProductsWithCron;
            }

            public void setIsSyncProductsWithCron(boolean isSyncProductsWithCron) {
                this.isSyncProductsWithCron = isSyncProductsWithCron;
            }

            public String getSupplierCustomCss() {
                return supplierCustomCss;
            }

            public void setSupplierCustomCss(String supplierCustomCss) {
                this.supplierCustomCss = supplierCustomCss;
            }

            public String getSupplierLogoOnProductUrl() {
                return supplierLogoOnProductUrl;
            }

            public void setSupplierLogoOnProductUrl(String supplierLogoOnProductUrl) {
                this.supplierLogoOnProductUrl = supplierLogoOnProductUrl;
            }

            public String getSupplierLogoeverythingUrl() {
                return supplierLogoeverythingUrl;
            }

            public void setSupplierLogoeverythingUrl(String supplierLogoeverythingUrl) {
                this.supplierLogoeverythingUrl = supplierLogoeverythingUrl;
            }

            public String getSupplierType() {
                return supplierType;
            }

            public void setSupplierType(String supplierType) {
                this.supplierType = supplierType;
            }

            public String getSupplierVersion() {
                return supplierVersion;
            }

            public void setSupplierVersion(String supplierVersion) {
                this.supplierVersion = supplierVersion;
            }

            public String getSupplierVirtualHtml() {
                return supplierVirtualHtml;
            }

            public void setSupplierVirtualHtml(String supplierVirtualHtml) {
                this.supplierVirtualHtml = supplierVirtualHtml;
            }

            public String getSupportedCultures() {
                return supportedCultures;
            }

            public void setSupportedCultures(String supportedCultures) {
                this.supportedCultures = supportedCultures;
            }

            public static class ConfigurationOptionsVo implements Parcelable {
                /**
                 * addtext : 1
                 * addimage : 1
                 * addclipart : 0
                 * logoeverything : 0
                 * removewhite : 1
                 * removeblack : 1
                 * removewhitedefault : 1
                 * zoom : 1
                 * download : 1
                 * mail : 1
                 * flyer : 0
                 * video : 0
                 * virtuallibrary : 0
                 * loginsignup : 0
                 * imprintcolor : 0
                 * pmscolor : 1
                 * wraparound : 0
                 * imprintmethods : 0
                 * transparentproductimage : 1
                 * instanceProofing : 0
                 * rotate : radio
                 * customswatches : 0
                 * showvirtualwithoutimprint : 0
                 * showwalkthrough : 0
                 * showdenyusertoupload : 0
                 * donotoverlapwork : 0
                 */

                @SerializedName("addtext")
                private int addtext;
                @SerializedName("addimage")
                private int addimage;
                @SerializedName("addclipart")
                private int addclipart;
                @SerializedName("logoeverything")
                private int logoeverything;
                @SerializedName("removewhite")
                private int removewhite;
                @SerializedName("removeblack")
                private int removeblack;
                @SerializedName("removewhitedefault")
                private int removewhitedefault;
                @SerializedName("zoom")
                private int zoom;
                @SerializedName("download")
                private int download;
                @SerializedName("mail")
                private int mail;
                @SerializedName("flyer")
                private int flyer;
                @SerializedName("video")
                private int video;
                @SerializedName("virtuallibrary")
                private int virtuallibrary;
                @SerializedName("loginsignup")
                private int loginsignup;
                @SerializedName("imprintcolor")
                private int imprintcolor;
                @SerializedName("pmscolor")
                private int pmscolor;
                @SerializedName("wraparound")
                private int wraparound;
                @SerializedName("imprintmethods")
                private int imprintmethods;
                @SerializedName("transparentproductimage")
                private int transparentproductimage;
                @SerializedName("instanceProofing")
                private int instanceProofing;
                @SerializedName("rotate")
                private String rotate;
                @SerializedName("customswatches")
                private int customswatches;
                @SerializedName("showvirtualwithoutimprint")
                private int showvirtualwithoutimprint;
                @SerializedName("showwalkthrough")
                private int showwalkthrough;
                @SerializedName("showdenyusertoupload")
                private int showdenyusertoupload;
                @SerializedName("donotoverlapwork")
                private int donotoverlapwork;

                protected ConfigurationOptionsVo(Parcel in) {
                    addtext = in.readInt();
                    addimage = in.readInt();
                    addclipart = in.readInt();
                    logoeverything = in.readInt();
                    removewhite = in.readInt();
                    removeblack = in.readInt();
                    removewhitedefault = in.readInt();
                    zoom = in.readInt();
                    download = in.readInt();
                    mail = in.readInt();
                    flyer = in.readInt();
                    video = in.readInt();
                    virtuallibrary = in.readInt();
                    loginsignup = in.readInt();
                    imprintcolor = in.readInt();
                    pmscolor = in.readInt();
                    wraparound = in.readInt();
                    imprintmethods = in.readInt();
                    transparentproductimage = in.readInt();
                    instanceProofing = in.readInt();
                    rotate = in.readString();
                    customswatches = in.readInt();
                    showvirtualwithoutimprint = in.readInt();
                    showwalkthrough = in.readInt();
                    showdenyusertoupload = in.readInt();
                    donotoverlapwork = in.readInt();
                }

                public static final Creator<ConfigurationOptionsVo> CREATOR = new Creator<ConfigurationOptionsVo>() {
                    @Override
                    public ConfigurationOptionsVo createFromParcel(Parcel in) {
                        return new ConfigurationOptionsVo(in);
                    }

                    @Override
                    public ConfigurationOptionsVo[] newArray(int size) {
                        return new ConfigurationOptionsVo[size];
                    }
                };

                public int getAddtext() {
                    return addtext;
                }

                public void setAddtext(int addtext) {
                    this.addtext = addtext;
                }

                public int getAddimage() {
                    return addimage;
                }

                public void setAddimage(int addimage) {
                    this.addimage = addimage;
                }

                public int getAddclipart() {
                    return addclipart;
                }

                public void setAddclipart(int addclipart) {
                    this.addclipart = addclipart;
                }

                public int getLogoeverything() {
                    return logoeverything;
                }

                public void setLogoeverything(int logoeverything) {
                    this.logoeverything = logoeverything;
                }

                public int getRemovewhite() {
                    return removewhite;
                }

                public void setRemovewhite(int removewhite) {
                    this.removewhite = removewhite;
                }

                public int getRemoveblack() {
                    return removeblack;
                }

                public void setRemoveblack(int removeblack) {
                    this.removeblack = removeblack;
                }

                public int getRemovewhitedefault() {
                    return removewhitedefault;
                }

                public void setRemovewhitedefault(int removewhitedefault) {
                    this.removewhitedefault = removewhitedefault;
                }

                public int getZoom() {
                    return zoom;
                }

                public void setZoom(int zoom) {
                    this.zoom = zoom;
                }

                public int getDownload() {
                    return download;
                }

                public void setDownload(int download) {
                    this.download = download;
                }

                public int getMail() {
                    return mail;
                }

                public void setMail(int mail) {
                    this.mail = mail;
                }

                public int getFlyer() {
                    return flyer;
                }

                public void setFlyer(int flyer) {
                    this.flyer = flyer;
                }

                public int getVideo() {
                    return video;
                }

                public void setVideo(int video) {
                    this.video = video;
                }

                public int getVirtuallibrary() {
                    return virtuallibrary;
                }

                public void setVirtuallibrary(int virtuallibrary) {
                    this.virtuallibrary = virtuallibrary;
                }

                public int getLoginsignup() {
                    return loginsignup;
                }

                public void setLoginsignup(int loginsignup) {
                    this.loginsignup = loginsignup;
                }

                public int getImprintcolor() {
                    return imprintcolor;
                }

                public void setImprintcolor(int imprintcolor) {
                    this.imprintcolor = imprintcolor;
                }

                public int getPmscolor() {
                    return pmscolor;
                }

                public void setPmscolor(int pmscolor) {
                    this.pmscolor = pmscolor;
                }

                public int getWraparound() {
                    return wraparound;
                }

                public void setWraparound(int wraparound) {
                    this.wraparound = wraparound;
                }

                public int getImprintmethods() {
                    return imprintmethods;
                }

                public void setImprintmethods(int imprintmethods) {
                    this.imprintmethods = imprintmethods;
                }

                public int getTransparentproductimage() {
                    return transparentproductimage;
                }

                public void setTransparentproductimage(int transparentproductimage) {
                    this.transparentproductimage = transparentproductimage;
                }

                public int getInstanceProofing() {
                    return instanceProofing;
                }

                public void setInstanceProofing(int instanceProofing) {
                    this.instanceProofing = instanceProofing;
                }

                public String getRotate() {
                    return rotate;
                }

                public void setRotate(String rotate) {
                    this.rotate = rotate;
                }

                public int getCustomswatches() {
                    return customswatches;
                }

                public void setCustomswatches(int customswatches) {
                    this.customswatches = customswatches;
                }

                public int getShowvirtualwithoutimprint() {
                    return showvirtualwithoutimprint;
                }

                public void setShowvirtualwithoutimprint(int showvirtualwithoutimprint) {
                    this.showvirtualwithoutimprint = showvirtualwithoutimprint;
                }

                public int getShowwalkthrough() {
                    return showwalkthrough;
                }

                public void setShowwalkthrough(int showwalkthrough) {
                    this.showwalkthrough = showwalkthrough;
                }

                public int getShowdenyusertoupload() {
                    return showdenyusertoupload;
                }

                public void setShowdenyusertoupload(int showdenyusertoupload) {
                    this.showdenyusertoupload = showdenyusertoupload;
                }

                public int getDonotoverlapwork() {
                    return donotoverlapwork;
                }

                public void setDonotoverlapwork(int donotoverlapwork) {
                    this.donotoverlapwork = donotoverlapwork;
                }

                @Override
                public int describeContents() {
                    return 0;
                }

                @Override
                public void writeToParcel(Parcel parcel, int i) {
                    parcel.writeInt(addtext);
                    parcel.writeInt(addimage);
                    parcel.writeInt(addclipart);
                    parcel.writeInt(logoeverything);
                    parcel.writeInt(removewhite);
                    parcel.writeInt(removeblack);
                    parcel.writeInt(removewhitedefault);
                    parcel.writeInt(zoom);
                    parcel.writeInt(download);
                    parcel.writeInt(mail);
                    parcel.writeInt(flyer);
                    parcel.writeInt(video);
                    parcel.writeInt(virtuallibrary);
                    parcel.writeInt(loginsignup);
                    parcel.writeInt(imprintcolor);
                    parcel.writeInt(pmscolor);
                    parcel.writeInt(wraparound);
                    parcel.writeInt(imprintmethods);
                    parcel.writeInt(transparentproductimage);
                    parcel.writeInt(instanceProofing);
                    parcel.writeString(rotate);
                    parcel.writeInt(customswatches);
                    parcel.writeInt(showvirtualwithoutimprint);
                    parcel.writeInt(showwalkthrough);
                    parcel.writeInt(showdenyusertoupload);
                    parcel.writeInt(donotoverlapwork);
                }
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.supplierName);
                dest.writeParcelable(this.configurationOptions, flags);
                dest.writeByte(this.isSyncProductsWithCron ? (byte) 1 : (byte) 0);
                dest.writeString(this.supplierCustomCss);
                dest.writeString(this.supplierLogoOnProductUrl);
                dest.writeString(this.supplierLogoeverythingUrl);
                dest.writeString(this.supplierType);
                dest.writeString(this.supplierVersion);
                dest.writeString(this.supplierVirtualHtml);
                dest.writeString(this.supportedCultures);
            }

            public SupplierDetailVo() {
            }

            protected SupplierDetailVo(Parcel in) {
                this.supplierName = in.readString();
                this.configurationOptions = in.readParcelable(ConfigurationOptionsVo.class.getClassLoader());
                this.isSyncProductsWithCron = in.readByte() != 0;
                this.supplierCustomCss = in.readString();
                this.supplierLogoOnProductUrl = in.readString();
                this.supplierLogoeverythingUrl = in.readString();
                this.supplierType = in.readString();
                this.supplierVersion = in.readString();
                this.supplierVirtualHtml = in.readString();
                this.supportedCultures = in.readString();
            }

            public static final Parcelable.Creator<SupplierDetailVo> CREATOR = new Parcelable.Creator<SupplierDetailVo>() {
                @Override
                public SupplierDetailVo createFromParcel(Parcel source) {
                    return new SupplierDetailVo(source);
                }

                @Override
                public SupplierDetailVo[] newArray(int size) {
                    return new SupplierDetailVo[size];
                }
            };
        }
    }
}
