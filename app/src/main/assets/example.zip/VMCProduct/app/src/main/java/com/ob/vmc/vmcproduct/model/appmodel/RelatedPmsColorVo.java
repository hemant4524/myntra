package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

import java.util.List;

/**
 * Created by khyati5403 on 12/13/2016.
 */

public class RelatedPmsColorVo extends BaseVo implements Parcelable {


    /**
     * data : {"count":53,"pmshexcolor":[{"pms":"7527 C","hex":"D6D2C4"},{"pms":"7604 C","hex":"E4D5D3"},{"pms":"7605 C","hex":"E1BBB4"},{"pms":"7611 C","hex":"DDBCB0"},{"pms":"196 C","hex":"ECC7CD"},{"pms":"7632 C","hex":"D6C9CA"},{"pms":"677 C","hex":"E5CEDB"},{"pms":"678 C","hex":"E3C8D8"},{"pms":"679 C","hex":"DEBED2"},{"pms":"684 C","hex":"E4C6D4"},{"pms":"685 C","hex":"DCB6C9"},{"pms":"510 C","hex":"EBBECB"},{"pms":"7429 C","hex":"E2BCCB"},{"pms":"691 C","hex":"E9CDD0"},{"pms":"692 C","hex":"E4BEC3"},{"pms":"503 C","hex":"E9C4C7"},{"pms":"502 C","hex":"E5BAC1"},{"pms":"5035 C","hex":"DFC2C3"},{"pms":"5025 C","hex":"DBB7BB"},{"pms":"524 C","hex":"D5C2D8"},{"pms":"5245 C","hex":"DBCDD3"},{"pms":"5235 C","hex":"D0BEC7"},{"pms":"5175 C","hex":"D8C8D1"},{"pms":"5165 C","hex":"D3C0CD"},{"pms":"256 C","hex":"D6BFDD"},{"pms":"665 C","hex":"C6BCD0"},{"pms":"5315 C","hex":"D8D7DF"},{"pms":"5305 C","hex":"C6C4D2"},{"pms":"538 C","hex":"C5CFDA"},{"pms":"5455 C","hex":"BFCED6"},{"pms":"5595 C","hex":"BFCEC2"},{"pms":"5527 C","hex":"BCC9C5"},{"pms":"621 C","hex":"D1E0D7"},{"pms":"622 C","hex":"B7CDC2"},{"pms":"7485 C","hex":"D0DEBB"},{"pms":"5807 C","hex":"D0D1AB"},{"pms":"7500 C","hex":"DFD1A7"},{"pms":"4685 C","hex":"E0C6AD"},{"pms":"4755 C","hex":"D7C4B7"},{"pms":"482 C","hex":"DBC8B6"},{"pms":"7534 C","hex":"D1CCBD"},{"pms":"427 C","hex":"D0D3D4"},{"pms":"428 C","hex":"C1C6C8"},{"pms":"420 C","hex":"C7C9C7"},{"pms":"441 C","hex":"BEC6C4"},{"pms":"400 C","hex":"C4BFB6"},{"pms":"406 C","hex":"C4BCB7"},{"pms":"434 C","hex":"D0C4C5"},{"pms":"Warm Gray 1 C","hex":"D7D2CB"},{"pms":"Warm Gray 2 C","hex":"CBC4BC"},{"pms":"Cool Gray 1 C","hex":"D9D9D6"},{"pms":"Cool Gray 2 C","hex":"D0D0CE"},{"pms":"Cool Gray 3 C","hex":"C8C9C7"}]}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo implements Parcelable {
        /**
         * count : 53
         * pmshexcolor : [{"pms":"7527 C","hex":"D6D2C4"},{"pms":"7604 C","hex":"E4D5D3"},{"pms":"7605 C","hex":"E1BBB4"},{"pms":"7611 C","hex":"DDBCB0"},{"pms":"196 C","hex":"ECC7CD"},{"pms":"7632 C","hex":"D6C9CA"},{"pms":"677 C","hex":"E5CEDB"},{"pms":"678 C","hex":"E3C8D8"},{"pms":"679 C","hex":"DEBED2"},{"pms":"684 C","hex":"E4C6D4"},{"pms":"685 C","hex":"DCB6C9"},{"pms":"510 C","hex":"EBBECB"},{"pms":"7429 C","hex":"E2BCCB"},{"pms":"691 C","hex":"E9CDD0"},{"pms":"692 C","hex":"E4BEC3"},{"pms":"503 C","hex":"E9C4C7"},{"pms":"502 C","hex":"E5BAC1"},{"pms":"5035 C","hex":"DFC2C3"},{"pms":"5025 C","hex":"DBB7BB"},{"pms":"524 C","hex":"D5C2D8"},{"pms":"5245 C","hex":"DBCDD3"},{"pms":"5235 C","hex":"D0BEC7"},{"pms":"5175 C","hex":"D8C8D1"},{"pms":"5165 C","hex":"D3C0CD"},{"pms":"256 C","hex":"D6BFDD"},{"pms":"665 C","hex":"C6BCD0"},{"pms":"5315 C","hex":"D8D7DF"},{"pms":"5305 C","hex":"C6C4D2"},{"pms":"538 C","hex":"C5CFDA"},{"pms":"5455 C","hex":"BFCED6"},{"pms":"5595 C","hex":"BFCEC2"},{"pms":"5527 C","hex":"BCC9C5"},{"pms":"621 C","hex":"D1E0D7"},{"pms":"622 C","hex":"B7CDC2"},{"pms":"7485 C","hex":"D0DEBB"},{"pms":"5807 C","hex":"D0D1AB"},{"pms":"7500 C","hex":"DFD1A7"},{"pms":"4685 C","hex":"E0C6AD"},{"pms":"4755 C","hex":"D7C4B7"},{"pms":"482 C","hex":"DBC8B6"},{"pms":"7534 C","hex":"D1CCBD"},{"pms":"427 C","hex":"D0D3D4"},{"pms":"428 C","hex":"C1C6C8"},{"pms":"420 C","hex":"C7C9C7"},{"pms":"441 C","hex":"BEC6C4"},{"pms":"400 C","hex":"C4BFB6"},{"pms":"406 C","hex":"C4BCB7"},{"pms":"434 C","hex":"D0C4C5"},{"pms":"Warm Gray 1 C","hex":"D7D2CB"},{"pms":"Warm Gray 2 C","hex":"CBC4BC"},{"pms":"Cool Gray 1 C","hex":"D9D9D6"},{"pms":"Cool Gray 2 C","hex":"D0D0CE"},{"pms":"Cool Gray 3 C","hex":"C8C9C7"}]
         */

        @SerializedName("count")
        private int count;
        @SerializedName("pmshexcolor")
        private List<PmshexcolorVo> pmshexcolor;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public List<PmshexcolorVo> getPmshexcolor() {
            return pmshexcolor;
        }

        public void setPmshexcolor(List<PmshexcolorVo> pmshexcolor) {
            this.pmshexcolor = pmshexcolor;
        }


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.count);
            dest.writeTypedList(this.pmshexcolor);
        }

        public DataVo() {
        }

        protected DataVo(Parcel in) {
            this.count = in.readInt();
            this.pmshexcolor = in.createTypedArrayList(PmshexcolorVo.CREATOR);
        }

        public static final Parcelable.Creator<DataVo> CREATOR = new Parcelable.Creator<DataVo>() {
            @Override
            public DataVo createFromParcel(Parcel source) {
                return new DataVo(source);
            }

            @Override
            public DataVo[] newArray(int size) {
                return new DataVo[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, flags);
    }

    public RelatedPmsColorVo() {
    }

    protected RelatedPmsColorVo(Parcel in) {
        this.data = in.readParcelable(DataVo.class.getClassLoader());
    }

    public static final Parcelable.Creator<RelatedPmsColorVo> CREATOR = new Parcelable.Creator<RelatedPmsColorVo>() {
        @Override
        public RelatedPmsColorVo createFromParcel(Parcel source) {
            return new RelatedPmsColorVo(source);
        }

        @Override
        public RelatedPmsColorVo[] newArray(int size) {
            return new RelatedPmsColorVo[size];
        }
    };
}
