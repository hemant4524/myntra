package com.ob.vmc.vmcproduct.utils;

/**
 * Created by Ishan4452 on 2/26/2016.
 */
public class ImprintAreaType {

  public final static String  RECTANGLE="rect";
    public final static String  CIRCLE="circle";
    public final static String  CYLINDER="";
    public final static String  CUSTOM="custome";
    public final static String  MUG_2="mug2";
}
