package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;
import com.ob.vmc.vmcproduct.utils.DensityUtils;

/**
 * Created by khyati5403 on 12/6/2016.
 */

public class EmbossEffectHandler {

    private Context mContext;

    public EmbossEffectHandler(Context mContext) {
        this.mContext=mContext;
    }

    public Bitmap executeProcess(Bitmap srcBitmap, boolean isRequireRemoveWhite, int opacity) {

        try {

            if (isRequireRemoveWhite) {
                int[] intArray = new int[srcBitmap.getWidth() * srcBitmap.getHeight()];
                srcBitmap.getPixels(intArray, 0, srcBitmap.getWidth(), 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight());

                for (int x = 0; x < intArray.length; x++) {
                    intArray[x]=BitmapProcessing.removeWhite(intArray[x]);
                }
                srcBitmap = Bitmap.createBitmap(intArray, srcBitmap.getWidth(), srcBitmap.getHeight(), srcBitmap.getConfig());
            }

            int color = Color.parseColor("#C8000000");

            Bitmap originalBitmap = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(originalBitmap);

            ColorFilter colorFilter = new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN);
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColorFilter(colorFilter);

            int trasPixelPlus= DensityUtils.dip2px(mContext,2);
            canvas.drawBitmap(srcBitmap, trasPixelPlus,trasPixelPlus, paint);

    /*        Paint paintTop = new Paint(Paint.ANTI_ALIAS_FLAG);
            ColorFilter colorFilterTop = new PorterDuffColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_IN);

            paintTop.setColorFilter(colorFilterTop);*/
            int trasPixelMinus= DensityUtils.dip2px(mContext,-1);
            canvas.drawBitmap(originalBitmap, trasPixelMinus,trasPixelMinus, paint);

            Paint paintNew = new Paint(Paint.ANTI_ALIAS_FLAG);
            canvas.drawBitmap(srcBitmap, 0,0, paintNew);



            /*
            if (srcBitmap != null) {
                srcBitmap = BitmapProcessing.doEmboss(srcBitmap, isRequireRemoveWhite);
            } else {
                CustomLogHandler.printVerbose(TAG, "Bitmap null Found");
            }*/

            return originalBitmap;
        } catch (Exception e) {

            e.printStackTrace();
        }
        return srcBitmap;

    }
}
