package com.ob.vmc.vmcproduct.httpcommon;

import android.os.AsyncTask;

import com.andoblib.customexception.CustomException;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;

import java.io.Reader;

/*This Aync class is decide which ResponseParcer Method call, depend on request code and return valid response*/
class AsycResponseParcer extends AsyncTask<Void, Void, BaseVo> {

        private Reader reader;
        private int requestCode;
        private OnCompleteListener onCompleteListener;


        public AsycResponseParcer(Reader reader, int mRequestCode, OnCompleteListener onCompleteListener) {
            this.reader = reader;
            this.requestCode = mRequestCode;
            this.onCompleteListener=onCompleteListener;
        }


        @Override
        protected BaseVo doInBackground(Void... params) {
            BaseVo baseVo = null;
            try {

                if (requestCode == WSRequestCodeConstant.REQUEST_SUPPLIER) {
                    baseVo = ResponseParser.parseGetSupplier(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_PRODUCT){
                    baseVo = ResponseParser.parseGetProductList(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_POST_LOGIN){
                    baseVo = ResponseParser.parsePostLogin(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_PRODUCT_DETAIL){
                    baseVo = ResponseParser.parseproductDetail(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_PMS_COLOR ){
                    baseVo = ResponseParser.parsepmsColor(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_RELATED_PMS_COLOR){
                    baseVo = ResponseParser.parsepmsRelatedColor(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_POST_VIRTUAL_UPLOAD){
                    baseVo = ResponseParser.parseVirtualUpload(reader);
                }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_SUPPLIER_DETAIL){
                    baseVo = ResponseParser.parseGetSupplierDetail(reader);
                }


            } catch (CustomException e) {
                baseVo = new BaseVo();
                baseVo.setCustomException(e);
                e.printStackTrace();

            }

            return baseVo;
        }

        @Override
        protected void onPostExecute(BaseVo baseVo) {
            super.onPostExecute(baseVo);

            if (baseVo!=null)
            {
                if (baseVo.getCustomException()==null)
                {
                    onCompleteListener.onSuccessComplete(baseVo,requestCode);
                }
                else
                {
                    onCompleteListener.onFailComplete(baseVo,requestCode);
                }
            }
        }
    }