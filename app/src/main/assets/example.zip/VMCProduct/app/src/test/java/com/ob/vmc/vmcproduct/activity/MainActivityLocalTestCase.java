package com.ob.vmc.vmcproduct.activity;

import android.test.ActivityInstrumentationTestCase2;

import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import org.junit.Before;

/**
 * Created by khyati5403 on 10/19/2016.
 */

public class MainActivityLocalTestCase extends ActivityInstrumentationTestCase2<MainActivity> {

    SuppliersVO suppliersVO;
    public MainActivityLocalTestCase() {
        super("com.ob.vmc.vmcproduct.activity", MainActivity.class);
    }

    @Before
    public void setUp() {

    }
    public void testCheckSupplierList(){

   /*     SuppliersVo  supplier = new SuppliersVo();

        assertEquals("abc", supplier.getSupplierName());

        List<SuppliersVo> list = new ArrayList<SuppliersVo>();
        list.add(new SuppliersVo("a", "abc"));
        list.add(new SuppliersVo("a", "bca"));
        list.add(new SuppliersVo("a", "abcaa"));

        assertEquals(3, list.size());
        Supplier supplier1 = list.get(1);
        assertEquals("a", supplier1.getId());
        assertEquals("abc", supplier1.getSupplierName());*/
    }
}
