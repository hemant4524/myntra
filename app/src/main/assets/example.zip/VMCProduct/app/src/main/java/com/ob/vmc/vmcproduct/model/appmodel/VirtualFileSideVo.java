package com.ob.vmc.vmcproduct.model.appmodel;

public class VirtualFileSideVo {

        private String sideId;
        private String colorId;
        private String sidePath;

    public VirtualFileSideVo(String colorId,String sideId,  String sidePath) {
        this.sideId = sideId;
        this.colorId = colorId;
        this.sidePath = sidePath;
    }

    public String getColorId() {
        return colorId;
    }

    public String getSideId() {
            return sideId;
        }

        public String getSidePath() {
            return sidePath;
        }
    }