package com.ob.vmc.vmcproduct.model.appmodel;

import java.io.Serializable;

/**
 * Created by khyati5403 on 9/19/2016.
 */
public class ArtworkBaseVo implements Serializable{

    private BubblePropertyModel bubblePropertyModel;
    private StickerPropertyModel stickerPropertyModel;

    public BubblePropertyModel getBubblePropertyModel() {
        return bubblePropertyModel;
    }

    public void setBubblePropertyModel(BubblePropertyModel bubblePropertyModel) {
        this.bubblePropertyModel = bubblePropertyModel;
    }

    public StickerPropertyModel getStickerPropertyModel() {
        return stickerPropertyModel;
    }

    public void setStickerPropertyModel(StickerPropertyModel stickerPropertyModel) {
        this.stickerPropertyModel = stickerPropertyModel;
    }
}
