package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/7/2016.
 */

public class SatinEachEffectHandler {
    private Context mContext;


    public SatinEachEffectHandler(Context pContext) {
        mContext=pContext;
    }


    public Bitmap executeProcess(Bitmap srcBitmap) {

        try {
            if (srcBitmap != null) {
                srcBitmap = BitmapProcessing.doSatinEach(srcBitmap);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        return srcBitmap;
    }

}
