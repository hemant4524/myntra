package com.ob.vmc.vmcproduct.permission;
public class PermissionVo {


    private String[] permissionName;
    private String permissionMessage;

    public PermissionVo(String[] permissionName, String permissionMessage) {
        this.permissionName = permissionName;
        this.permissionMessage = permissionMessage;
    }

    public String[] getPermissionName() {
        return permissionName;
    }



    public String getPermissionMessage() {
        return permissionMessage;
    }


}