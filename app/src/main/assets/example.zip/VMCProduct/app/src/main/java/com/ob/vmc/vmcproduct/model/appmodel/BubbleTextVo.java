package com.ob.vmc.vmcproduct.model.appmodel;

import android.graphics.Color;

import com.ob.vmc.vmcproduct.constant.AlignmentType;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;

/**
 * Created by Ishan4452 on 1/9/2017.
 */

public class BubbleTextVo {

    private String labelText;
    private FlipType flipType;
    private EffectTypes effectType;
    private int singleColorCode;
    private int embroideryColorCode;
    private int opacity;
    private int toneOnToneColorCode;
    private int fontColorCode= Color.BLACK;
    private String fontTypeName;
    private float fontSize;
    private boolean fontStyleBold;
    private boolean fontStyleItalic;
    private boolean fontStyleUnderLine;
    private AlignmentType alignmentStyle;
    private int curveDegree;
    private int leatherEngravedColorCode;


    public String getLabelText() {
        return labelText;
    }

    public void setLabelText(String labelText) {
        this.labelText = labelText;
    }

    public int getFontColorCode() {
        return fontColorCode;
    }

    public void setFontColorCode(int fontColorCode) {
        this.fontColorCode = fontColorCode;
    }

    public FlipType getFlipType() {
        return flipType;
    }

    public void setFlipType(FlipType flipType) {
        this.flipType = flipType;
    }

    public EffectTypes getEffectType() {
        return effectType;
    }

    public void setEffectType(EffectTypes effectType) {
        this.effectType = effectType;
    }

    public int getSingleColorCode() {
        return singleColorCode;
    }

    public void setSingleColorCode(int singleColorCode) {
        this.singleColorCode = singleColorCode;
    }

    public int getEmbroideryColorCode() {
        return embroideryColorCode;
    }

    public void setEmbroideryColorCode(int embroideryColorCode) {
        this.embroideryColorCode = embroideryColorCode;
    }

    public int getOpacity() {
        return opacity;
    }

    public void setOpacity(int opacity) {
        this.opacity = opacity;
    }

    public int getToneOnToneColorCode() {
        return toneOnToneColorCode;
    }

    public void setToneOnToneColorCode(int toneOnToneColorCode) {
        this.toneOnToneColorCode = toneOnToneColorCode;
    }

    public String getFontTypeName() {
        return fontTypeName;
    }

    public void setFontTypeName(String fontTypeName) {
        this.fontTypeName = fontTypeName;
    }

    public float getFontSize() {
        return fontSize;
    }

    public void setFontSize(float fontSize) {
        this.fontSize = fontSize;
    }

    public boolean isFontStyleBold() {
        return fontStyleBold;
    }

    public void setFontStyleBold(boolean fontStyleBold) {
        this.fontStyleBold = fontStyleBold;
    }

    public boolean isFontStyleItalic() {
        return fontStyleItalic;
    }

    public void setFontStyleItalic(boolean fontStyleItalic) {
        this.fontStyleItalic = fontStyleItalic;
    }

    public boolean isFontStyleUnderLine() {
        return fontStyleUnderLine;
    }

    public void setFontStyleUnderLine(boolean fontStyleUnderLine) {
        this.fontStyleUnderLine = fontStyleUnderLine;
    }

    public AlignmentType getAlignmentStyle() {
        return alignmentStyle;
    }

    public void setAlignmentStyle(AlignmentType alignmentStyle) {
        this.alignmentStyle = alignmentStyle;
    }

    public int getCurveDegree() {
        return curveDegree;
    }

    public void setCurveDegree(int curveDegree) {
        this.curveDegree = curveDegree;
    }

    public int getLeatherEngravedColorCode() {
        return leatherEngravedColorCode;
    }

    public void setLeatherEngravedColorCode(int leatherEngravedColorCode) {
        this.leatherEngravedColorCode = leatherEngravedColorCode;
    }
}
