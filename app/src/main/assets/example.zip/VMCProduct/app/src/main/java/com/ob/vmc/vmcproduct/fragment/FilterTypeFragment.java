package com.ob.vmc.vmcproduct.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.FilterTypeAdapter;
import com.ob.vmc.vmcproduct.communicator.OnFilterTypeClick;

import java.util.ArrayList;

/**
 * Created by khyati5403 on 10/20/2016.
 */

public class FilterTypeFragment extends Fragment {

    public static final String TAG = FilterTypeFragment.class.getSimpleName();
    private RecyclerView mRecyclerView;
    private FilterTypeAdapter mFilterTypeAdapter;
    private ArrayList<String> list;
    private OnFilterTypeClick mFilterTypeClickListener;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_filter_type, container, false);

        mRecyclerView = (RecyclerView)view.findViewById(R.id.fft_rvFilterType);
        ArrayList<String> populate = getFilterList();
        mFilterTypeAdapter = new FilterTypeAdapter(getActivity(), populate, mFilterTypeClickListener);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
//        mRecyclerView.setHasFixedSize(true);
//        mRecyclerView.addItemDecoration(new CategoryDividerItemDecoration(getActivity(), CategoryDividerItemDecoration.VERTICAL_LIST, Util.getDrawable(getActivity(), R.drawable.divider)));
//        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mRecyclerView.setAdapter(mFilterTypeAdapter);
        return view;
    }

    public static FilterTypeFragment newInstance() {
        FilterTypeFragment typeFragment = new FilterTypeFragment();
        return typeFragment;
    }

    public ArrayList<String> getFilterList(){
        list = new ArrayList<>();
        list.add("Supplier");
        list.add("Colors");
        return list;
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        try
        {
            mFilterTypeClickListener = (OnFilterTypeClick) context;
        }
        catch (Exception e)
        {
            Activity activity = (Activity)context;
            throw new IllegalArgumentException(activity.getLocalClassName() + " does not implements 'OnFilterTypeClick'", e);
        }
    }
}
