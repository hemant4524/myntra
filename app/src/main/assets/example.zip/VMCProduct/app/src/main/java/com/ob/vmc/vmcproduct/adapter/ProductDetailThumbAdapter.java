package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.List;

/**
 * Created by khyati5403 on 11/2/2016.
 */

public class ProductDetailThumbAdapter extends RecyclerView.Adapter<ProductDetailThumbAdapter.ProductDetailThumbViewHolder> {

    private LayoutInflater inflater;
    private Context mContext;
    List<ProductDetailVo.DataVo.SidesVo> sidesList;
    private onThumbClickListener onThumbClickListener;
    private int mPColorIndex ;
    private int mSelectedIndex;

    public ProductDetailThumbAdapter(Context context,int pPColorIndex, onThumbClickListener clickListener) {
        this.inflater = LayoutInflater.from(context);
        mPColorIndex=pPColorIndex;
        this.mContext = context;
        this.onThumbClickListener = clickListener;
    }

    @Override
    public ProductDetailThumbViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ProductDetailThumbViewHolder(inflater.inflate(R.layout.item_product_thumb, parent, false));
    }

    @Override
    public void onBindViewHolder(ProductDetailThumbViewHolder holder, final int position) {
        holder.sdv_productThumb.setSelected(mSelectedIndex == position);
        holder.sdv_productThumb.setTag(R.id.tagKey_position, position);
        holder.sdv_productThumb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selected = (int) v.getTag(R.id.tagKey_position);
                onThumbClickListener.onThumbClick(selected);
                setPColorIndex(position);
               // setSelectedItem(selected);
            }
        });

        Util.loadImageByFresco(holder.sdv_productThumb, sidesList.get(position).getSideImage().get(mPColorIndex).getThumbImage(), null);
    }

    @Override
    public int getItemCount() {
        return sidesList==null?0:sidesList.size();
    }

    public void setSelectedItem(int position) {
        final int mPreviousSelected = mSelectedIndex;
        mSelectedIndex = mPColorIndex;
        if (mPreviousSelected != -1)
            notifyItemChanged(mPreviousSelected);
        notifyItemChanged(mSelectedIndex);


    }

    public ProductDetailThumbAdapter setPColorIndex(int mPColorIndex) {
        this.mPColorIndex = mPColorIndex;


        return this;
    }

    public ProductDetailThumbAdapter setSidesList(List<ProductDetailVo.DataVo.SidesVo> sidesList) {
        this.sidesList = sidesList;
        return this;
    }

    public class ProductDetailThumbViewHolder extends RecyclerView.ViewHolder{

        private SimpleDraweeView sdv_productThumb;
        public ProductDetailThumbViewHolder(View itemView) {
            super(itemView);

            sdv_productThumb = (SimpleDraweeView)itemView.findViewById(R.id.ipt_sdvProductThumb);
        }
    }

    public interface onThumbClickListener{
        void onThumbClick(int position);
    }
}
