package com.ob.vmc.vmcproduct.model.httpmodel;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

/**
 * Created by Ishan4452 on 12/14/2016.
 */

public class VirtualUploadVo extends BaseVo {


    /**
     * data : {"image":"http://virtualmarketingcart.com/assets/mobile-api/downloadproduct_58513b365eefa.jpg","pdf":"http://virtualmarketingcart.com/assets/mobile-api/mailproduct_58513b365eefa.pdf"}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo {
        /**
         * image : http://virtualmarketingcart.com/assets/mobile-api/downloadproduct_58513b365eefa.jpg
         * pdf : http://virtualmarketingcart.com/assets/mobile-api/mailproduct_58513b365eefa.pdf
         */

        @SerializedName("image")
        private String image;
        @SerializedName("pdf")
        private String pdf;

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getPdf() {
            return pdf;
        }

        public void setPdf(String pdf) {
            this.pdf = pdf;
        }
    }
}
