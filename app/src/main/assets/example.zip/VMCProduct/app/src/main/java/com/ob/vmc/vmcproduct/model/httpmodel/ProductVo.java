package com.ob.vmc.vmcproduct.model.httpmodel;

import com.ob.ecommercelibrary.vo.BaseVo;

import java.util.List;

/**
 * Created by khyati5403 on 10/11/2016.
 */

public class ProductVo extends BaseVo {
    public Data data;

    public class Data {
        public int count;
        public List<Product> products;
        public Product product;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public List<Product> getProducts() {
            return products;
        }

        public void setProducts(List<Product> products) {
            this.products = products;
        }

        public Product getProduct() {
            return product;
        }

        public void setProduct(Product product) {
            this.product = product;
        }
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
