package com.ob.vmc.vmcproduct.constant;

import android.os.Environment;

import java.io.File;

/**
 * Created by Ishan4452 on 6/7/2016.
 */

/*List of Application Constant Values base on Client */
public class AppConstant {

    public static final String CRITTERCISM_APP_KEY="73b4d6adad8147229a09c62176cf398a00555300";


    public static final String CLIENT_ID = "4_6btyz4ylot0c4csgcoow4ww40k8gsccc8k4c08sksso0gk8wgc";
    public static final String CLIENT_SECRET = "ged31no2wxwg0s4wg44osc08cgosgkgg40goc4o0ww8c8sgoo";

    public static final String LOCALE = "en_us";
    public static final String INSTANCE_ID = "1";
    public static final String INSTANCE_TYPE = "association";
    public static final String SUPPLIER_ID = "4";

    public static final int REQUEST_CODE_SEARCH_PROGRESS_CANCEL = 100;
    public static final String EXTERNAL_PATH = Environment.getExternalStorageDirectory()+"/.virtual";
    public static final String EXTERNAL_PATH_PRODUCT =EXTERNAL_PATH+"/.products";
    public static final String EXTERNAL_PATH_TEMP= "/.temp";
    public static final String EXTERNAL_PATH_IMAGE= "/.image";
    public static final String EXTERNAL_PATH_ART= "/.art";




    public static String getAppTempDirectory() {
        File file=new File(EXTERNAL_PATH,EXTERNAL_PATH_TEMP);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file.getAbsolutePath();
    }

    public static String getAppProductImageDirectory(String name) {
        File file=new File(EXTERNAL_PATH_PRODUCT+EXTERNAL_PATH_IMAGE,name);
        if (!file.exists()) {
            file.mkdirs();
        }

        return file.getAbsolutePath();
    }

    public static String getAppProductArtworkDirectory(String name,boolean wantCreate) {
        File file=new File(EXTERNAL_PATH_PRODUCT+EXTERNAL_PATH_ART,name);
        if (wantCreate) {
            if (!file.exists()) {
                file.mkdirs();
            }
        }
        return file.getAbsolutePath();
    }
}
