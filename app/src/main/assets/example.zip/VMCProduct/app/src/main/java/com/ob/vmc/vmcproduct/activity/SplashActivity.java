package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.andoblib.http.HTTPConnection;
import com.andoblib.listener.SimpleAlertDialogListener;
import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.KeyConstant;
import com.ob.vmc.vmcproduct.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        initView();
    }

    private void initView() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing()) {
                    if (HTTPConnection.isNetConnected(SplashActivity.this)) {
                        if (AppSetting.getString(SplashActivity.this, KeyConstant.PREF_ACCESS_TOKEN, null) != null) {

                            //Login User
                            startMainActivity(ProductListingActivity.class);

                        } else {
                            startMainActivity(LoginActivity.class);
                        }
                        //Finish This Activity
                        finish();
                    }
                } else {
                    CommonUtil.showSimpleDialog(SplashActivity.this, "Error", getString(R.string.err_no_internet_connection), "OK", false, 123, new SimpleAlertDialogListener() {
                        @Override
                        public void onSimpleDialogButtonClicked(int pRequestCode) {
                            finish();
                        }
                    }, getSupportFragmentManager());
                }
            }
        }, 1000);

    }

    private void startMainActivity(Class activityname) {

        Intent mIntent = new Intent(SplashActivity.this, activityname);
        startActivity(mIntent);
    }
}
