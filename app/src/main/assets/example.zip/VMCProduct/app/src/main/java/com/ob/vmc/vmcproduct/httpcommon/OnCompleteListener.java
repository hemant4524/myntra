package com.ob.vmc.vmcproduct.httpcommon;


/*API calling response handler and response parser handler methods*/
public interface OnCompleteListener {
    /**
     * Call when Parser response Success
     * @param itemObj  Base Object
     * @param requestCode API Request Code
     */
    void onSuccessComplete(Object itemObj, int requestCode);

    /**
     * Call when Parser response Fail
     * @param itemObj  Base Object
     * @param requestCode API Request Code
     */
    void onFailComplete(Object itemObj, int requestCode);


    /**
     * Call when un-accepted response or un-handle response Error
     * @param itemObj  Base Object
     *
     */
    void onError(Object itemObj);
}