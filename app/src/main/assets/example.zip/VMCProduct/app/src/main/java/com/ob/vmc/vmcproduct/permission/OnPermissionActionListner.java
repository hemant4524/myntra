package com.ob.vmc.vmcproduct.permission;

public interface OnPermissionActionListner
    {
        void permissionDenied(int requestCode);

        void permissionGranted(int requestCode);

        void permissionNeverAsked(int requestCode);
    }