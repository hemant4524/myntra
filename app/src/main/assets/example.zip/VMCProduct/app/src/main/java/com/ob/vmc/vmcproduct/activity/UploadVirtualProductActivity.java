package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.andoblib.io.FileIO;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.FilesToUpload;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.UploadVirtualAdapter;
import com.ob.vmc.vmcproduct.constant.AppConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.appmodel.UploadVirtualFileVo;
import com.ob.vmc.vmcproduct.model.appmodel.VirtualFileSideVo;
import com.ob.vmc.vmcproduct.model.httpmodel.VirtualUploadVo;
import com.ob.vmc.vmcproduct.permission.OnPermissionActionListner;
import com.ob.vmc.vmcproduct.permission.PemissionBaseActivity;
import com.ob.vmc.vmcproduct.utils.Util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ishan4452 on 12/14/2016.
 */

public class UploadVirtualProductActivity extends PemissionBaseActivity implements OnPermissionActionListner, UploadVirtualAdapter.OnUploadClickListener, OnCompleteListener {

    public static final java.lang.String VIRTUAL_SKU = "virtual_sku";
    public static final String VIRTUAL_NAME = "virtual_name";
    private static final int REQUEST_FILE_UPLOAD = 101;
    private static final int REQUEST_UPLOAD_RESULT_ACTIVITY = 201;
    private String productSku;
    private RecyclerView mRvVirtualProductList;
    private Toolbar mToolbar;
    private String productTitle;
    private List<VirtualFileSideVo> mUploadVirtualUrl;

    public static String getFileExt(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_virtual);
        bundleValues();
        setupToolbar();
        initViews();

        initVirtualList();


    }

    private void bundleValues() {

        Bundle bundle = getIntent().getExtras();
        if (bundle == null)
            finish();
        productTitle = bundle.getString(VIRTUAL_NAME);
        productSku = bundle.getString(VIRTUAL_SKU);
    }

    private void setupToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setNavigationIcon(R.drawable.back_icon);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mToolbar.setTitle(productTitle);


    }

    private void initViews() {
        mRvVirtualProductList = (RecyclerView) findViewById(R.id.auv_rvVirtualWorkList);
        mRvVirtualProductList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        ((TextView) findViewById(R.id.auv_tvProductName)).setText(productTitle);
        ((TextView) findViewById(R.id.auv_tvSkuValue)).setText(productSku);
    }

    private void initVirtualList() {

        String directoryPath = AppConstant.getAppProductImageDirectory(productSku);

        File virtualFilePath = new File(directoryPath);


        if (virtualFilePath.exists()) {
            List<UploadVirtualFileVo> uploadVirtualFileVo = new ArrayList<>();

            File[] colorDirectory = virtualFilePath.listFiles();
            for (int index = 0; index < colorDirectory.length; index++) {
                List<VirtualFileSideVo> virtualFileSideVos = getVirtualFilePath(colorDirectory[index]);
                uploadVirtualFileVo.add(new UploadVirtualFileVo(colorDirectory[index].getName(), virtualFileSideVos));
            }

            UploadVirtualAdapter uploadVirtualAdapter = new UploadVirtualAdapter(this, uploadVirtualFileVo);
            mRvVirtualProductList.setAdapter(uploadVirtualAdapter);

        }

    }

    public List<VirtualFileSideVo> getVirtualFilePath(File directoryFile) {
        List<VirtualFileSideVo> fileSideVos = new ArrayList<>();
        if (directoryFile.isDirectory()) {
            File[] fileList = directoryFile.listFiles();

            for (int indexFile = 0; indexFile < fileList.length; indexFile++) {
                String filePath = fileList[indexFile].getPath();
                String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
                String[] fileNameSplit = fileName.split("_");

                boolean checkFileExtenstion = checkFileExtention("png", fileName);
                if (fileNameSplit.length == 3 && checkFileExtenstion) {
                    fileSideVos.add(new VirtualFileSideVo(fileNameSplit[1], fileNameSplit[2], filePath));
                }

            }
        }
        return fileSideVos;
    }

    private boolean checkFileExtention(String ext, String fileName) {
        String fileExt = getFileExt(fileName);
        return ext.equalsIgnoreCase(fileExt);
    }

    @Override
    public void permissionDenied(int requestCode) {

    }

    @Override
    public void permissionGranted(int requestCode) {

    }

    @Override
    public void permissionNeverAsked(int requestCode) {

    }


    @Override
    public void onUploadClick(List<VirtualFileSideVo> virtualFileSideVos) {

        mUploadVirtualUrl = virtualFileSideVos;

        String uploadImageUrl = WSUrlConstant.virtualProductUpload();
        List<NameValuePair> postHeader = Util.getDefaultHeader(this);
        List<FilesToUpload> postParams = new ArrayList<>();
        for (int index = 0; index < virtualFileSideVos.size(); index++) {
            VirtualFileSideVo sideVo = virtualFileSideVos.get(index);
            postParams.add(new FilesToUpload(sideVo.getSidePath(), WSKeyConstant.SIDEIMAGES));
        }
        CommonUtil.showProgressDialog(this, null, "Uploading virtual...", false, null, -1, getSupportFragmentManager());
        FormHttpCaller formHttpCaller = new FormHttpCaller(this, uploadImageUrl, APIType.METHOD_POST, postHeader, null, postParams, WSRequestCodeConstant.REQUEST_POST_VIRTUAL_UPLOAD, new ResponseHandler(this));
        formHttpCaller.execute();

    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;

        if (requestCode == WSRequestCodeConstant.REQUEST_POST_VIRTUAL_UPLOAD) {
            VirtualUploadVo virtualUploadVo = (VirtualUploadVo) baseVo;
            VirtualUploadVo.DataVo dataVo = virtualUploadVo.getData();
            if (dataVo != null) {

                if (mUploadVirtualUrl != null) {
                    for (int i = 0; i < mUploadVirtualUrl.size(); i++) {
                     /* File file=new File(mUploadVirtualUrl.get(i).getSidePath());
                        if (file.exists()) {
                            file.delete();
                        }*/
                        FileIO.deleteDirectory(AppConstant.getAppProductImageDirectory(productSku + "/" + mUploadVirtualUrl.get(i).getColorId()));
                    }
                }


                Intent intent = new Intent(UploadVirtualProductActivity.this, UploadVirtualResultActivity.class);
                intent.putExtra(UploadVirtualResultActivity.VIRTUAL_IMAGE, dataVo.getImage());
                intent.putExtra(UploadVirtualResultActivity.VIRTUAL_PDF, dataVo.getPdf());
                startActivityForResult(intent, REQUEST_UPLOAD_RESULT_ACTIVITY);
            }
        }

        Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        Toast.makeText(this, baseVo.getCustomException().getMessage(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onError(Object itemObj) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        Toast.makeText(this, baseVo.getCustomException().getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_UPLOAD_RESULT_ACTIVITY) {
            UploadVirtualAdapter adapter = (UploadVirtualAdapter) mRvVirtualProductList.getAdapter();
            if (adapter.getItemCount() > 1)
                initVirtualList();
            else
                finish();
        }

    }
}
