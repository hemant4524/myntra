package com.ob.vmc.vmcproduct.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;

import com.ob.vmc.vmcproduct.customcontrol.bitmapcontrol.bitmapcache.ImageResizer;


/**
 * Created by Abner on 15/2/12.
 * QQ 230877476
 * Email nimengbo@gmail.com
 */
public class CommonUtils {


    private static final int KEY_PREVENT_TS = -20000;
    private static String TAG = "CommonUtils";
    private static long lastClickTime;
    private static int lastClickViewId;

    /**
     * 计算分享内容的字数，一个汉字=两个英文字母，一个中文标点=两个英文标点 注意：该函数的不适用于对单个字符进行计算，因为单个字符四舍五入后都是1
     *
     * @param c
     * @return
     */
    public static long calculateLength(CharSequence c) {
        double len = 0;
        for (int i = 0; i < c.length(); i++) {
            int tmp = (int) c.charAt(i);
            if (tmp > 0 && tmp < 127) {
                len += 0.5;
            } else {
                len++;
            }
        }
        return Math.round(len);
    }

    public static Bitmap decodeSampledBitmapFromResource(Resources res, int resId,
                                                         int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;

        return BitmapFactory.decodeResource(res, resId, options);
    }


    public static Bitmap decodeSampledBitmapFromFile(String file,
                                                     int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        BitmapFactory.decodeFile(file, options);


        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(file, options);
    }


    public static Bitmap decodeSampledBitmapFromOriginal(Resources res, int resId, BitmapFactory.Options options,
                                                         int reqWidth, int reqHeight) {


        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }


    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    public static BitmapFactory.Options getImageDrawableOption(Context context, int drawable) {
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(context.getResources(), drawable, option);
        return option;
    }

    public static Bitmap getBitmapDrawable(ImageResizer imageResizer, int drawable) {
        return imageResizer.getImageCache().getBitmapFromMemCache(String.valueOf(drawable)).getBitmap();

    }


    public static int getBitmapDrawableWidth(ImageResizer imageResizer, int drawable) {
        BitmapDrawable bitmapDrawable = imageResizer.getImageCache().getBitmapFromMemCache(String.valueOf(drawable));
        if (bitmapDrawable != null)
            return bitmapDrawable.getIntrinsicWidth();
        else
            return 0;
    }

    public static int getBitmapDrawableHeight(ImageResizer imageResizer, int drawable) {
        BitmapDrawable bitmapDrawable = imageResizer.getImageCache().getBitmapFromMemCache(String.valueOf(drawable));
        if (bitmapDrawable != null)
            return bitmapDrawable.getIntrinsicHeight();
        else
            return 0;
    }
}
