package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by khyati5403 on 11/29/2016.
 */

public class ImageVo implements Parcelable {

    private int opacity;
    private boolean isHFlip;
    private boolean isVFlip;
    private boolean isEmboss;
    private boolean isDeboss;
    private boolean isEngrave;
    private int singleColor;
    private boolean isSingleColor;
    private boolean isSatinEach;
    private boolean isMulticolor;
    private boolean isRemoveWhite;
    private boolean isRemoveBlack;
    private boolean isSharpness;
    private boolean isWooden;
    private boolean isEmbroidery;


    public ImageVo() {
    }

    public int getOpacity() {
        return opacity;
    }

    public void setOpacity(int opacity) {
        this.opacity = opacity;
    }

    public boolean isHFlip() {
        return isHFlip;
    }

    public void setHFlip(boolean HFlip) {
        isHFlip = HFlip;
    }

    public boolean isVFlip() {
        return isVFlip;
    }

    public void setVFlip(boolean VFlip) {
        isVFlip = VFlip;
    }

    public boolean isEmboss() {
        return isEmboss;
    }

    public boolean isEmbroidery() {
        return isEmbroidery;
    }

    public void setEmbroidery(boolean embroidery) {
        isEmbroidery = embroidery;
    }

    public void setEmboss(boolean emboss) {
        isEmboss = emboss;
    }

    public void setEmboss(boolean emboss, boolean isReset) {
        isEmboss = emboss;
        if (emboss && isReset) {
            setDeboss(false);
            setEngrave(false);
            setSatinEach(false);
            setSingleColor(false);
            setWooden(false);
            setEmbroidery(false);
        }
    }

    public boolean isDeboss() {
        return isDeboss;
    }

    public void setDeboss(boolean deboss) {
        isDeboss = deboss;
    }

    public void setDeboss(boolean deboss, boolean isReset) {
        isDeboss = deboss;
        if (deboss && isReset) {
            setEmboss(false);
            setEngrave(false);
            setSatinEach(false);
            setSingleColor(false);
            setWooden(false);
            setEmbroidery(false);
        }
    }

    public boolean isEngrave() {
        return isEngrave;
    }

    public void setEngrave(boolean engrave) {
        isEngrave = engrave;

    }

    public void setEngrave(boolean engrave, boolean isReset) {
        isEngrave = engrave;
        if (engrave && isReset) {
            setDeboss(false);
            setEmboss(false);
            setSingleColor(false);
            setSatinEach(false);
            setWooden(false);
            setEmbroidery(false);
        }
    }

    public int getSingleColor() {
        return singleColor;
    }

    public void setSingleColor(int singleColor) {
        this.singleColor = singleColor;
    }

    public boolean isSatinEach() {
        return isSatinEach;
    }

    public void setSatinEach(boolean satinEach) {
        isSatinEach = satinEach;
    }

    public void setSatinEach(boolean satinEach, boolean isReset) {
        isSatinEach = satinEach;
        if (satinEach && isReset) {
            setDeboss(false);
            setEngrave(false);
            setEmboss(false);
            setSingleColor(false);
            setWooden(false);
            setEmbroidery(false);
        }
    }

    public boolean isSingleColor() {
        return isSingleColor;
    }

    public void setSingleColor(boolean singleColor) {
        isSingleColor = singleColor;
    }

    public void setSingleColor(boolean singleColor, boolean isReset) {
        isSingleColor = singleColor;
        if (singleColor && isReset) {
            setDeboss(false);
            setEngrave(false);
            setSatinEach(false);
            setEmboss(false);
            setWooden(false);
            setRemoveWhite(true);
            setEmbroidery(false);
        }
    }

    public boolean isMulticolor() {
        return isMulticolor;
    }

    public void setMulticolor(boolean multicolor) {
        isMulticolor = multicolor;
        setDeboss(false);
        setEmboss(false);
        setSingleColor(false);
        setSatinEach(false);
        setEngrave(false);
        setWooden(false);
        setEmbroidery(false);
    }

    public boolean isRemoveWhite() {
        return isRemoveWhite;
    }

    public void setRemoveWhite(boolean removeWhite) {
        isRemoveWhite = removeWhite;
    }

    public boolean isRemoveBlack() {
        return isRemoveBlack;
    }

    public void setRemoveBlack(boolean removeBlack) {
        isRemoveBlack = removeBlack;
    }

    public boolean isSharpness() {
        return isSharpness;
    }

    public void setSharpness(boolean sharpness) {
        isSharpness = sharpness;
    }

    public boolean isWooden() {
        return isWooden;
    }

    public void setWooden(boolean wooden) {
        isWooden = wooden;
    }

    public void setWooden(boolean wooden, boolean isReset){
        isWooden = wooden;
        if (wooden && isReset){
            setDeboss(false);
            setEngrave(false);
            setEmboss(false);
            setSingleColor(false);
            setSatinEach(false);
            setEmbroidery(false);
        }
    }

    public void setEmbroidery(boolean embroidery, boolean isReset){
        isEmbroidery = embroidery;
        if (embroidery && isReset){
            setDeboss(false);
            setEngrave(false);
            setEmboss(false);
            setSingleColor(false);
            setSatinEach(false);
            setWooden(false);
        }
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.opacity);
        dest.writeByte(this.isHFlip ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isVFlip ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEmboss ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isDeboss ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEngrave ? (byte) 1 : (byte) 0);
        dest.writeInt(this.singleColor);
        dest.writeByte(this.isSingleColor ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isSatinEach ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isMulticolor ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isRemoveWhite ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isRemoveBlack ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isSharpness ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isWooden ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEmbroidery ? (byte) 1 : (byte) 0);
    }

    protected ImageVo(Parcel in) {
        this.opacity = in.readInt();
        this.isHFlip = in.readByte() != 0;
        this.isVFlip = in.readByte() != 0;
        this.isEmboss = in.readByte() != 0;
        this.isDeboss = in.readByte() != 0;
        this.isEngrave = in.readByte() != 0;
        this.singleColor = in.readInt();
        this.isSingleColor = in.readByte() != 0;
        this.isSatinEach = in.readByte() != 0;
        this.isMulticolor = in.readByte() != 0;
        this.isRemoveWhite = in.readByte() != 0;
        this.isRemoveBlack = in.readByte() != 0;
        this.isSharpness = in.readByte() != 0;
        this.isWooden = in.readByte() != 0;
        this.isEmbroidery = in.readByte() != 0;
    }

    public static final Creator<ImageVo> CREATOR = new Creator<ImageVo>() {
        @Override
        public ImageVo createFromParcel(Parcel source) {
            return new ImageVo(source);
        }

        @Override
        public ImageVo[] newArray(int size) {
            return new ImageVo[size];
        }
    };
}
