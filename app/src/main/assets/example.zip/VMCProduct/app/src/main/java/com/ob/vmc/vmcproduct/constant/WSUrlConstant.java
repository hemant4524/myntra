package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 10/10/2016.
 */

public class WSUrlConstant {


//        private  static String BASE_URL="http://172.16.116.31/virtual/web/app_dev.php";
    private  static String BASE_URL="http://172.16.116.30/Virtual/web/app_dev.php";
    private  static String BASE_URL_LIVE="http://virtualmarketingcart.com";
    private static String API_AUTHORIZE_TOKEN="/api/v1/authorize-token";


    private static final String API_PROJECT_SETTING = "/api/v1/"+AppConstant.LOCALE+"/get-project-settings";
    public static String API_SUPPLIER = "/api/request-call/v2/get-suppliers";

    //    public static String API_GET_PRODUCT = "/api/v2/get-products";
    public static String API_GET_PRODUCT = "/api/request-call/v2/get-products";
    public static String API_AUTH_USER= "/api/request-call/v2/auth-user";
    private static final String API_GET_PRODUCT_DETAIL = "/api/request-call/v2/get-product-detail";

    private static final String  API_GET_PMS_COLOR = "/api/request-call/v2/get-pms-color";
    private static final String  API_GET_RELATED_PMS_COLOR = "/api/request-call/v2/get-related-pms-color";
    private static final String  API_POST_VIRTUAL_IMAGE= "/api/request-call/v2/upload-images";
    private static final String API_GET_SUPPLIER_DETAIL = "/api/request-call/v2/get-supplier-detail";


    /**
     * This Method Webservice Base Url
     * @return BASE_URL
     */
    public static String webServiceBaseUrl() {
        return BASE_URL_LIVE;
    }

    /**
     * This Method return WebService Methods URL after append BASE_URL + POST_URL
     * @param postUrl POST_URL After BASE_URL.
     * @return  BASE_URL + POST_URL
     */
    public static String urlAppendWithBaseUrl(String postUrl) {
        return webServiceBaseUrl()+postUrl;
    }


    /**
     * This Method return WebService Methods URL for login
     *
     * @return  BASE_URL + API_AUTH_USER
     */
    public static String loginAPIUrl() {
        return webServiceBaseUrl()+API_AUTH_USER;
    }

    /**
     * This Method return WebService Methods URL for Product API Url
     *
     * @return  BASE_URL + API_AUTH_USER
     */
    public static String productAPIUrl() {
        return webServiceBaseUrl()+API_GET_PRODUCT;
    }


    /**
     * This Method return WebService Methods URL for Product Detail Url
     *
     * @return  BASE_URL + API_product Detail
     */
    public static String productDetailAPIUrl() {
        return webServiceBaseUrl()+API_GET_PRODUCT_DETAIL;
    }


    /**
     * This Method return WebService Methods URL for get Pms Color
     *
     * @return  BASE_URL + API_Pms_color
     */
    public static String productApiGetPmsColor() {
        return webServiceBaseUrl()+API_GET_PMS_COLOR;
    }


    /**
     * This Method return WebService Methods URL for get Replated Pms color
     *
     * @return  BASE_URL + API_get_related_pms_color
     */
    public static String productApiGetRelatedPmsColor() {
        return webServiceBaseUrl()+API_GET_RELATED_PMS_COLOR;
    }

    /**
     * This Method return WebService Methods URL for Virtual Upload Image
     *
     * @return  BASE_URL + API_POST_VIRTUAL_IMAGE
     */
    public static String virtualProductUpload() {
        return webServiceBaseUrl()+API_POST_VIRTUAL_IMAGE;
    }


    /**
     * This Method return WebService Methods URL for Supplier Detail
     *
     * @return  BASE_URL + API_GET_SUPPLIER_DETAIL
     */
    public static String getSupplierDetail() {
        return webServiceBaseUrl()+API_GET_SUPPLIER_DETAIL;
    }
}
