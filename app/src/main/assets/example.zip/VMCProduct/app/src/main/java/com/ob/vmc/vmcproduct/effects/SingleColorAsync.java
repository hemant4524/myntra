package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

public class SingleColorAsync extends AsyncTask<Void, Void, Bitmap> {

    private int mColor;
    private Bitmap srcBitmap;
    private Context mContext;
    private SingleColorEventResult mSingleColorEventResult;
    private String error;
    private String pBitmapPath;

    public SingleColorAsync(Context mContext, SingleColorEventResult mSingleColorEventResult, Bitmap bitmap, int color) {
        this.mContext = mContext;
        this.mSingleColorEventResult = mSingleColorEventResult;
        this.mColor = color;
//        this.pBitmapPath = mBitmapPath;
        this.srcBitmap =  bitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;

            /**
             * Get bitmap from URI
             */
        //                Uri uri=Uri.fromFile(new File(pBitmapPath));
//                srcBitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
        bitmap = BitmapProcessing.singleColor(srcBitmap, mColor);
//        bitmap = BitmapProcessing.darker(srcBitmap, mColor, 0.9f);
//                mUri = Uri.fromFile(FileUtils.saveBitmap(bitmap, mContext));


        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mSingleColorEventResult.onSingleColorEventComplete(bitmap);
        } else {
            mSingleColorEventResult.onSingleColorEventFail(error);
        }
    }

    public interface SingleColorEventResult {
        void onSingleColorEventComplete(Bitmap bitmap);

        void onSingleColorEventFail(String exceptionMsg);
    }


}