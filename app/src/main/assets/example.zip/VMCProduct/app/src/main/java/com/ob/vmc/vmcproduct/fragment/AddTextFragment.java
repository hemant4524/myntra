package com.ob.vmc.vmcproduct.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.customviews.BubbleTextView;


/**
 * Created by khyati5403 on 11/24/2016.
 */

public class AddTextFragment extends EcommerceBaseFragment {

    private static final String BUBBLE_TEXT = "bubble_text";
    private static final String BUBBLE_NEW = "bubble_new";
    private EditText et_bubble_input;
    private CompleteCallBack mCompleteCallBack;
    private BubbleTextView mBubbleTextView;
    private Context mContext;
    private String defaultStr;
    private RelativeLayout iv_Done;
    private boolean isBubbleNew;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mContext = getActivity();
        View v = inflater.inflate(R.layout.view_input_dialog, null);
//        defaultStr = mContext.getString(R.string.double_click_input_text);

        Bundle bundle = getArguments();
        if (bundle != null) {
            defaultStr = bundle.getString(BUBBLE_TEXT);
            isBubbleNew = bundle.getBoolean(BUBBLE_NEW);
        }


        et_bubble_input = (EditText) v.findViewById(R.id.vid_etInputText);
        if (defaultStr.length() == 0)
            et_bubble_input.setHint(R.string.double_click_input_text);

        else
            et_bubble_input.setText(defaultStr);

        et_bubble_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);

                imm.showSoftInputFromInputMethod(getView().findViewById(R.id.vid_etInputText).getWindowToken(), 0);
            }
        });
        iv_Done = (RelativeLayout) v.findViewById(R.id.vid_rlDone);
        iv_Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                done();

            }
        });
        return v;
    }

    public void setBubbleTextView(BubbleTextView bubbleTextView) {
        this.mBubbleTextView = bubbleTextView;
        if (defaultStr.equals(bubbleTextView.getmStr())) {
            et_bubble_input.setText("");
        } else {
            et_bubble_input.setText(bubbleTextView.getmStr());
            et_bubble_input.setSelection(bubbleTextView.getmStr().length());
        }
    }


    private void done() {
        if (mCompleteCallBack != null) {
            String str;
            if (TextUtils.isEmpty(et_bubble_input.getText())) {
                str = defaultStr;
            } else {

                str = et_bubble_input.getText().toString();
            }

                mCompleteCallBack.onComplete(str, isBubbleNew);

        }
    }

    public void setCompleteCallBack(CompleteCallBack completeCallBack) {
        this.mCompleteCallBack = completeCallBack;
    }

    public static AddTextFragment newInstance(String pBubbleText, boolean isNew) {
        AddTextFragment textFragment = new AddTextFragment();
        Bundle bundle = new Bundle();
        bundle.putString(BUBBLE_TEXT, pBubbleText);
        bundle.putBoolean(BUBBLE_NEW, isNew);
        textFragment.setArguments(bundle);
        return textFragment;
    }

    public interface CompleteCallBack {
        void onComplete(String str, boolean isNew);
    }
}
