package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import com.ob.vmc.vmcproduct.effects.RemoveColorAsync;

/**
 * Created by Ishan4452 on 12/1/2016.
 */

public class RemoveBlackWhiteHandler {


    private final int[] COLOR_FROM_WHITE = new int[]{255, 255, 255};
    private final int[] COLOR_FROM_BLACK = new int[]{0, 0, 0};
    private final int WHITE_THRESHOLD = 100;
    private final int BLACK_THRESHOLD = 100;

    private Context mContext;
    private RemoveColorAsync.RemoveColorEventResult mRemoveColorEventResult;
    private Bitmap mBitmapPath;
    private boolean isRemovedWhite;
    private boolean isRemovedBlack;


    public RemoveBlackWhiteHandler(Context mContext) {
        this.mContext = mContext;
    }

    public RemoveBlackWhiteHandler(Context pContext, RemoveColorAsync.RemoveColorEventResult pRemoveColorEventResult) {
        this.mContext = pContext;
        this.mRemoveColorEventResult = pRemoveColorEventResult;

    }

    public RemoveBlackWhiteHandler setRemovedWhite(boolean removedWhite) {
        isRemovedWhite = removedWhite;
        return this;
    }

    public RemoveBlackWhiteHandler setRemovedBlack(boolean removedBlack) {
        isRemovedBlack = removedBlack;
        return this;
    }

    public RemoveBlackWhiteHandler setRemovedWhitwBlack(Bitmap pBitmapPath, boolean removedWhite, boolean removedBlack) {
        mBitmapPath = pBitmapPath;
        isRemovedWhite = removedWhite;
        isRemovedBlack = removedBlack;
        return this;
    }

    public Bitmap executeProcess(Bitmap srcBitmap) {
     /*   new RemoveColorAsync(mContext, mBitmapPath,isRemovedWhite,isRemovedBlack, mRemoveColorEventResult).execute();*/

        /**
         * Get bitmap from URI
         */
       Bitmap result = srcBitmap.copy(Bitmap.Config.ARGB_8888, true);
        try {
        /*     int nWidth = result.getWidth();
            int nHeight = result.getHeight();
            for (int y = 0; y < nHeight; ++y) {
                for (int x = 0; x < nWidth; ++x) {
                    int nPixelColor = result.getPixel(x, y);
                    if (isRemovedWhite) {
                        nPixelColor = matchWhite(nPixelColor);
                        result.setPixel(x, y, nPixelColor);
                    }
                    if (isRemovedBlack) {
                        nPixelColor = matchBlack(nPixelColor);
                        result.setPixel(x, y, nPixelColor);
                    }

                }
            }

            srcBitmap=result.copy(Bitmap.Config.ARGB_8888, true);
            result.recycle();*/

//                Uri uri=Uri.fromFile(new File(mBitmapPath));
//                Bitmap srcBitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
            //Need to copy to ensure that the bitmap is mutable.
            int[] intArray = new int[srcBitmap.getWidth() * srcBitmap.getHeight()];
            srcBitmap.getPixels(intArray, 0, srcBitmap.getWidth(), 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight());


            for (int x = 0; x < intArray.length; x++) {
                if (isRemovedWhite)
                    intArray[x] = matchWhite(intArray[x]);
                if (isRemovedBlack)
                    intArray[x] = matchBlack(intArray[x]);

            }
            srcBitmap = Bitmap.createBitmap(intArray, srcBitmap.getWidth(), srcBitmap.getHeight(), srcBitmap.getConfig());
        } catch (Exception e) {
            e.printStackTrace();
        }


        return srcBitmap;
    }


    private int matchWhite(int pixel) {
        //There may be a better way to match, but I wanted to do a comparison ignoring
        //transparency, so I couldn't just do a direct integer compare.
        return Math.abs(Color.red(pixel) - COLOR_FROM_WHITE[0]) < WHITE_THRESHOLD &&
                Math.abs(Color.green(pixel) - COLOR_FROM_WHITE[1]) < WHITE_THRESHOLD &&
                Math.abs(Color.blue(pixel) - COLOR_FROM_WHITE[2]) < WHITE_THRESHOLD ? Color.TRANSPARENT : pixel;
    }

    private int matchBlack(int pixel) {
        //There may be a better way to match, but I wanted to do a comparison ignoring
        //transparency, so I couldn't just do a direct integer compare.
        return Math.abs(Color.red(pixel) - COLOR_FROM_BLACK[0]) < BLACK_THRESHOLD &&
                Math.abs(Color.green(pixel) - COLOR_FROM_BLACK[1]) < BLACK_THRESHOLD &&
                Math.abs(Color.blue(pixel) - COLOR_FROM_BLACK[2]) < BLACK_THRESHOLD ?  Color.TRANSPARENT : pixel;
    }

}
