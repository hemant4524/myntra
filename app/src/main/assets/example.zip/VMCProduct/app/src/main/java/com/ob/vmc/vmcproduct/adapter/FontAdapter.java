package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.utils.font.FontFileReader;
import com.ob.vmc.vmcproduct.utils.font.TTFFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by khyati5403 on 3/21/2016.
 */
public class FontAdapter extends RecyclerView.Adapter<FontAdapter.MyViewHolder> {

    private String[] fontList;
    private String TAG = FontAdapter.class.getSimpleName();
    ;
    private Context context;
    private OnFontFaceChange onFontFaceChange;
    private ArrayList<String> fontsArrayList;
    private int selected_position = 0;


    public FontAdapter(Context pContext, String[] fontList) {
        this.context = pContext;
        this.fontList = fontList;
        this.fontsArrayList = new ArrayList<>(Arrays.asList(fontList));

        onFontFaceChange = (OnFontFaceChange) pContext;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fontface_view, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
//        CustomLogHandler.printVerbose(TAG,"position:==>"+position);
        String font = fontsArrayList.get(position);
        final String fontPath = "fonts/" + fontList[position];
        Typeface typeface = Typeface.createFromAsset(context.getAssets(), fontPath);
        String fontTitle = fontList[position];
        InputStream inputStream = null;
        String fontName = null;
        try {
            inputStream = context.getAssets().open(fontPath);
            TTFFile ttfFile = FontFileReader.readTTF(inputStream);
            fontName = ttfFile.getFullName();
//            fontName = (String) ttfFile.getFamilyNames().toArray()[position];
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*fontTitle = fontTitle.replace(".ttf", "");
        fontTitle = fontTitle.replace(".otf", "");*/
        holder.title.setText(fontName);
        holder.title.setTypeface(typeface);
        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFontFaceChange.setOnFontFaceChanageListener(fontPath);
            }
        });
    }

    @Override
    public int getItemCount() {
//        CustomLogHandler.printVerbose(TAG,"font length:==>"+fontList.length);
        return fontsArrayList.size();
    }

    public interface OnFontFaceChange {
        void setOnFontFaceChanageListener(String fontsPath);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView title;

        public MyViewHolder(View view) {
            super(view);

            title = (TextView) view.findViewById(R.id.fv_tvfontName);
        }
    }
}