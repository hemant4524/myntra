package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;
import com.ob.vmc.vmcproduct.utils.DensityUtils;

/**
 * Created by khyati5403 on 12/15/2016.
 */

public class DebossEffectHandler {

    private Context mContext;


    public DebossEffectHandler(Context pContext) {
        mContext = pContext;
    }

    public Bitmap executeProcess(Bitmap srcBitmap, boolean isRequireRemoveWhite,int opa) {
//        new DebossEffectAsync(mContext, mDebossResult, bitmap).execute();
        /**
         * Get bitmap from URI
         */
        try {

//            float[] arrayOfFloat = new float[9];
//            matrix.setValues(arrayOfFloat);


            if (isRequireRemoveWhite) {
                int[] intArray = new int[srcBitmap.getWidth() * srcBitmap.getHeight()];
                srcBitmap.getPixels(intArray, 0, srcBitmap.getWidth(), 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight());
                for (int x = 0; x < intArray.length; x++) {
                    intArray[x]= BitmapProcessing.removeWhite(intArray[x]);
                }
                srcBitmap = Bitmap.createBitmap(intArray, srcBitmap.getWidth(), srcBitmap.getHeight(), srcBitmap.getConfig());
            }


            Bitmap originalBitmap = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(originalBitmap);

            int color = Color.parseColor("#c8000000");
            Paint paintt = new Paint();
            canvas.drawBitmap(srcBitmap, 0,0, paintt);


            Bitmap bitmapMaskShadow = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);

            Canvas cShadowLeftTop = new Canvas(bitmapMaskShadow);


            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setStyle(Paint.Style.FILL);
//            paint.setColor(Color.YELLOW);
            paint.setColor(color);
            paint.setAntiAlias(true);

            cShadowLeftTop.drawRect(0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(), paint);

            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            int trasPixelPlus= DensityUtils.dip2px(mContext,2);

            cShadowLeftTop.drawBitmap(srcBitmap, trasPixelPlus,trasPixelPlus, paint);



//            Bitmap copyShadow=bitmapMaskShadow.copy(Bitmap.Config.ARGB_8888,true);
//            cShadowLeftTop.drawBitmap(copyShadow, -2, 0,new Paint(Paint.ANTI_ALIAS_FLAG));
//            cShadowLeftTop.drawBitmap(copyShadow, 0, 2,new Paint(Paint.ANTI_ALIAS_FLAG));
//            cShadowLeftTop.drawBitmap(copyShadow, 0, -2,new Paint(Paint.ANTI_ALIAS_FLAG));

        /*    Paint paintShadow = new Paint(Paint.ANTI_ALIAS_FLAG);

            canvas.drawBitmap(bitmapMaskShadow, 0,0, paintShadow);*/

            paint.setColorFilter(null);

            Paint paintShadow = new Paint(Paint.ANTI_ALIAS_FLAG);

            canvas.drawBitmap(bitmapMaskShadow, 0,0, paintShadow);

            bitmapMaskShadow.recycle();

            Bitmap bitmapMaskShadowBottom = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);

            Canvas cShadowRightBottom = new Canvas(bitmapMaskShadowBottom);

            paint.setXfermode(null);

            cShadowRightBottom.drawRect(0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(), paint);

            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));

            int trasPixelMinus= DensityUtils.dip2px(mContext,-2);

            cShadowRightBottom.drawBitmap(srcBitmap, trasPixelMinus,trasPixelMinus, paint);

            Paint paintShadowBottom = new Paint();

            canvas.drawBitmap(bitmapMaskShadowBottom, 0,0, paintShadowBottom);


            bitmapMaskShadowBottom.recycle();


            Bitmap bitmapMask = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);

            Canvas cNew = new Canvas(bitmapMask);


            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.parseColor("#FFFFFF"));
            paint.setAntiAlias(true);

            cNew.drawRect(0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(), paint);

            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));

            cNew.drawBitmap(srcBitmap, 0, 0, paint);


//            Paint paintNew = new Paint(Paint.ANTI_ALIAS_FLAG);
//            paintNew.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
//            canvas.drawBitmap(bitmapMask, 0,0, paintNew);


//            Bitmap copyOrigin= Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas removeWhite=new Canvas(originalBitmap);
//            removeWhite.drawBitmap(originalBitmap,0,0,new Paint(Paint.ANTI_ALIAS_FLAG));

            Paint paintRemoveWhite = new Paint(Paint.ANTI_ALIAS_FLAG);
            paintRemoveWhite.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
//            Bitmap copyMask=bitmapMask.copy(Bitmap.Config.ARGB_8888,true);
            removeWhite.drawBitmap(bitmapMask,0,0,paintRemoveWhite);

            bitmapMask.recycle();

/*            Bitmap removeWhite = Bitmap.createBitmap(srcBitmap.getWidth(), srcBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas1=new Canvas(originalBitmap);
            *//*canvas1.setBitmap(removeWhite);
            canvas1.drawBitmap(originalBitmap, 0,0, new Paint(Paint.ANTI_ALIAS_FLAG));
*//*
            Paint paintRemoveWhite = new Paint(Paint.ANTI_ALIAS_FLAG);
            ColorMatrix colorMatrix = new ColorMatrix();
            colorMatrix.setSaturation(Color.WHITE); //Remove Colour
            ColorMatrixColorFilter colorFilterWhite = new ColorMatrixColorFilter(colorMatrix);
            paintRemoveWhite.setColorFilter(colorFilterWhite);
            canvas1.drawBitmap(originalBitmap, 0,0, paintRemoveWhite);*/
//            originalBitmap.eraseColor(Color.WHITE);

            return originalBitmap;

/*
            int[] intArray = new int[originalBitmap.getWidth() * originalBitmap.getHeight()];
            originalBitmap.getPixels(intArray, 0, originalBitmap.getWidth(), 0, 0, originalBitmap.getWidth(), originalBitmap.getHeight());
            for (int x = 0; x < intArray.length; x++) {

                    intArray[x] = (intArray[x]==Color.parseColor("#FFFFFF") || intArray[x]==Color.WHITE) ?0:intArray[x];

            }
          Bitmap  bitmap = Bitmap.createBitmap(intArray, originalBitmap.getWidth(), originalBitmap.getHeight(), originalBitmap.getConfig());

            return bitmap;
*/



//            if (srcBitmap != null) {
//                srcBitmap = BitmapProcessing.doDeboss(srcBitmap, isRequireRemoveWhite);
//            }
        } catch (Exception e) {
            e.printStackTrace();
            return srcBitmap;
        }


    }
}
