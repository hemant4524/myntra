package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/15/2016.
 */

public class WoodenEffectAsync extends AsyncTask<Void, Void, Bitmap> {
    private Bitmap maskBitmap;
    private Uri mUri;
    private Bitmap srcBitmap;
    private Context mContext;
    private WoodenEffectAsync.WoodenEffectResult mWoodenEffectResult;
    private String error;
    private View view;

    public WoodenEffectAsync(Context mContext, WoodenEffectAsync.WoodenEffectResult mWoodenEffectResult, Bitmap bitmap, Bitmap maskBitmap) {
        this.mContext = mContext;
        this.mWoodenEffectResult = mWoodenEffectResult;
        this.srcBitmap = bitmap;
        this.maskBitmap = maskBitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;
        /**
         * Get bitmap from URI
         */
        try {
            if (srcBitmap != null) {
                bitmap = BitmapProcessing.woodenEffect(srcBitmap, maskBitmap);
            }
        } catch (Exception e) {
            error = e.getMessage();
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mWoodenEffectResult.onWoodenEventComplete(bitmap);
        } else {
            mWoodenEffectResult.onWoodenEventFail(error);
        }
    }

    public interface WoodenEffectResult {
        void onWoodenEventComplete(Bitmap bitmap);

        void onWoodenEventFail(String exceptionMsg);
    }
}