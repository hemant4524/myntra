package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.andoblib.http.HTTPConnection;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.ActivityFinishBroadCastReceiver;
import com.ob.ecommercelibrary.common.KeyConstant;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.communicator.RefreshCallBack;
import com.ob.vmc.vmcproduct.permission.PemissionBaseActivity;
import com.ob.vmc.vmcproduct.utils.Util;

public class VirtualBaseActivity extends PemissionBaseActivity implements ActivityFinishBroadCastReceiver.Listener
{
    private ActivityFinishBroadCastReceiver mActivityFinishBroadCastReceiver;

    protected void startActivity(@NonNull Class activityToStart)
    {
        Intent startIntent = new Intent(this, activityToStart);
        startActivity(startIntent);
    }

    protected void startActivityForResult(@NonNull Class activityToStart,int resultCode)
    {
        Intent startIntent = new Intent(this, activityToStart);
        startActivityForResult(startIntent, resultCode);
    }

    /**
     * Method to add {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to add {@link Fragment}
     * @param addToBackStack whether to add to back stack or not
     * @param fragToAdd      Fragment to be added
     */
    protected void addFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToAdd)
    {
        addFragment(layoutResId, addToBackStack, fragToAdd, null);
    }

    /**
     * Method to add {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to add {@link Fragment}
     * @param addToBackStack whether to add transition to back stack or not
     * @param fragToAdd      Fragment to be added
     * @param tag            String TAG to be used in transition and back stack name
     */
    protected void addFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToAdd, @Nullable String tag)
    {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transition = manager.beginTransaction();

        if (tag != null)
            transition.add(layoutResId, fragToAdd, tag);
        else
            transition.add(layoutResId, fragToAdd, fragToAdd.getClass().getSimpleName());
        if (addToBackStack)
            transition.addToBackStack(tag);
        transition.commit();
    }

    /**
     * Method to replace {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to replace {@link Fragment}
     * @param addToBackStack whether to add transition to back stack or not
     * @param fragToReplace  Fragment to be replaced
     */
    protected void replaceFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToReplace)
    {
        replaceFragment(layoutResId, addToBackStack, fragToReplace, null);
    }

    /**
     * Method to replace {@link Fragment} to transition
     *
     * @param layoutResId    Layout resource id where to replace {@link Fragment}
     * @param addToBackStack whether to add transition to back stack or not
     * @param fragToReplace  Fragment to be replaced
     * @param tag            String TAG to be used in transition and back stack name
     */
    protected void replaceFragment(int layoutResId, boolean addToBackStack, @NonNull Fragment fragToReplace, @Nullable String tag)
    {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transition = manager.beginTransaction();

        if (tag != null)
            transition.replace(layoutResId, fragToReplace, tag);
        else
            transition.replace(layoutResId, fragToReplace, fragToReplace.getClass().getSimpleName());

        if (addToBackStack)
            transition.addToBackStack(tag);
        transition.commit();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        mActivityFinishBroadCastReceiver = new ActivityFinishBroadCastReceiver(this);
        registerReceiver(mActivityFinishBroadCastReceiver, new IntentFilter(KeyConstant.BROAD_CAST_ACTION_NAME));
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if(mActivityFinishBroadCastReceiver != null)
        unregisterReceiver(mActivityFinishBroadCastReceiver);
    }

    @Override
    public void destroyActivity(int pAction)
    {
        if(pAction == KeyConstant.ACTION_LOGOUT_FINISH)
            finish();
    }

    public boolean popFragment() {
        boolean isPop = false;
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            isPop = true;
            manager.popBackStack(manager.getBackStackEntryAt(0).getId(), 0);
            manager.popBackStack();
        }
        return isPop;
    }

    public void setErroMsg( final LinearLayout mLlErrorContainer, int erroIcon, String errorFirst, String errorSecond,final RefreshCallBack refreshCallBack) {

        mLlErrorContainer.setVisibility(View.VISIBLE);
        ((ImageView) mLlErrorContainer.findViewById(R.id.df_ivErrorIcon)).setImageDrawable(getResources().getDrawable(erroIcon));
        ((TextView) mLlErrorContainer.findViewById(R.id.df_tvErrorMsgFirst)).setText(errorFirst);
        ((TextView) mLlErrorContainer.findViewById(R.id.df_tvErrorMsgSecond)).setText(errorSecond);

        mLlErrorContainer.findViewById(R.id.df_cbRetry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mLlErrorContainer.setVisibility(View.GONE);

                if (HTTPConnection.isNetConnected(VirtualBaseActivity.this)) {
                    refreshCallBack.onRefreshOnClick();

                } else {

                    CommonUtil.showProgressDialog(VirtualBaseActivity.this, null, null, false, null, -1, getSupportFragmentManager());


                    new Thread(new Runnable() {


                        @Override
                        public void run() {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    setErroMsg(mLlErrorContainer, R.drawable.close_icon, getString(R.string.error_no_connection), getString(R.string.info_plz_chk_yr_conn),refreshCallBack);
                                    mLlErrorContainer.setVisibility(View.VISIBLE);
                                    CommonUtil.dismissProgressDialog();
                                }
                            });
                        }
                    }).start();


                }
            }
        });
    }

    /**
     * Method to check if user is login and can proceed as normal flow. If user is not logged in, he/she would be redirected to login screen
     * @return true if user should proceed further, false if redirected to Login Screen
     */
    protected boolean userShouldProceed()
    {
        if(Util.checkUserAsLogin(this))
        {
            return true;
        }
        else
        {
            Intent intent = new Intent(this, LoginActivity.class);
//            intent.putExtra(Constants.IS_FROM_GUEST_USER, true);
            startActivity(intent);
            return false;
        }
    }
}
