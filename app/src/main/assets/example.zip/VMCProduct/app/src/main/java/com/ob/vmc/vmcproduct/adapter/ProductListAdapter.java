package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.communicator.OnItemClickListener;
import com.ob.vmc.vmcproduct.model.httpmodel.Product;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.List;

/**
 * Created by khyati5403 on 10/11/2016.
 */

public class ProductListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<Product> productList;
    private Context mContext;
    public final OnItemClickListener mOnItemClickListener;
    private boolean isGridStyle;

    public ProductListAdapter(List<Product> products, Context pContext, OnItemClickListener mClickListener) {
        this.productList = products;
        this.mContext = pContext;
        this.mOnItemClickListener = mClickListener;
    }

    @Override
    public int getItemViewType(int position) {

        return isGridStyle ?0:1;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView;
        if (viewType==1) {
            itemView = LayoutInflater.from(mContext).inflate(R.layout.item_product_list, parent, false);
            return new ProductListViewHolder(itemView);

        } else {
            itemView = LayoutInflater.from(mContext).inflate(R.layout.item_product_grid, parent, false);
            return new ProductGridViewHolder(itemView);

        }
    }



    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        RecyclerView.ViewHolder vh = holder;

        if (vh instanceof ProductListViewHolder) {

            ProductListViewHolder lVh = (ProductListViewHolder) vh;

            final Product product = productList.get(position);
            lVh.tvProductName.setText(product.getProductTitle());
//        holder.iv_ProductImage.setImageResource(Integer.parseInt(product.getProductimage()));
            Util.loadImageByFresco(lVh.iv_ProductImage, product.getThumbImage(), null);

            lVh.pView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mOnItemClickListener.onItemClick(product);
                }
            });

        } else {

            ProductGridViewHolder gridViewHolder = (ProductGridViewHolder) vh;

            final Product product = productList.get(position);

            gridViewHolder.tvGridProductName.setText(product.getProductTitle());

            Util.loadImageByFresco(gridViewHolder.iv_GridProductImage, product.getThumbImage(), null);
            gridViewHolder.pView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mOnItemClickListener.onItemClick(product);
                }
            });

        }


    }

    public void setGridStyle(boolean gridStyle) {
        isGridStyle = gridStyle;
    }

    public boolean isGridStyle() {
        return isGridStyle;
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void addItem(List<Product> list) {
        if (list != null) {
            productList.addAll(list);
        }
    }

    public class ProductListViewHolder extends RecyclerView.ViewHolder {
        public TextView tvProductName, tvGridProductName;
        public SimpleDraweeView iv_ProductImage, iv_GridProductImage;
        public View pView;

        public ProductListViewHolder(View itemView) {
            super(itemView);
            pView = itemView;
            tvProductName = (TextView) itemView.findViewById(R.id.ipl_tvProductName);
            iv_ProductImage = (SimpleDraweeView) itemView.findViewById(R.id.ipl_ivProductImage);

        }
    }

    public class ProductGridViewHolder extends RecyclerView.ViewHolder {
        public TextView  tvGridProductName;
        public SimpleDraweeView iv_GridProductImage;
        public View pView;

        public ProductGridViewHolder(View itemView) {
            super(itemView);
            pView = itemView;
            tvGridProductName = (TextView) itemView.findViewById(R.id.ipg_tvProductName);
            iv_GridProductImage = (SimpleDraweeView) itemView.findViewById(R.id.ipg_ivProductImage);

        }
    }
}
