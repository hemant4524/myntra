package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by khyati5403 on 10/24/2016.
 */

public class CategoryVo implements Parcelable{


    @SerializedName("id")
    private int id;
    @SerializedName("supplierName")
    public String supplierName;

    protected CategoryVo(Parcel in) {
        id = in.readInt();
        supplierName = in.readString();
    }

    public static final Creator<CategoryVo> CREATOR = new Creator<CategoryVo>() {
        @Override
        public CategoryVo createFromParcel(Parcel in) {
            return new CategoryVo(in);
        }

        @Override
        public CategoryVo[] newArray(int size) {
            return new CategoryVo[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    @Override
    public String toString() {
        return "CommonIdNameCountVo{" +
                "id=" + id +
                ", supplierName='" + supplierName + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(supplierName);
    }
}
