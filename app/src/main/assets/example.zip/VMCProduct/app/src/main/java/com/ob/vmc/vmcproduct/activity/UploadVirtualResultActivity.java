package com.ob.vmc.vmcproduct.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.customviews.facebookzoomable.ZoomableDraweeView;
import com.ob.vmc.vmcproduct.permission.OnPermissionActionListner;
import com.ob.vmc.vmcproduct.permission.PemissionBaseActivity;

/**
 * Created by Ishan4452 on 12/15/2016.
 */
public class UploadVirtualResultActivity extends PemissionBaseActivity implements OnPermissionActionListner{
    public static final String VIRTUAL_IMAGE = "virtual_image";
    public static final String VIRTUAL_PDF = "Virtual_pdf";
    private Toolbar mToolbar;
    private String productImage;
    private String productPdf;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_virtual_result);
        bundleValues();
        setupToolbar();

        initViews();
    }

    private void bundleValues() {
        Bundle bundle = getIntent().getExtras();
        if (bundle == null)
            finish();
        productImage= bundle.getString(VIRTUAL_IMAGE);
        productPdf= bundle.getString(VIRTUAL_PDF);
    }


    private void setupToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setNavigationIcon(R.drawable.back_icon);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void initViews() {
        ZoomableDraweeView draweeView=(ZoomableDraweeView)findViewById(R.id.auvr_zvProductImage);
        DraweeController controller = Fresco.newDraweeControllerBuilder()
                .setUri(productImage)
                .build();
        draweeView.setController(controller);
    }


        @Override
    public void permissionDenied(int requestCode) {

    }

    @Override
    public void permissionGranted(int requestCode) {

    }

    @Override
    public void permissionNeverAsked(int requestCode) {

    }
}
