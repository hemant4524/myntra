package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/15/2016.
 */

public class EmbroideryEffectAsync extends AsyncTask<Void, Void, Bitmap> {
    private Bitmap maskBitmap;
    private Bitmap srcBitmap;
    private Context mContext;
    private EmbroideryEffectResult mEmbroideryEffectResult;
    private String error;
    private int  colorCode;

    public EmbroideryEffectAsync(Context mContext,int colorCode ,EmbroideryEffectResult mEmbroideryEffectResult, Bitmap bitmap, Bitmap maskBitmap) {
        this.mContext = mContext;
        this.mEmbroideryEffectResult = mEmbroideryEffectResult;
        this.srcBitmap = bitmap;
        this.maskBitmap = maskBitmap;
        this.colorCode=colorCode;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;
        /**
         * Get bitmap from URI
         */
        try {
            if (srcBitmap != null) {
                bitmap = BitmapProcessing.embroideryEffect(colorCode,srcBitmap, maskBitmap);
            }
        } catch (Exception e) {
            error = e.getMessage();
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mEmbroideryEffectResult.onEmbroideryEventComplete(bitmap);
        } else {
            mEmbroideryEffectResult.onEmbroideryEventFail(error);
        }
    }

    public interface EmbroideryEffectResult {
        void onEmbroideryEventComplete(Bitmap bitmap);

        void onEmbroideryEventFail(String exceptionMsg);
    }
}