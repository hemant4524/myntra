package com.ob.vmc.vmcproduct.model.appmodel;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by khyati5403 on 3/1/2016.
 */
public class FontVo implements Parcelable {
    private int tagId;
    private float fontSize;
    private Typeface fontFace;
    private int fontColor = Color.BLACK;
    private int singleColor;
    private boolean isBold;
    private boolean isItalic;
    private boolean isUnderline;
    private boolean isHFlip;
    private boolean isVFlip;
    private int angle;
    private boolean isLeft;
    private boolean isRight;
    private boolean isCenter;
    private boolean isEmboss;
    private boolean isDeboss;
    private boolean isEngrave;

    private boolean isMultiColor;
    private boolean isSingleColor;
    private boolean isSatinEtch;
    private boolean isWooden;
    private boolean isEmbroidary;
    private int opacity;
    private int mColor;


    public FontVo() {
    }


    public int getTagId() {
        return tagId;
    }

    public void setTagId(int tagId) {
        this.tagId = tagId;
    }

    public float getFontSize() {
        return fontSize;
    }

    public void setFontSize(float fontSize) {
        this.fontSize = fontSize;
    }

    public Typeface getFontFace() {
        return fontFace;
    }

    public void setFontFace(Typeface fontFace) {
        this.fontFace = fontFace;
    }

    public int getFontColor() {
        return fontColor;
    }

    public void setFontColor(int fontColor) {
        this.fontColor = fontColor;
    }

    public boolean isBold() {
        return isBold;
    }

    public void setIsBold(boolean isBold) {
        this.isBold = isBold;
    }

    public boolean isItalic() {
        return isItalic;
    }

    public void setIsItalic(boolean isItalic) {
        this.isItalic = isItalic;
    }

    public boolean isUnderline() {
        return isUnderline;
    }

    public void setUnderline(boolean underline) {
        isUnderline = underline;
    }

    public boolean isHFlip() {
        return isHFlip;
    }

    public void setHFlip(boolean HFlip) {
        isHFlip = HFlip;
    }

    public boolean isVFlip() {
        return isVFlip;
    }

    public void setVFlip(boolean VFlip) {
        isVFlip = VFlip;
    }

    public boolean isLeft() {
        return isLeft;
    }

    public void setIsLeft(boolean isLeft) {
        this.isLeft = isLeft;
    }

    public boolean isRight() {
        return isRight;
    }

    public void setIsRight(boolean isRight) {
        this.isRight = isRight;
    }

    public boolean isCenter() {
        return isCenter;
    }

    public void setIsCenter(boolean isCenter) {
        this.isCenter = isCenter;
    }

    public int getAngle() {
        return angle;
    }

    public void setAngle(int angle) {
        this.angle = angle;
    }

    public boolean isMultiColor() {
        return isMultiColor;
    }

    public boolean isSingleColor() {
        return isSingleColor;
    }

    public void setIsSingleColor(boolean isSingleColor) {
        this.isSingleColor = isSingleColor;
    }

    public void setSingleColor(int colorCode) {
        singleColor = colorCode;
    }

    public int getSingleColor() {
        return singleColor;
    }

    public void setIsSingleColor(boolean isSingleColor, boolean isReset) {
        this.isSingleColor = isSingleColor;
        if (isSingleColor && isReset) {
            setDeboss(false);
            setIsEngrave(false);
            setIsSatinEtch(false);
            setIsEmboss(false);
            setWooden(false);
            setEmbroidary(false);
        }
    }

    public boolean isEngrave() {
        return isEngrave;
    }

    public void setIsEngrave(boolean isEngrave) {
        this.isEngrave = isEngrave;
    }

    public void setIsEngrave(boolean isEngrave, boolean isReset) {
        this.isEngrave = isEngrave;
        if (isEngrave && isReset) {
            setIsEmboss(false);
            setDeboss(false);
            setIsSatinEtch(false);
            setIsSingleColor(false);
            setWooden(false);
            setEmbroidary(false);
        }
    }

    public boolean isEmboss() {
        return isEmboss;
    }

    public void setIsEmboss(boolean isEmboss) {
        this.isEmboss = isEmboss;
    }

    public void setIsEmboss(boolean isEmboss, boolean isReset) {
        this.isEmboss = isEmboss;
        if (isEmboss && isReset) {
            setDeboss(false);
            setIsSingleColor(false);
            setIsSatinEtch(false);
            setIsEngrave(false);
            setWooden(false);
            setEmbroidary(false);
        }
    }


    public void setIsMultiColor(boolean isMultiColor) {
        this.isMultiColor = isMultiColor;
        setDeboss(false);
        setIsEmboss(false);
        setIsSingleColor(false);
        setIsSatinEtch(false);
        setIsEngrave(false);
        setWooden(false);
        setEmbroidary(false);
    }

    public boolean isDeboss() {
        return isDeboss;
    }

    public void setDeboss(boolean deboss) {
        isDeboss = deboss;
    }

    public void setDeboss(boolean deboss, boolean isReset) {
        isDeboss = deboss;
        if (deboss && isReset) {
            setIsEmboss(false);
            setIsSingleColor(false);
            setIsSatinEtch(false);
            setIsEngrave(false);
            setWooden(false);
            setEmbroidary(false);
        }
    }

    public boolean isSatinEtch() {
        return isSatinEtch;
    }

    public void setIsSatinEtch(boolean isSatinEtch) {
        this.isSatinEtch = isSatinEtch;
    }

    public void setIsSatinEtch(boolean isSatinEtch, boolean isReset) {
        this.isSatinEtch = isSatinEtch;
        if (isSatinEtch && isReset) {
            setDeboss(false);
            setIsEmboss(false);
            setIsSingleColor(false);
            setIsEngrave(false);
            setWooden(false);
            setEmbroidary(false);
        }
    }

    public int getOpacity() {
        return opacity;
    }

    public void setOpacity(int opacity) {
        this.opacity = opacity;
    }

    public boolean isWooden() {
        return isWooden;
    }

    public void setWooden(boolean wooden) {
        isWooden = wooden;
    }

    public void setWooden(boolean wooden, boolean isReset) {
        isWooden = wooden;
        if (wooden && isReset) {
            setDeboss(false);
            setIsEmboss(false);
            setIsSingleColor(false);
            setIsEngrave(false);
            setIsSatinEtch(false);
            setEmbroidary(false);
        }
    }

    public boolean isEmbroidary() {
        return isEmbroidary;
    }

    public void setEmbroidary(boolean embroidary) {
        isEmbroidary = embroidary;
    }

    public int getEmbroidaryColor() {
        return mColor;
    }

    public void setEmbroidary(int color, boolean embroidary, boolean isReset) {
        isEmbroidary = embroidary;
        mColor = color;
        if (embroidary && isReset) {
            setDeboss(false);
            setIsEmboss(false);
            setIsSingleColor(false);
            setIsEngrave(false);
            setIsSatinEtch(false);
            setWooden(false);
        }
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.tagId);
        dest.writeFloat(this.fontSize);
        dest.writeParcelable((Parcelable) this.fontFace, flags);
        dest.writeInt(this.fontColor);
        dest.writeByte(this.isBold ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isItalic ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isUnderline ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isHFlip ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isVFlip ? (byte) 1 : (byte) 0);
        dest.writeInt(this.angle);
        dest.writeByte(this.isLeft ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isRight ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isCenter ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isMultiColor ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isSingleColor ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEngrave ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isEmboss ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isDeboss ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isSatinEtch ? (byte) 1 : (byte) 0);
        dest.writeInt(this.opacity);
    }

    protected FontVo(Parcel in) {
        this.tagId = in.readInt();
        this.fontSize = in.readFloat();
        this.fontFace = in.readParcelable(Typeface.class.getClassLoader());
        this.fontColor = in.readInt();
        this.isBold = in.readByte() != 0;
        this.isItalic = in.readByte() != 0;
        this.isUnderline = in.readByte() != 0;
        this.isHFlip = in.readByte() != 0;
        this.isVFlip = in.readByte() != 0;
        this.angle = in.readInt();
        this.isLeft = in.readByte() != 0;
        this.isRight = in.readByte() != 0;
        this.isCenter = in.readByte() != 0;
        this.isMultiColor = in.readByte() != 0;
        this.isSingleColor = in.readByte() != 0;
        this.isEngrave = in.readByte() != 0;
        this.isEmboss = in.readByte() != 0;
        this.isDeboss = in.readByte() != 0;
        this.isSatinEtch = in.readByte() != 0;
        this.opacity = in.readInt();
    }

    public static final Creator<FontVo> CREATOR = new Creator<FontVo>() {
        @Override
        public FontVo createFromParcel(Parcel source) {
            return new FontVo(source);
        }

        @Override
        public FontVo[] newArray(int size) {
            return new FontVo[size];
        }
    };
}
