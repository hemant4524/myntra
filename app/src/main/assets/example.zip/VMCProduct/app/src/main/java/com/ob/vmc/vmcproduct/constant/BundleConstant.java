package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 10/10/2016.
 */

public class BundleConstant {
}
