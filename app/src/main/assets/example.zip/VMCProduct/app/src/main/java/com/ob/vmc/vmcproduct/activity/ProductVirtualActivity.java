package com.ob.vmc.vmcproduct.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Animatable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.CursorLoader;
import android.support.v7.graphics.Palette;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.andoblib.io.FileIO;
import com.andoblib.listener.YesNoAlertDialogListener;
import com.andoblib.log.CustomLogHandler;
import com.andoblib.util.CommonUtil;
import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.common.logging.FLog;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.DataSource;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.drawee.controller.ControllerListener;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.Priority;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.image.ImageInfo;
import com.facebook.imagepipeline.image.QualityInfo;
import com.facebook.imagepipeline.request.BasePostprocessor;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.facebook.imagepipeline.request.Postprocessor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.ColorAdapter;
import com.ob.vmc.vmcproduct.adapter.ColorSwatchesAdapter;
import com.ob.vmc.vmcproduct.adapter.FontAdapter;
import com.ob.vmc.vmcproduct.adapter.SingleColorAdapter;
import com.ob.vmc.vmcproduct.constant.AppConstant;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.customcontrol.bitmapcontrol.bitmapcache.AsyncTask;
import com.ob.vmc.vmcproduct.customviews.BubbleTextView;
import com.ob.vmc.vmcproduct.customviews.ProductOverlayImageView;
import com.ob.vmc.vmcproduct.customviews.ShowView;
import com.ob.vmc.vmcproduct.customviews.StickerView;
import com.ob.vmc.vmcproduct.customviews.ZoomLayout;
import com.ob.vmc.vmcproduct.effects.BubbleEffectsTask;
import com.ob.vmc.vmcproduct.effects.StickerEffectTaskListener;
import com.ob.vmc.vmcproduct.effects.StickerEffectsTask;
import com.ob.vmc.vmcproduct.effects.ViewsEffectsThread;
import com.ob.vmc.vmcproduct.fragment.AddMediaFragment;
import com.ob.vmc.vmcproduct.fragment.AddTextFragment;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.appmodel.ArtworkBaseVo;
import com.ob.vmc.vmcproduct.model.appmodel.BubblePropertyModel;
import com.ob.vmc.vmcproduct.model.appmodel.PmsColorVo;
import com.ob.vmc.vmcproduct.model.appmodel.PmshexcolorVo;
import com.ob.vmc.vmcproduct.model.appmodel.RelatedPmsColorVo;
import com.ob.vmc.vmcproduct.model.appmodel.StickerPropertyModel;
import com.ob.vmc.vmcproduct.model.httpmodel.GetSupplierDetailVo;
import com.ob.vmc.vmcproduct.model.httpmodel.PointVo;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.permission.OnPermissionActionListner;
import com.ob.vmc.vmcproduct.permission.PermissionVo;
import com.ob.vmc.vmcproduct.utils.CommonUtils;
import com.ob.vmc.vmcproduct.utils.DensityUtils;
import com.ob.vmc.vmcproduct.utils.ImprintAreaType;
import com.ob.vmc.vmcproduct.utils.Util;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Created by khyati5403 on 10/27/2016.
 */

public class ProductVirtualActivity extends VirtualBaseActivity implements FontAdapter.OnFontFaceChange, AddMediaFragment.OnAddMediaActionListner, ColorAdapter.OnColorClickListener, SingleColorAdapter.OnSingleColorClickListener, OnPermissionActionListner,
        OnCompleteListener, ColorSwatchesAdapter.onColorSwatchesListener, YesNoAlertDialogListener, StickerEffectTaskListener {

    public static final String BASIC_INFO = "basic_info";
    public static final String IMPRINT_INFO = "imprint_info";
    public static final String SIDE_DETAIL = "Side_detail";
    public static final String CONFIGURATION_OPTION = "configurationOptions";
    private static final String TAG = ProductVirtualActivity.class.getSimpleName();
    private final static int REQUEST_CALL_FOR_ENGRAVE = 101;
    private static final int REQUEST_CAMERA = 501;
    private static final int REQUEST_GALLERY = 502;
    private static final int REQUEST_IMAGE_CROP = 100;
    private static final String ADD_MEDIA_FRAGMENT = "add_media";
    private static final String ADD_NEW_TEXT_TAG = "add_new_text";
    private static final int REQUEST_ALL_PERMISSION = 201;
    private static final int REQUEST_CAMERA_PERMISSION = 202;
    private static final int REQUEST_GALLERY_PERMISSION = 203;
    private static final int REQUEST_VIRTUAL_SAVE_PERMISSION = 204;
    private static final int REQUEST_DIALOG_SAVE_ARTWORK = 301;

    private Activity mContext;
    private SimpleDraweeView sdv_ProductImage;
    private TextView tvImageMenu, tvTextMenu, tvEffectMenu;
    private Toolbar mToolbar;
    private RecyclerView rView_Font;
    private FontAdapter fAdapter;
    private View mapv_main_menu_layout, mapv_menu_image, mapv_menu_text;
    private View mapv_menuimage_rotate, mapv_menuimage_layer, mapv_menuimage_alignment, mapv_menuimage_opacity, mapv_menuimage_sharpness, mapv_menuimage_removecolor, mapv_menutext_fonttype, mapv_menutext_fontcolor,
            mapv_menutext_fontsize, mapv_menutext_fontstyle, mapv_menutext_fontcurve, mapv_menueffects;

    private SeekBar sbOpacity, sbSharpness, sb_fontSize, sb_Curve;
    private ShowView mapv_svCustomeView;

    private RelativeLayout rlCropImage, rlRotation, rlLayerOrder, rlAlignment, rlOpacity, rlSharpness, rlRemoveColor;
    private RelativeLayout rlFontFace, rlFontColor, rlFontSize, rlFontStyle, rlFontRotation, rlLayer, rlAlign, rlFontOpacity, rlCurve;

    private ImageView mimr_ivRLeft, mimr_ivRRight, mimr_ivLFilp, mimr_ivRFlip;
    private ImageView miml_ivMoveTop, miml_ivMoveBottom;
    private ImageView mima_ivLeftAlign, mima_ivCenterAlign, mima_ivRightAlign;
    private ImageView ivFontBold, ivFontItalic, ivFontUnderline;

    private ImageView ivMulticolor, ivSinglecolor, ivEmboss, ivDeboss, ivEngrave, ivEmbroidery, ivSatinEach, ivWooden, ivToneonTone, ivLatherEngraved;

    private ProductDetailVo.DataVo.BasicInformationVo mProductBasicInfo;
    private ProductDetailVo.DataVo.ImprintInfoVo mProductImprintInfo;
    private ProductDetailVo.DataVo.SidesVo.SideImageVo mProductSideDetail;
    private GetSupplierDetailVo.DataVo.SupplierDetailVo.ConfigurationOptionsVo mConfigurationOptionsVo;
    private ProductOverlayImageView mProductOverlayImprintArea;
    private View editableView;
    private RelativeLayout rlCustomeDraw, mapv_back;
    private AddTextFragment textFragment;
    private ImageView mPreview, mvt_btnSave;
    private boolean isProductPreview;
    private File photoFile;
    private long editableViewId;

    private BubbleTextView.OperationListener bubbleTextViewListener = new BubbleTextView.OperationListener() {
        @Override
        public void onDeleteClick(BubbleTextView bubbleTextView) {
            rlCustomeDraw.removeView(bubbleTextView);

            initDefaultEditableView();
            showHideBottomBarContainer(false);
            showHideImgaeViewActionBar(false);
            showHideTextViewActionBar(false);
            showHideColorSwaches(false);
            showHideTextMenu(false);

        }

        @Override
        public void onEdit(BubbleTextView bubbleTextView) {
        }

        @Override
        public void onDoubleClick(BubbleTextView bubbleTextView) {
            bubbleTextView.setInEdit(true);
            inputDialog(bubbleTextView.getmStr(), false);
            showHideTextMenu(false);
        }

        @Override
        public void onTop(BubbleTextView bubbleTextView) {
            rlCustomeDraw.invalidate();
        }

        @Override
        public void onClick(BubbleTextView bubbleTextView) {

            if (editableViewId != bubbleTextView.getBubbleId()) {
                showHideBottomBarContainer(false);
                editableViewId = bubbleTextView.getBubbleId();
            }
            if (editableView != null) {
                showViewEditable(false);
            }
            editableView = bubbleTextView;
            showViewEditable(true);
            showHideTextViewActionBar(true);
            showHideColorSwaches(false);
            BubbleTextView textView = (BubbleTextView) editableView;
            textView.getmFontVo();
            float val = textView.getmFontVo().getFontSize();
            sb_fontSize.setProgress((int) val);

        }
    };
    private StickerView.OperationListener stickerOperationListener = new StickerView.OperationListener() {
        @Override
        public void onDeleteClick(StickerView stickerView) {
//            CustomLogHandler.printVerbose(TAG, "StickerView:---onDeleteClick");
            rlCustomeDraw.removeView(stickerView);

            initDefaultEditableView();
            showHideBottomBarContainer(false);
            showHideImgaeViewActionBar(false);
            showHideTextViewActionBar(false);
            showHideImageMenu(false);
        }

        @Override
        public void onEdit(StickerView stickerView) {
//            CustomLogHandler.printVerbose(TAG, "StickerView:---onEdit");
        }

        @Override
        public void onTop(StickerView stickerView) {
//            CustomLogHandler.printVerbose(TAG, "StickerView:---onTop");
        }

        @Override
        public void onClick(StickerView stickerView) {
//            CustomLogHandler.printVerbose(TAG, "StickerView:---onClick");
            showHideTextMenu(false);
            showHideColorSwaches(false);

            if (editableViewId != stickerView.getStickerId()) {
                showHideBottomBarContainer(false);
                editableViewId = stickerView.getStickerId();
            }


            if (editableView != null)
                showViewEditable(false);
            editableView = stickerView;
            showViewEditable(true);
            if (mapv_menu_image.getVisibility() == View.GONE)
                showHideImgaeViewActionBar(true);
        }
    };
    private int mProductImageOriginalWidth, mProductImageOriginalHeight;
    private int mSelectedColor = 1;
    private ColorAdapter mColorAdapter;
    private SingleColorAdapter mSingleColorAdapter;
    private RecyclerView rv_ProductColor, rvPmsColorSwatches;
    private ZoomLayout mZoomLayout;
    private ColorSwatchesAdapter mColorSwatchesAdapter;
    private PmsColorVo.DataVo colorDataVo;
    private RelatedPmsColorVo.DataVo relatedPmsColorVo;
    private CheckBox mimremove_cbRemoveWhite, mimremove_cbRemoveBlack;
    private ViewsEffectsThread mViewsEffectsThread;
    ;
    private Handler mEffectHandler;
    private int dominantColor;

    private Bitmap convertToMutable(Bitmap imgIn) {
        try {
            //this is the file going to use temporally to save the bytes.
            // This file will not be a image, it will store the raw image data.
            File file = new File(Environment.getExternalStorageDirectory() + File.separator + "temp.tmp");

            //Open an RandomAccessFile
            //Make sure you have added uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
            //into AndroidManifest.xml file
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");

            // get the width and height of the source bitmap.
            int width = imgIn.getWidth();
            int height = imgIn.getHeight();
            Bitmap.Config type = imgIn.getConfig();

            //Copy the byte to the file
            //Assume source bitmap loaded using options.inPreferredConfig = Config.ARGB_8888;
            FileChannel channel = randomAccessFile.getChannel();
            MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_WRITE, 0, imgIn.getRowBytes() * height);
            imgIn.copyPixelsToBuffer(map);
            //recycle the source bitmap, this will be no longer used.
//            imgIn.recycle();
            System.gc();// try to force the bytes from the imgIn to be released

            //Create a new bitmap to load the bitmap again. Probably the memory will be available.
            imgIn = Bitmap.createBitmap(width, height, type);
            map.position(0);
            //load it back from temporary
            imgIn.copyPixelsFromBuffer(map);
            //close the temporary file and channel , then delete that also
            channel.close();
            randomAccessFile.close();

            // delete the temp file
            file.delete();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return imgIn;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_virtual);

        mContext = this;
        mToolbar = (Toolbar) findViewById(R.id.virtual_toolbar);
        setupToolbar();

        bundleArguments(savedInstanceState == null ? getIntent().getExtras() : savedInstanceState);
        initView();

        callGetPmsColor();

        mViewsEffectsThread = new ViewsEffectsThread(ProductVirtualActivity.this);
        mViewsEffectsThread.start();

        mEffectHandler = new Handler();

    }

    private void callGetPmsColor() {
        List<NameValuePair> postHeader = Util.getDefaultHeader(this);
        FormHttpCaller formHttpCaller = new FormHttpCaller(this, WSUrlConstant.productApiGetPmsColor(), APIType.METHOD_GET, postHeader, WSRequestCodeConstant.REQUEST_GET_PMS_COLOR, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    private boolean bundleArguments(Bundle bundle) {
        if (bundle == null) {
            finish();
            return true;
        }
        mProductBasicInfo = (ProductDetailVo.DataVo.BasicInformationVo) bundle.get(BASIC_INFO);
        mProductImprintInfo = (ProductDetailVo.DataVo.ImprintInfoVo) bundle.get(IMPRINT_INFO);
        mProductSideDetail = (ProductDetailVo.DataVo.SidesVo.SideImageVo) bundle.get(SIDE_DETAIL);
        mConfigurationOptionsVo = (GetSupplierDetailVo.DataVo.SupplierDetailVo.ConfigurationOptionsVo) bundle.get(CONFIGURATION_OPTION);

        return false;
    }

    private void setupToolbar() {
        mToolbar.setNavigationIcon(R.drawable.back_icon);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }


        });

        mPreview = (ImageView) findViewById(R.id.vt_ivPreview);

        mPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideColorSwaches(false);
                isProductPreview = !mProductOverlayImprintArea.isPreviewView();

                showHideProductPreview(isProductPreview);
                mZoomLayout.setZoomMin();
                if (isProductPreview) {

                    initDefaultEditableView();
                    loadPreviewVirtualImage();
                    showHideTextMenu(false);
                    showHideImageMenu(false);
                    mapv_menueffects.setVisibility(View.GONE);

//                    mvt_btnSave.setVisibility(View.VISIBLE);

                } else {
                    mPreview.setImageResource(R.drawable.preview);
                    mapv_main_menu_layout.setVisibility(View.VISIBLE);
                    mapv_menu_text.setVisibility(View.GONE);
                    mProductOverlayImprintArea.setPreviewView(false);
                    mProductOverlayImprintArea.setProductBitmapDrawable(null);
                    mProductOverlayImprintArea.postInvalidate();
                    showViewEditable(false);
//                    mvt_btnSave.setVisibility(View.GONE);
//                    mProductOverlayImprintArea.reDraw();
                }
            }
        });

        mvt_btnSave = (ImageView) findViewById(R.id.vt_btnSave);
        mvt_btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomLogHandler.printVerbose(TAG, "iszoom::" + (mZoomLayout.isLayourZoom() ? "Yes" : "No"));
                if (isProductPreview) {
                    if (rlCustomeDraw.getChildCount() > 1) {
                        checkSinglePermission(ProductVirtualActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "Allowed STORAGE permission for save your virtual work.", REQUEST_VIRTUAL_SAVE_PERMISSION);
                    } else {
                        Toast.makeText(ProductVirtualActivity.this, "no any artwork found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ProductVirtualActivity.this, "Click on preview before save", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String[] permissionsForActivity = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        checkMultiplePermission(this, new PermissionVo(permissionsForActivity, "Virtual application not working properly without CAMERA and STORAGE permission"), REQUEST_ALL_PERMISSION);

    }

    private void saveArtworkDialog() {
        CommonUtil.showYesNoDialog(ProductVirtualActivity.this, null, "want to save artwork for this product?", "YES", "NO", true, REQUEST_DIALOG_SAVE_ARTWORK, this, getSupportFragmentManager());
    }

    private boolean saveVirtualProduct() {

        mZoomLayout.setDrawingCacheEnabled(true);
        Bitmap bitmap = mZoomLayout.getDrawingCache();

        String filesDirectory = getSkuImageDirectoryPath();
        String fileName = getSkuImageFileName();

        File saveFilePath = new File(filesDirectory, fileName);

        return Util.saveBitmap(this, saveFilePath, bitmap);
    }

    @NonNull
    private String getSkuArtFileName(long artId) {
        return mProductBasicInfo.getSku() + "_" + mProductImprintInfo.getLocationKey() + "_" + artId + ".vt";
    }

    @NonNull
    private String getSkuArtDirectoryPath(boolean wantCreate) {
        return AppConstant.getAppProductArtworkDirectory(mProductBasicInfo.getSku() + "/" + mProductImprintInfo.getLocationKey(), wantCreate);
    }

    @NonNull
    private String getSkuImageFileName() {
        return mProductBasicInfo.getSku() + "_" + mProductSideDetail.getColorId() + "_" + mProductImprintInfo.getLocationKey().replace("_","") + ".png";
    }

    @NonNull
    private String getSkuImageDirectoryPath() {
        return AppConstant.getAppProductImageDirectory(mProductBasicInfo.getSku() + "/" + mProductSideDetail.getColorId());
    }

    private void initView() {

        rlCustomeDraw = (RelativeLayout) findViewById(R.id.apv_rlCustomDraw);
        sdv_ProductImage = (SimpleDraweeView) findViewById(R.id.apv_sdvProductImage);
        mZoomLayout = (ZoomLayout) findViewById(R.id.apv_zlZoomLayout);

        if (mProductSideDetail != null)
            loadVirtualImageInfo();


        //Bottom Menu initialization
        tvImageMenu = (TextView) findViewById(R.id.mml_tvImageMenu);
        tvTextMenu = (TextView) findViewById(R.id.mml_tvTextMenu);
        tvEffectMenu = (TextView) findViewById(R.id.mml_tvEffectsMenu);

        //Check in Product detail API
        if (mProductImprintInfo.getImprintSettings().getAddimage() == 1) {
            tvImageMenu.setVisibility(View.VISIBLE);
        }
        if (mProductImprintInfo.getImprintSettings().getAddtext() == 1) {
            tvTextMenu.setVisibility(View.VISIBLE);
        }

        /*Main Menu*/
        mapv_main_menu_layout = findViewById(R.id.apv_main_menu_layout);
        mapv_menu_image = findViewById(R.id.apv_menu_image);
        mapv_menu_text = findViewById(R.id.apv_menu_text);
        mapv_back = (RelativeLayout) findViewById(R.id.apv_back);
        mapv_menuimage_rotate = findViewById(R.id.apv_menuimage_rotate);
        mapv_menuimage_layer = findViewById(R.id.apv_menuimage_layer);
        mapv_menuimage_alignment = findViewById(R.id.apv_menuimage_alignment);
        mapv_menuimage_opacity = findViewById(R.id.apv_menuimage_opacity);
        mapv_menuimage_sharpness = findViewById(R.id.apv_menuimage_sharpness);
        mapv_menuimage_removecolor = findViewById(R.id.apv_menuimage_removecolor);
        mapv_menutext_fonttype = findViewById(R.id.apv_menutext_fonttype);
        mapv_menutext_fontcolor = findViewById(R.id.apv_menutext_fontcolor);
        mapv_menutext_fontsize = findViewById(R.id.apv_menutext_fontsize);
        mapv_menutext_fontstyle = findViewById(R.id.apv_menutext_fontstyle);
        mapv_menutext_fontcurve = findViewById(R.id.apv_menutext_fontcurve);
        mapv_menueffects = findViewById(R.id.apv_menueffects);

        mimremove_cbRemoveWhite = (CheckBox) findViewById(R.id.imremove_cbRemoveWhite);

        mimremove_cbRemoveBlack = (CheckBox) findViewById(R.id.imremove_cbRemoveBlack);


        //Check in Supplier Detail API
        if (mConfigurationOptionsVo.getRemovewhite() == 1) {
            mimremove_cbRemoveWhite.setVisibility(View.VISIBLE);
        }
        if (mConfigurationOptionsVo.getRemoveblack() == 1) {
            mimremove_cbRemoveBlack.setVisibility(View.VISIBLE);
        }

        mapv_svCustomeView = (ShowView) findViewById(R.id.apv_svCustomeView);

        sbOpacity = (SeekBar) findViewById(R.id.imo_sbOpacity);
        sbSharpness = (SeekBar) findViewById(R.id.ims_sbSharpness);
        sb_fontSize = (SeekBar) findViewById(R.id.tmfontsize_sbSize);
        sb_Curve = (SeekBar) findViewById(R.id.tmc_sbCurve);

        rv_ProductColor = (RecyclerView) findViewById(R.id.tmfc_rvColor);
        rvPmsColorSwatches = (RecyclerView) findViewById(R.id.apv_rvColor);


        mProductOverlayImprintArea = (ProductOverlayImageView) findViewById(R.id.apv_ivProductpreviewImage);

        //Bottom Menu Click Event
        tvImageMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddMediaFragment addMediaFragment = new AddMediaFragment();
                addMediaFragment.setOnImageActionFromListner(ProductVirtualActivity.this);
                showBottomBarContainer(addMediaFragment, ADD_MEDIA_FRAGMENT);
                showHideColorSwaches(false);
            }
        });

        tvTextMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputDialog("", true);

            }
        });

        ivMulticolor = (ImageView) findViewById(R.id.le_ivMulticolor);
        ivSinglecolor = (ImageView) findViewById(R.id.le_ivSinglecolor);
        ivEmboss = (ImageView) findViewById(R.id.le_ivEmboss);
        ivDeboss = (ImageView) findViewById(R.id.le_ivDeboss);
        ivEngrave = (ImageView) findViewById(R.id.le_ivEngrave);
        ivEmbroidery = (ImageView) findViewById(R.id.le_ivEmbroidery);
        ivSatinEach = (ImageView) findViewById(R.id.le_ivSatinEach);
        ivWooden = (ImageView) findViewById(R.id.le_ivWooden);
        ivToneonTone = (ImageView) findViewById(R.id.le_ivTone_on_tone);
        ivLatherEngraved = (ImageView) findViewById(R.id.le_ivLather_Engraved);


        tvEffectMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickEffect();
            }
        });

        backToMainMenu();

//        addText();
        imageCrop();

        imageRotationFlip();
        imageRotateLeft();
        imageRotateRight();
        imageFlipHorizontal();
        imageFlipVertical();

        imageLayerOrder();
        /*imageMoveUp();
        imageMoveDown();*/
        imageMoveTop();
        imageMoveBottom();

        imageAlignment();
        imageLeftAlign();
        imageRightAlign();
        imageCenterAlign();

        imageOpacity();

        imageSharpness();

        imageRemoveColor();
        imgRemoveWhite();
        imgRemoveBlack();

        textFontFace();
        textFontColor();
        textFontSize();

        textFontStyle();
        textBold();
        textItalic();
        textUnderline();

        textRotationFlip();
        textLayerOrder();
        textAlignment();
        textOpacity();
        textFontCurve();

        doDebossEffect();
        doEmbossEffect();
        doEngraveEffect();
        doDebossEffect();
        doSatinEachEffect();
        doWoodenEffect();
        doEmroideryEffect();
        doToneOnToneEffect();
        doLatherEngravedEffect();
    }

    private void onClickEffect() {
        showHideBottomBarContainer(false);
        showHideColorSwaches(false);
        mapv_main_menu_layout.setVisibility(View.GONE);
        mapv_back.setVisibility(View.VISIBLE);

        if (mProductImprintInfo.getImprintMethod().getSingleColor() != null && mProductImprintInfo.getImprintMethod().getSingleColor().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivSinglecolor.setVisibility(View.VISIBLE);
            doSingleColorEffect();

        }
        if (mProductImprintInfo.getImprintMethod().getPlain() != null && mProductImprintInfo.getImprintMethod().getPlain().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivMulticolor.setVisibility(View.VISIBLE);
            doMulticolorEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getEmboss() != null && mProductImprintInfo.getImprintMethod().getEmboss().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivEmboss.setVisibility(View.VISIBLE);
            doEmbossEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getDeboss() != null && mProductImprintInfo.getImprintMethod().getDeboss().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivDeboss.setVisibility(View.VISIBLE);
            doDebossEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getEngraved() != null && mProductImprintInfo.getImprintMethod().getEngraved().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivEngrave.setVisibility(View.VISIBLE);
            doEngraveEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getLeather_engrave() != null && mProductImprintInfo.getImprintMethod().getLeather_engrave().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivLatherEngraved.setVisibility(View.VISIBLE);
            doLatherEngravedEffect();

        }
        if (mProductImprintInfo.getImprintMethod().getEmbroidery() != null && mProductImprintInfo.getImprintMethod().getEmbroidery().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivEmbroidery.setVisibility(View.VISIBLE);
            doEmroideryEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getGlass() != null && mProductImprintInfo.getImprintMethod().getGlass().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivSatinEach.setVisibility(View.VISIBLE);
            doSatinEachEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getWooden() != null && mProductImprintInfo.getImprintMethod().getWooden().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivWooden.setVisibility(View.VISIBLE);
            doWoodenEffect();
        }
        if (mProductImprintInfo.getImprintMethod().getTone_on_tone() != null && mProductImprintInfo.getImprintMethod().getTone_on_tone().contains("1")) {
            mapv_menueffects.setVisibility(View.VISIBLE);
            ivToneonTone.setVisibility(View.VISIBLE);
            doToneOnToneEffect();
        }
    }

    private void doMulticolorEffect() {
        ivMulticolor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideColorSwaches(false);
                showHideBottomBarContainer(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.MULTICOLOR);/*
                int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {

                    for (int i = 0; i < childViewsCount; i++) {
//                        CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                        View v = rlCustomeDraw.getChildAt(i);
                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            stickerView.setEffectType(EffectTypes.MULTICOLOR);

                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            int color = bubbleTextView.getmFontVo().getFontColor();
                            ((BubbleTextView) v).setFontColor(color);

                            ((BubbleTextView) v).setEmbossEffect(false);
                            ((BubbleTextView) v).setEngraveEffect(false);
                            ((BubbleTextView) v).setDebossEffect(false);
                            ((BubbleTextView) v).setSatinEachEffect(false);
                            ((BubbleTextView) v).setWoodenEffect(false);
                            ((BubbleTextView) v).setEmbroidery(false, color);


                        }

                    }
                }*/
            }
        });
    }

    private void doSingleColorEffect() {
        ivSinglecolor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {

                    showHideBottomBarContainer(true);
                    mapv_menutext_fontcolor.setVisibility(View.VISIBLE);

                    LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
                    rv_ProductColor.setLayoutManager(layoutManager);

                    mSingleColorAdapter = new SingleColorAdapter(getApplicationContext(), EffectTypes.SINGLE_COLOR, colorDataVo.getPmscolor(), -1, ProductVirtualActivity.this);
                    rv_ProductColor.setAdapter(mSingleColorAdapter);

                }
            }
        });
    }

    private void doEmbossEffect() {
        ivEmboss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.EMBOSS);
             /*    int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {
                    applyEffectsOnViews(rlCustomeDraw, EffectTypes.EMBOSS);

                    for (int i = 0; i < childViewsCount; i++) {
                        View v = rlCustomeDraw.getChildAt(i);
                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            if (stickerView.getmImageVo().getEffectType() != EffectTypes.EMBOSS) {
                                ((StickerView) v).setEmbossEffect(true);
                            }
                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            if (!bubbleTextView.getmFontVo().isEmboss()) {
                                ((BubbleTextView) v).setEmbossEffect(true);
                            }
                        }
                    }
                }*/
            }
        });
    }

    private void doDebossEffect() {
        ivDeboss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.DEBOSS);
                /*applyEffectsOnViews(rlCustomeDraw);
                int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {


                    for (int i = 0; i < childViewsCount; i++) {
                        View v = rlCustomeDraw.getChildAt(i);

                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            if (stickerView.getmImageVo().getEffectType() != EffectTypes.DEBOSS) {
                                CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                                ((StickerView) v).setDebossEffect(true);
                            }
                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            if (!bubbleTextView.getmFontVo().isDeboss()) {
                                ((BubbleTextView) v).setDebossEffect(true);
                            }
                        }
                    }
                }*/
            }
        });
    }

    private void doEmroideryEffect() {
        ivEmbroidery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);

                int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {

                    /*for (int i = 0; i < childViewsCount; i++) {
                        View v = rlCustomeDraw.getChildAt(i);
                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            if (!stickerView.getmImageVo().isEngrave()) {
                                CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                                ((StickerView) v).setEmbroideryEffect(true);
                            }
                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            if (!bubbleTextView.getmFontVo().isEngrave()) {
                                ((BubbleTextView) v).setEngraveEffect(true);
                            }

                        }
                    }*/
                    showHideBottomBarContainer(true);
                    mapv_menutext_fontcolor.setVisibility(View.VISIBLE);

                    LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
                    rv_ProductColor.setLayoutManager(layoutManager);

                    mSingleColorAdapter = new SingleColorAdapter(getApplicationContext(), EffectTypes.EMBROIDERY, colorDataVo.getPmscolor(), -1, ProductVirtualActivity.this);
                    rv_ProductColor.setAdapter(mSingleColorAdapter);
                }
            }
        });
    }


    private void doEngraveEffect() {
        ivEngrave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.ENGRAVE);

             /*   int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {
                    applyEffectsOnViews(rlCustomeDraw,EffectTypes.ENGRAVE);/*
                    for (int i = 0; i < childViewsCount; i++) {
                        View v = rlCustomeDraw.getChildAt(i);
                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            if (stickerView.getmImageVo().getEffectType() != EffectTypes.ENGRAVE) {
                                CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                                ((StickerView) v).setEngraveEffect(true);
                            }
                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            if (!bubbleTextView.getmFontVo().isEngrave()) {
                                ((BubbleTextView) v).setEngraveEffect(true);
                            }

                        }
                    }
                }*/
            }
        });
    }

    private void doSatinEachEffect() {
        ivSatinEach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.SATIN_EACH);
               /*
                               int childViewsCount = rlCustomeDraw.getChildCount();

               if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {

                   /for (int i = 0; i < childViewsCount; i++) {
                        View v = rlCustomeDraw.getChildAt(i);

                        if (v instanceof StickerView) {
                            StickerView stickerView = (StickerView) v;
                            if (stickerView.getmImageVo().getEffectType() != EffectTypes.SATIN_EACH) {
                                CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                                ((StickerView) v).setSatinEachEffect(true);
                            }
                        } else if (v instanceof BubbleTextView) {
                            BubbleTextView bubbleTextView = (BubbleTextView) v;
                            if (!bubbleTextView.getmFontVo().isSatinEtch()) {
                                ((BubbleTextView) v).setSatinEachEffect(true);
                            }
                        }
                    }
                }*/
            }
        });
    }

    private void doWoodenEffect() {
        ivWooden.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.WOODEN);
               /* int childViewsCount = rlCustomeDraw.getChildCount();
                if (childViewsCount < 2) {
                    Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
                } else {


                }*/
                /*
                for (int i = 0; i < childViewsCount; i++) {
                    View v = rlCustomeDraw.getChildAt(i);

                    if (v instanceof StickerView) {
                        StickerView stickerView = (StickerView) v;
                        if (stickerView.getmImageVo().getEffectType() != EffectTypes.WOODEN) {
                            CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                            ((StickerView) v).setWoodenEffect(true);
                        }
                    } else if (v instanceof BubbleTextView) {
                        BubbleTextView bubbleTextView = (BubbleTextView) v;
                        if (!bubbleTextView.getmFontVo().isWooden()) {
                            ((BubbleTextView) v).setWoodenEffect(true);
                        }

                    }
                }*/
            }
        });
    }

    private void applyEffectsOnViews(ViewGroup view, EffectTypes effectTypes) {
        applyEffectsOnViews(view, effectTypes, Color.BLACK);
    }

    private void applyEffectsOnViews(ViewGroup viewGroup, EffectTypes effectTypes, int mSelectedColor) {
        int childViewsCount = viewGroup.getChildCount();
        if (childViewsCount < 2) {
            Toast.makeText(ProductVirtualActivity.this, "Please add any Object.", Toast.LENGTH_SHORT).show();
        } else {
            CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, null, true, null, 1, getSupportFragmentManager());
            for (int i = 0; i < childViewsCount; i++) {
                View v = rlCustomeDraw.getChildAt(i);

                if (v instanceof StickerView) {
                    StickerView stickerView = (StickerView) v;
                    stickerView.setEffectType(effectTypes);

                    if (effectTypes == EffectTypes.SINGLE_COLOR)
                        stickerView.setSingleColorWithColorCode(mSelectedColor);
                    else if (effectTypes == EffectTypes.EMBROIDERY)
                        stickerView.setEmbroideryEffectWithColor(mSelectedColor);
                    else if (effectTypes == EffectTypes.TONE_ON_TONE)
                        stickerView.setToneOnToneEffect(dominantColor);
                    else if (effectTypes == EffectTypes.LEATHER_ENGRAVED)
                        stickerView.setLeatherEngraveEffect(dominantColor);

                    executeStickerViewThread(stickerView);
                } else if (v instanceof BubbleTextView) {

                    BubbleTextView bubbleTextView = (BubbleTextView) v;
                    bubbleTextView.setEffectType(effectTypes);

                    if (effectTypes == EffectTypes.SINGLE_COLOR)
                        bubbleTextView.setSingleColorWithColorCode(mSelectedColor);
                    else if (effectTypes == EffectTypes.EMBROIDERY)
                        bubbleTextView.setEmbroideryEffectWithColor(mSelectedColor);
                    else if (effectTypes == EffectTypes.TONE_ON_TONE)
                        bubbleTextView.setToneOnToneEffect(dominantColor);
                    else if (effectTypes == EffectTypes.LEATHER_ENGRAVED)
                        bubbleTextView.setLeatherEngraveEffect(dominantColor);

                    executeBubbleViewThread(bubbleTextView);
                }

            }
        }
    }

    private void doToneOnToneEffect() {
        ivToneonTone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.TONE_ON_TONE, dominantColor);

            }
        });
    }

    public void doLatherEngravedEffect() {
        ivLatherEngraved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHideBottomBarContainer(false);
                showHideColorSwaches(false);
                applyEffectsOnViews(rlCustomeDraw, EffectTypes.LEATHER_ENGRAVED, dominantColor);
            }
        });
    }

    private void loadVirtualImageInfo() {

        String productImageUrl = mProductSideDetail.getProductImage();
        ControllerListener controllerListener = new BaseControllerListener<ImageInfo>() {
            @Override
            public void onFinalImageSet(
                    String id,
                    @Nullable final ImageInfo imageInfo,
                    @Nullable Animatable anim) {
                if (imageInfo == null) {
                    return;
                }
                QualityInfo qualityInfo = imageInfo.getQualityInfo();
                FLog.d("Final image received! " +
                                "Size %d x %d",
                        "Quality level %d, good enough: %s, full quality: %s",
                        imageInfo.getWidth(),
                        imageInfo.getHeight(),
                        qualityInfo.getQuality(),
                        qualityInfo.isOfGoodEnoughQuality(),
                        qualityInfo.isOfFullQuality());


                mProductImageOriginalWidth = imageInfo.getWidth();
                mProductImageOriginalHeight = imageInfo.getHeight();

                CustomLogHandler.printVerbose(TAG, "Final image received!");
                CustomLogHandler.printVerbose(TAG, "Width:--" + imageInfo.getWidth() + "Height:--" + imageInfo.getHeight());

                sdv_ProductImage.post(new Runnable() {
                    @Override
                    public void run() {
                        CustomLogHandler.printVerbose(TAG, "Drawee Height:--" + sdv_ProductImage.getHeight());
                        //Draw Overlay Imparint areahade
                        drawImprintAreasOverlay(mProductImprintInfo, imageInfo.getWidth(), imageInfo.getHeight(), sdv_ProductImage.getWidth(), sdv_ProductImage.getHeight());

                        drawPreviousArtWork();

                    }
                });
            }

            @Override
            public void onIntermediateImageSet(String id, @Nullable ImageInfo imageInfo) {
                FLog.d("Intermediate image received", "id:--" + id);
            }

            @Override
            public void onFailure(String id, Throwable throwable) {
                FLog.e(getClass(), throwable, "Error loading %s", id);
            }
        };

        Postprocessor redMeshPostprocessor = new BasePostprocessor() {
            @Override
            public String getName() {
                return "redMeshPostprocessor";
            }

            @Override
            public void process(Bitmap bitmap) {

                dominantColor = getDominantColor(bitmap);
            }
        };

        ImageRequest request = ImageRequestBuilder.newBuilderWithSource(Uri.parse(productImageUrl))
                .setPostprocessor(redMeshPostprocessor)
                .build();


        DraweeController controller = Fresco.newDraweeControllerBuilder()
                .setControllerListener(controllerListener)
                .setImageRequest(request)
                // other setters
                .build();
        sdv_ProductImage.setController(controller);
    }

    public static int getDominantColor(Bitmap bitmap) {
        List<Palette.Swatch> swatchesTemp = Palette.from(bitmap).generate().getSwatches();
        List<Palette.Swatch> swatches = new ArrayList<Palette.Swatch>(swatchesTemp);
        Collections.sort(swatches, new Comparator<Palette.Swatch>() {
            @Override
            public int compare(Palette.Swatch swatch1, Palette.Swatch swatch2) {
                return swatch2.getPopulation() - swatch1.getPopulation();
            }
        });
        return swatches.size() > 0 ? swatches.get(0).getRgb() : bitmap.getPixel(bitmap.getWidth() / 2, bitmap.getHeight() / 2);
    }

    private void drawPreviousArtWork() {
        File file = new File(getSkuArtDirectoryPath(false));

        CustomLogHandler.printVerbose(TAG, "File path:-" + file.getPath());

        if (file.exists()) {
            File[] fileList = file.listFiles();

            if (fileList != null && fileList.length > 0) {
                new DrawPreviousArtWorkAsync(this, fileList).execute();
            }

        }
        /*CustomLogHandler.printVerbose(TAG,"FileCount:-"+filelist.length);

        for (int i = 0; i < filelist.length; i++) {
            CustomLogHandler.printVerbose(TAG,":--"+filelist[i]);
        }*/
    }


    private void drawImprintAreasOverlay(ProductDetailVo.DataVo.ImprintInfoVo imprintInfoVo, int rootBitmapWidth, int rootBitmapHeight, int draweeViewWidth, int draweeViewHeight) {
        CustomLogHandler.printVerbose(TAG, "Height:--" + sdv_ProductImage.getHeight());
        mProductOverlayImprintArea.drawImprintAreaPreviewView(imprintInfoVo, rootBitmapWidth, rootBitmapHeight, draweeViewWidth, draweeViewHeight, new ProductOverlayImageView.OnPreviewViewDrawResultListener() {
            @Override
            public void onPreviewViewDrawLoad() {
//                CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
            }

            @Override
            public void onPreviewViewResult(boolean result) {
                CommonUtil.dismissProgressDialog();
                //Reset Imprint Parent Relative View Width and Height
                int screenWidth = imprintViewResizeWidth(mProductOverlayImprintArea.getWidth(), mProductOverlayImprintArea.getHeight());
                int setUpHeight = (int) imprintViewResizeHeight(screenWidth, mProductOverlayImprintArea.getWidth(), mProductOverlayImprintArea.getHeight());
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(sdv_ProductImage.getWidth(), setUpHeight);
                rlCustomeDraw.setLayoutParams(layoutParams);
                if (result) {
//                    Toast.makeText(ProductVirtualActivity.this, "Process Done", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProductVirtualActivity.this, "Error", Toast.LENGTH_SHORT).show();

                }
            }
        });

        mProductOverlayImprintArea.reDraw();
    }

    private void loadPreviewVirtualImage() {

        ImagePipeline imagePipeline = Fresco.getImagePipeline();

        String productImageUrl = mProductSideDetail.getProductImage();
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(productImageUrl))
                .setRequestPriority(Priority.HIGH)
                .setLowestPermittedRequestLevel(ImageRequest.RequestLevel.FULL_FETCH)
                .build();

        DataSource<CloseableReference<CloseableImage>> dataSource =
                imagePipeline.fetchDecodedImage(imageRequest, this);

        try {
            dataSource.subscribe(new BaseBitmapDataSubscriber() {
                @Override
                public void onNewResultImpl(@Nullable Bitmap bitmap) {
                    if (bitmap == null) {
                        Log.d(TAG, "Bitmap data source returned success, but bitmap null.");
                        return;
                    }

                    CustomLogHandler.printVerbose(TAG, "Bitmap:--width:-" + bitmap.getWidth());
                    CustomLogHandler.printVerbose(TAG, "Bitmap:--height:-" + bitmap.getHeight());


                    Bitmap b = convertToMutable(bitmap);

//                   final  Bitmap newBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false);


                    mProductOverlayImprintArea.setPreviewView(true);
                    mProductOverlayImprintArea.setProductBitmapDrawable(b);
                    mProductOverlayImprintArea.postInvalidate();
                    mPreview.setImageResource(R.drawable.preview_off);
                    // The bitmap provided to this method is only guaranteed to be around
                    // for the lifespan of this method. The image pipeline frees the
                    // bitmap's memory after this method has completed.
                    //
                    // This is fine when passing the bitmap to a system process as
                    // Android automatically creates a copy.
                    //
                    // If you need to keep the bitmap around, look into using a
                    // BaseDataSubscriber instead of a BaseBitmapDataSubscriber.
                }

                @Override
                public void onFailureImpl(DataSource dataSource) {
                    // No cleanup required here
                }
            }, CallerThreadExecutor.getInstance());


        } finally {
            if (dataSource != null) {
                dataSource.close();
            }
        }

    }

    private void showHideProductPreview(boolean isProductPreview) {
        removeBottomBarContainerFragment();
        showHideBottomBarContainer(false);
        if (rlCustomeDraw.getChildCount() > 1) {
            enableDisableViewTouch(isProductPreview);
            showHideImgaeViewActionBar(!isProductPreview);
            showHideTextViewActionBar(!isProductPreview);
            showViewEditable(!isProductPreview);
        }
        mapv_main_menu_layout.setVisibility(View.GONE);

    }

    //Enable\Disable Click Event of all views in Imprint area layout
    private void enableDisableViewTouch(boolean isTouchable) {

        int childCount = rlCustomeDraw.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View view = rlCustomeDraw.getChildAt(i);
            if (view instanceof BubbleTextView)
                ((BubbleTextView) view).setInPreviewMode(isTouchable);
            else if (view instanceof StickerView)
                ((StickerView) view).setInPreviewMode(isTouchable);

        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(BASIC_INFO, mProductBasicInfo);
        outState.putParcelable(IMPRINT_INFO, mProductImprintInfo);
        outState.putParcelable(SIDE_DETAIL, mProductSideDetail);
        outState.putParcelable(CONFIGURATION_OPTION, mConfigurationOptionsVo);
    }

    /*private void addText() {
        //tltml_rlAddText = (RelativeLayout) findViewById(R.id.tml_rlAddText);
        //tltml_rlAddText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (//tltml_rlAddText.isPressed()) {
                    //tltml_rlAddText.setSelected(true);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }
            }
        });
    }*/

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mProductBasicInfo = (ProductDetailVo.DataVo.BasicInformationVo) savedInstanceState.get(BASIC_INFO);
        mProductImprintInfo = (ProductDetailVo.DataVo.ImprintInfoVo) savedInstanceState.get(IMPRINT_INFO);
        mProductSideDetail = (ProductDetailVo.DataVo.SidesVo.SideImageVo) savedInstanceState.get(SIDE_DETAIL);
        mConfigurationOptionsVo = (GetSupplierDetailVo.DataVo.SupplierDetailVo.ConfigurationOptionsVo) savedInstanceState.get(CONFIGURATION_OPTION);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // request the thread to stop
        mViewsEffectsThread.requestStop();
    }

    /***
     * Create image into sdcard
     *
     * @return File
     * @throws IOException
     */
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );


        return image;
    }

    private void addBubble(String text) {

        // Remove view selection
        showViewEditable(false);

        initDefaultEditableView();

        long viewId = System.currentTimeMillis();
        final BubbleTextView bubbleTextView = new BubbleTextView(this,
                Color.BLACK, viewId);
        bubbleTextView.setText(text, 150, 75);
        bubbleTextView.setOperationListener(bubbleTextViewListener);

        executeBubbleViewThread(bubbleTextView);

        editableView = bubbleTextView;
        showViewEditable(true);
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        rlCustomeDraw.addView(bubbleTextView, lp);


    }

    private void inputDialog(final String pBubbleText, boolean isNew) {
        textFragment = AddTextFragment.newInstance(pBubbleText, isNew);
        showBottomBarContainer(textFragment, ADD_NEW_TEXT_TAG);
        showHideColorSwaches(false);
        textFragment.setCompleteCallBack(new AddTextFragment.CompleteCallBack() {
            @Override
            public void onComplete(String str, boolean isBubbleNew) {
                if (str != null && str.length() > 0) {
                    if (!isBubbleNew && editableView != null) {
                        BubbleTextView textView = (BubbleTextView) editableView;
                        textView.setText(str, 150, 75);
                        executeBubbleViewThread(textView);
                    } else {
                        addBubble(str);
                    }
//                mBaseVos.add(((BubbleTextView) bubbleTextView).calculate(model));
                    showViewEditable(true);
                    showHideTextViewActionBar(true);
                } else {
                    Toast.makeText(mContext, "Invalid text.", Toast.LENGTH_SHORT).show();
                }
                removeBottomBarContainerFragment();
            }
        });
    }

    private void showBottomBarContainer(Fragment fragment, String tag) {
        showHideBottomBarContainer(true);
        showHideColorSwaches(false);
        replaceFragment(R.id.apv_bottombarContainer, false, fragment, tag);
    }

    /**
     * Back to Main menu
     */

    public void backToMainMenu() {
//        RelativeLayout rlBackMenu = (RelativeLayout) findViewById(R.id.tml_rlBack);
        mapv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapv_main_menu_layout.setVisibility(View.VISIBLE);
                mapv_back.setVisibility(View.GONE);
                mapv_menu_image.setVisibility(View.GONE);
                mapv_menu_text.setVisibility(View.GONE);
                mapv_menueffects.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menueffects.setVisibility(View.GONE);
                showViewEditable(false);
                showHideColorSwaches(false);
                showHideBottomBarContainer(false);
                initDefaultEditableView();
            }
        });


    }

    private void initDefaultEditableView() {
        editableView = null;
        editableViewId = -1;
    }

    /**
     * Image Crop
     */
    public void imageCrop() {
        showHideBottomBarContainer(true);
        rlCropImage = (RelativeLayout) findViewById(R.id.iml_rlImageCrop);
        rlCropImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StickerView view = (StickerView) editableView;
                Uri mediaPath = Uri.fromFile(new File(view.getBitmapPath()));
                CustomLogHandler.printVerbose(TAG, "resultUri:--" + mediaPath.getPath());

                UCrop.Options options = new UCrop.Options();
                options.setActiveWidgetColor(getResources().getColor(R.color.menu_selected));
                options.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
                options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
                options.setToolbarTitleTextColor(getResources().getColor(R.color.white));
                options.setCompressionFormat(Bitmap.CompressFormat.PNG);


                String appDirectory = AppConstant.getAppTempDirectory();
                File cropFile = new File(appDirectory, System.currentTimeMillis() + ".png");

                UCrop.of(mediaPath, Uri.fromFile(cropFile))
                        .withOptions(options)
                        .start(ProductVirtualActivity.this);

                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);

                if (rlCropImage.isPressed()) {
                    //rlCropImage.setSelected(true);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(false);
                }
            }
        });
        rlCropImage.invalidate();
    }

    /**
     * Image Rotation Flip
     */

    public void imageRotationFlip() {

        rlRotation = (RelativeLayout) findViewById(R.id.iml_rlImageRotate);
        rlRotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menuimage_rotate.setVisibility(View.VISIBLE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);

                if (rlRotation.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(true);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(false);

                }
            }
        });
        rlRotation.invalidate();

    }

    /**
     * Image Left Rotation
     */
    public void imageRotateLeft() {
        mimr_ivRLeft = (ImageView) findViewById(R.id.imr_ivRLeft);
        mimr_ivRLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editableView != null) {
                    if (editableView instanceof StickerView) {
                        StickerView stickerView = (StickerView) editableView;
                        stickerView.rotateView(false);
                    } else {
                        BubbleTextView bubbleTextView = (BubbleTextView) editableView;
                        bubbleTextView.rotateView(false);
                    }
                }
                if (mimr_ivRLeft.isPressed()) {
//                    mimr_ivRLeft.setSelected(true);
//                    mimr_ivRRight.setSelected(false);
//                    mimr_ivLFilp.setSelected(false);
//                    mimr_ivRFlip.setSelected(false);
                }
            }
        });

    }

    /**
     * Image Right Rotation
     */
    public void imageRotateRight() {
        mimr_ivRRight = (ImageView) findViewById(R.id.imr_ivRRight);
        mimr_ivRRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editableView != null) {
                    if (editableView instanceof StickerView) {
                        StickerView stickerView = (StickerView) editableView;
                        stickerView.rotateView(true);
                    } else {
                        BubbleTextView bubbleTextView = (BubbleTextView) editableView;
                        bubbleTextView.rotateView(true);
                    }

                }
                if (mimr_ivRRight.isPressed())

                {
//                    mimr_ivRLeft.setSelected(false);
//                    mimr_ivRRight.setSelected(true);
//                    mimr_ivLFilp.setSelected(false);
//                    mimr_ivRFlip.setSelected(false);
                }
            }
        });

    }

    /**
     * Image Flip Horizontal
     */
    public void imageFlipHorizontal() {
        mimr_ivLFilp = (ImageView) findViewById(R.id.imr_ivLFilp);
        mimr_ivLFilp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editableView != null) {
                    if (editableView instanceof StickerView) {
                        StickerView stickerView = (StickerView) editableView;
                        stickerView.setFlipChange(FlipType.HORIZONTAL);
                        executeStickerViewThread(stickerView);
                    } else {
                        BubbleTextView bubbleTextView = (BubbleTextView) editableView;
                        bubbleTextView.changeFlipText(FlipType.HORIZONTAL);
                        executeBubbleViewThread(bubbleTextView);
                    }
                }
                if (mimr_ivLFilp.isPressed()) {
                    mimr_ivRLeft.setSelected(false);
                    mimr_ivRRight.setSelected(false);
//                    mimr_ivLFilp.setSelected(true);
//                    mimr_ivRFlip.setSelected(false);
                }
            }
        });

    }

    /**
     * Image Move Up
     */

   /* public void imageMoveUp() {
        miml_ivMoveUp = (ImageView) findViewById(R.id.iml_ivMoveUp);
        miml_ivMoveUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editableView instanceof BubbleTextView) {
                    rlCustomeDraw.invalidate();
                    ((BubbleTextView) editableView).setMoveUp();
                }
                if (editableView instanceof StickerView) {
                    rlCustomeDraw.invalidate();
                    ((StickerView) editableView).setMoveUp();
                }
                if (miml_ivMoveUp.isPressed()) {
                    miml_ivMoveUp.setSelected(true);
                    miml_ivMoveDown.setSelected(false);
                    miml_ivMoveTop.setSelected(false);
                    miml_ivMoveBottom.setSelected(false);
                }
            }
        });
    }

    */

    /**
     * Image Flip Vertical
     */
    public void imageFlipVertical() {
        mimr_ivRFlip = (ImageView) findViewById(R.id.imr_ivRFlip);
        mimr_ivRFlip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editableView != null) {
                    if (editableView instanceof StickerView) {
                        StickerView stickerView = (StickerView) editableView;
                        stickerView.setFlipChange(FlipType.VERTICAL);
                        executeStickerViewThread(stickerView);
                    } else {
                        BubbleTextView bubbleTextView = (BubbleTextView) editableView;
                        bubbleTextView.changeFlipText(FlipType.VERTICAL);
                        executeBubbleViewThread(bubbleTextView);
                    }

                }


                if (mimr_ivRFlip.isPressed()) {
                    mimr_ivRLeft.setSelected(false);
                    mimr_ivRRight.setSelected(false);
//                    mimr_ivLFilp.setSelected(false);
//                    mimr_ivRFlip.setSelected(true);
                }
            }
        });
    }


    /**
     * Image Layer Order
     */

    public void imageLayerOrder() {
        rlLayerOrder = (RelativeLayout) findViewById(R.id.iml_rlImageLayerOrder);
        rlLayerOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.VISIBLE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);

                if (rlLayerOrder.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(true);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(false);

                }
            }
        });
    }


    /**
     * Image Move Down
     *//*

    public void imageMoveDown() {
        miml_ivMoveDown = (ImageView) findViewById(R.id.iml_ivMoveDown);
        miml_ivMoveDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editableView instanceof BubbleTextView) {
                    moveToBack(editableView);
                }
                if (editableView instanceof StickerView) {
                    moveToBack(editableView);
                }

                if (miml_ivMoveDown.isPressed()) {
                    miml_ivMoveUp.setSelected(false);
                    miml_ivMoveDown.setSelected(true);
                    miml_ivMoveTop.setSelected(false);
                    miml_ivMoveBottom.setSelected(false);
                }
            }
        });
    }*/
   /* private void moveToBack(View myCurrentView) {

        ViewGroup myViewGroup = ((ViewGroup) myCurrentView.getParent());
        int index = myViewGroup.indexOfChild(myCurrentView);
        for (int i = 0; i < index; i++) {
            myViewGroup.bringChildToFront(myViewGroup.getChildAt(i));
        }
    }*/

    /**
     * Image Move Top
     */

    public void imageMoveTop() {
        miml_ivMoveTop = (ImageView) findViewById(R.id.iml_ivMoveTop);
        miml_ivMoveTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editableView instanceof BubbleTextView) {
                    rlCustomeDraw.invalidate();
                    ((BubbleTextView) editableView).setMoveUp();
                }
                if (editableView instanceof StickerView) {
                    rlCustomeDraw.invalidate();
                    ((StickerView) editableView).setMoveUp();
                }
                if (miml_ivMoveTop.isPressed()) {

                    miml_ivMoveTop.setSelected(true);
                    miml_ivMoveBottom.setSelected(false);
                }
            }
        });
    }

    /**
     * Image Move Bottom
     */

    public void imageMoveBottom() {
        miml_ivMoveBottom = (ImageView) findViewById(R.id.iml_ivMoveBottom);
        miml_ivMoveBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editableView instanceof BubbleTextView) {
//                    moveToBack(editableView);
                }
                if (editableView instanceof StickerView) {
//                    moveToBack(editableView);
                }
                if (miml_ivMoveBottom.isPressed()) {
                    miml_ivMoveTop.setSelected(false);
                    miml_ivMoveBottom.setSelected(true);
                }
            }
        });
    }

    /**
     * Image Alignment
     */

    public void imageAlignment() {
        rlAlignment = (RelativeLayout) findViewById(R.id.iml_rlImageAlignment);
        rlAlignment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.VISIBLE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);

                if (rlAlignment.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(true);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(false);

                }

            }
        });
    }

    /**
     * Image Left Alignment
     */

    public void imageLeftAlign() {
        mima_ivLeftAlign = (ImageView) findViewById(R.id.ima_ivLeftAlign);
        mima_ivLeftAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                viewLeftAlignToImprintX();


//                mapv_svCustomeView.showView();

                if (mima_ivLeftAlign.isPressed()) {
                    mima_ivLeftAlign.setSelected(true);
                    mima_ivRightAlign.setSelected(false);
                    mima_ivCenterAlign.setSelected(false);
                }
            }
        });
        mima_ivLeftAlign.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {

                    mapv_svCustomeView.setText("Left Align");
                    mapv_svCustomeView.showView();


                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    viewLeftAlignToImprintX();
                    mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                }
                return true;
            }
        });
    }

    private void viewLeftAlignToImprintX() {

        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo imprintParamVo = mProductImprintInfo.getImprintParam();
        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo.ImptintPointsVo imptintPointsVo = imprintParamVo.getImptintPoints();
        final PointVo pointVo;
        float pointX = 0;
        if (imprintParamVo.getProductTemplateObjectShape().equalsIgnoreCase(ImprintAreaType.CIRCLE)) {
            pointVo = imptintPointsVo.getCirclePoints();
            pointX = pointVo.getX() - imptintPointsVo.getRadius();
        } else {
            pointVo = imptintPointsVo.getPoint1();
            pointX = pointVo.getX();
        }

        CustomLogHandler.printVerbose(TAG, "Drawee Height:--" + mProductOverlayImprintArea.getHeight());

        int screenWidth = DensityUtils.getScreenWidth(ProductVirtualActivity.this);


        float xLEft = (screenWidth * pointX) / mProductImageOriginalWidth;
        CustomLogHandler.printVerbose(TAG, "left x:--" + xLEft);

        if (editableView != null && editableView instanceof StickerView) {
            ((StickerView) editableView).viewLeftAlign((int) xLEft, 0);
        } else if (editableView != null && editableView instanceof BubbleTextView) {
            ((BubbleTextView) editableView).viewLeftAlign((int) xLEft, 0);
        }
       /* int childViewsCount = rlCustomeDraw.getChildCount();

        for (int i = 0; i < childViewsCount; i++) {
            View view = rlCustomeDraw.getChildAt(i);

            if (view instanceof StickerView) {
                ((StickerView) view).viewLeftAlign((int) xLEft, 0);
            } else if (view instanceof BubbleTextView) {
                ((BubbleTextView) view).viewLeftAlign((int) xLEft, 0);
            }
        }*/
    }

    /**
     * Image Right Alignment
     */

    public void imageRightAlign() {
        mima_ivRightAlign = (ImageView) findViewById(R.id.ima_ivRightAlign);
        mima_ivRightAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mima_ivRightAlign.isPressed()) {
                    mima_ivLeftAlign.setSelected(false);
                    mima_ivRightAlign.setSelected(true);
                    mima_ivCenterAlign.setSelected(false);
                }
            }
        });
        mima_ivRightAlign.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    viewRightAlignToImprintX();
                    mapv_svCustomeView.setText("Right Align");
                    mapv_svCustomeView.showView();
                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {

                    mapv_svCustomeView.hideView(ProductVirtualActivity.this);


                }
                return true;
            }
        });
    }

    private void viewRightAlignToImprintX() {
        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo imprintParamVo = mProductImprintInfo.getImprintParam();
        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo.ImptintPointsVo imptintPointsVo = imprintParamVo.getImptintPoints();

        final PointVo pointVo;
        float pointX = 0;

        if (imprintParamVo.getProductTemplateObjectShape().equalsIgnoreCase(ImprintAreaType.CIRCLE)) {
            pointVo = imptintPointsVo.getCirclePoints();
            pointX = pointVo.getX() + imptintPointsVo.getRadius();
        } else {
            pointVo = imptintPointsVo.getPoint2();
            pointX = pointVo.getX();
        }
        CustomLogHandler.printVerbose(TAG, "Drawee Height:--" + sdv_ProductImage.getHeight());

        int screenWidth = DensityUtils.getScreenWidth(ProductVirtualActivity.this);
        float xRight = (screenWidth * pointX) / mProductImageOriginalWidth;
        CustomLogHandler.printVerbose(TAG, "left x:--" + xRight);

        if (editableView != null && editableView instanceof StickerView) {
            ((StickerView) editableView).viewRightAlign((int) xRight, 0);
        } else if (editableView != null && editableView instanceof BubbleTextView) {
            ((BubbleTextView) editableView).viewRightAlign((int) xRight, 0);
        }
        /*int childViewsCount = rlCustomeDraw.getChildCount();

        for (int i = 0; i < childViewsCount; i++) {
            View view = rlCustomeDraw.getChildAt(i);

            if (view instanceof StickerView) {
                ((StickerView) view).viewRightAlign((int) xRight, 0);
            } else if (view instanceof BubbleTextView) {
                ((BubbleTextView) view).viewRightAlign((int) xRight, 0);
            }

        }*/
    }

    /**
     * Image Center Alignment
     */

    public void imageCenterAlign() {
        mima_ivCenterAlign = (ImageView) findViewById(R.id.ima_ivCenterAlign);
        mima_ivCenterAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mima_ivCenterAlign.isPressed()) {
                    mima_ivLeftAlign.setSelected(false);
                    mima_ivRightAlign.setSelected(false);
                    mima_ivCenterAlign.setSelected(true);
                }
            }
        });
        mima_ivCenterAlign.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    mapv_svCustomeView.setText("Center Align");
                    mapv_svCustomeView.showView();
                    viewCenterAlignToImprintX();

                }
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {

                    mapv_svCustomeView.hideView(ProductVirtualActivity.this);

                }
                return true;
            }
        });
    }

    private void viewCenterAlignToImprintX() {

        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo imprintParamVo = mProductImprintInfo.getImprintParam();
        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo.ImptintPointsVo imptintPointsVo = imprintParamVo.getImptintPoints();

        int screenWidth = DensityUtils.getScreenWidth(ProductVirtualActivity.this);

        float pointCenter = 0;
        PointVo pointVoStart;

        if (imprintParamVo.getProductTemplateObjectShape().equalsIgnoreCase(ImprintAreaType.CIRCLE)) {
            pointVoStart = imptintPointsVo.getCirclePoints();
            pointCenter = pointVoStart.getX();
        } else {
            pointVoStart = imptintPointsVo.getPoint1();
            PointVo pointVoEnd = imptintPointsVo.getPoint2();
            pointCenter = (pointVoEnd.getX() - pointVoStart.getX()) / 2;

        }

        CustomLogHandler.printVerbose(TAG, "pointCenter:--" + pointCenter);

        float imprintCenter = (screenWidth * pointCenter) / mProductImageOriginalWidth;
        CustomLogHandler.printVerbose(TAG, "left x:--" + imprintCenter);
        int childViewsCount = rlCustomeDraw.getChildCount();

        float tranXpos = imprintCenter;
        if (!imprintParamVo.getProductTemplateObjectShape().equalsIgnoreCase(ImprintAreaType.CIRCLE)) {
            float xLEft = (screenWidth * pointVoStart.getX()) / mProductImageOriginalWidth;
            tranXpos += xLEft;
        }

        if (editableView != null && editableView instanceof StickerView) {
            ((StickerView) editableView).viewCenterAlign((int) tranXpos);
        } else if (editableView != null && editableView instanceof BubbleTextView) {
            ((BubbleTextView) editableView).viewCenterAlign((int) tranXpos);
        }

        /*for (int i = 0; i < childViewsCount; i++) {
            View view = rlCustomeDraw.getChildAt(i);

            if (view instanceof StickerView) {
                ((StickerView) view).viewCenterAlign((int) tranXpos);
            } else if (view instanceof BubbleTextView) {
                ((BubbleTextView) view).viewCenterAlign((int) tranXpos);
            }
        }*/
    }

    /**
     * Image Opacity
     */
    public void imageOpacity() {
        rlOpacity = (RelativeLayout) findViewById(R.id.iml_rlImageOpacity);
        rlOpacity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.VISIBLE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);

                if (rlOpacity.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(true);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(false);

                }
                setOpacity();
            }
        });
    }

    /**
     * Image Sharpness
     */
    public void imageSharpness() {
        rlSharpness = (RelativeLayout) findViewById(R.id.iml_rlImageSharpness);
        rlSharpness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);
                CommonUtil.showProgressDialog(mContext, null, getString(R.string.please_wait), false, null, REQUEST_CALL_FOR_ENGRAVE, getSupportFragmentManager());


                StickerView stickerView = (StickerView) editableView;
                stickerView.setEffectType(EffectTypes.SHARPNESS);
                executeStickerViewThread(stickerView);

                if (rlSharpness.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(true);
                    rlRemoveColor.setSelected(false);

                }


                /*sbSharpness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    int p = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        p = progress;
                        mapv_svCustomeView.setText("Sharpness : " + p + "%");
                        mapv_svCustomeView.showView();
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        CommonUtil.showProgressDialog(mContext, null, getString(R.string.please_wait), false, null, REQUEST_CALL_FOR_ENGRAVE, getSupportFragmentManager());
                        StickerView stickerView = (StickerView) editableView;
                        stickerView.setSharpness(true, p);
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    }
                });*/
            }
        });
    }

    /**
     * Image Remove Color
     */
    public void imageRemoveColor() {
        rlRemoveColor = (RelativeLayout) findViewById(R.id.iml_rlImageRemoveColor);
        rlRemoveColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);


                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_sharpness.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.VISIBLE);


                if (rlRemoveColor.isPressed()) {
                    //rlCropImage.setSelected(false);
                    rlRotation.setSelected(false);
                    rlLayerOrder.setSelected(false);
                    rlAlignment.setSelected(false);
                    rlOpacity.setSelected(false);
                    rlSharpness.setSelected(false);
                    rlRemoveColor.setSelected(true);

                }
            }
        });
    }

    /**
     * Image Remove White
     */
    public void imgRemoveWhite() {
        mimremove_cbRemoveWhite.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (editableView != null && editableView instanceof StickerView) {
                    StickerView stickerView = (StickerView) editableView;

                    if (isChecked) {
                        stickerView.removeWhiteColor(true);

                        mapv_svCustomeView.setText("Remove White");
                        mapv_svCustomeView.showView();
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    } else {
                        stickerView.removeWhiteColor(false);
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    }

                    executeStickerViewThread(stickerView);
                }
            }
        });

    }

    /**
     * Image Remove Black
     */
    public void imgRemoveBlack() {


        mimremove_cbRemoveBlack.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (editableView != null && editableView instanceof StickerView) {
                    StickerView stickerView = (StickerView) editableView;
                    if (isChecked) {
                        stickerView.removeBlackColor(true);
                        mapv_svCustomeView.setText("Remove Black");
                        mapv_svCustomeView.showView();
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    } else {
                        stickerView.removeBlackColor(false);
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    }
                    executeStickerViewThread(stickerView);

                }
            }
        });
    }

    /**
     * Text Font face Menu
     */
    private void textFontFace() {
        try {
            String list[] = getAssets().list("fonts");
            rlFontFace = (RelativeLayout) findViewById(R.id.tml_rlFontType);
            rView_Font = (RecyclerView) findViewById(R.id.tmf_rvFontType);

            fAdapter = new FontAdapter(this, list);
            // Apply the adapter to the Recycler View
            LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
            rView_Font.setLayoutManager(mLayoutManager);
            rView_Font.setAdapter(fAdapter);
            rlFontFace.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showHideColorSwaches(false);
                    showHideBottomBarContainer(true);
                    mapv_menutext_fonttype.setVisibility(View.VISIBLE);
                    mapv_menutext_fontcolor.setVisibility(View.GONE);
                    mapv_menutext_fontsize.setVisibility(View.GONE);
                    mapv_menutext_fontstyle.setVisibility(View.GONE);
                    mapv_menutext_fontcurve.setVisibility(View.GONE);
                    mapv_menuimage_rotate.setVisibility(View.GONE);
                    mapv_menuimage_layer.setVisibility(View.GONE);
                    mapv_menuimage_alignment.setVisibility(View.GONE);
                    mapv_menuimage_opacity.setVisibility(View.GONE);

                    if (rlFontFace.isPressed()) {
//                        //tltml_rlAddText.setSelected(false);
                        rlFontFace.setSelected(true);
                        rlFontColor.setSelected(false);
                        rlFontSize.setSelected(false);
                        rlFontStyle.setSelected(false);
                        rlFontRotation.setSelected(false);
                        rlLayer.setSelected(false);
                        rlAlign.setSelected(false);
                        rlFontOpacity.setSelected(false);
                        rlCurve.setSelected(false);
                    }

                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void setOnFontFaceChanageListener(String fontStylepath) {
        if (editableView != null) {
            BubbleTextView bubbleTextView = (BubbleTextView) this.editableView;
            bubbleTextView.setFontType(fontStylepath);
            executeBubbleViewThread(bubbleTextView);

        }
    }

    /**
     * Text Font Color Change
     */
    public void textFontColor() {
        rlFontColor = (RelativeLayout) findViewById(R.id.tml_rlColor);
        rlFontColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.VISIBLE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlFontColor.isPressed()) {
//                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(true);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
                rv_ProductColor.setLayoutManager(layoutManager);
            }
        });
    }

    /**
     * Text Font Size Change
     */
    public void textFontSize() {
        rlFontSize = (RelativeLayout) findViewById(R.id.tml_rlSize);
        rlFontSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.VISIBLE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlFontSize.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(true);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }
                sb_fontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    int p = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        p = progress;
                        BubbleTextView bubbleTextView = (BubbleTextView) ProductVirtualActivity.this.editableView;
                        bubbleTextView.setFontsize(p);
                        executeBubbleViewThread(bubbleTextView);
                        mapv_svCustomeView.setText("Font Size : " + p);
                        mapv_svCustomeView.showView();
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    }
                });
            }
        });
    }

    /**
     * Text Font Style Change
     */
    public void textFontStyle() {
        rlFontStyle = (RelativeLayout) findViewById(R.id.tml_rlStyle);
        rlFontStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.VISIBLE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlFontStyle.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(true);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }
            }
        });

    }

    /**
     * Text Bold
     */
    public void textBold() {
        ivFontBold = (ImageView) findViewById(R.id.tmfontstyle_ivBold);
        ivFontBold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ivFontBold.isPressed()) {
                    ivFontBold.setSelected(true);
                    ivFontItalic.setSelected(false);
                    ivFontUnderline.setSelected(false);
                }
                ((BubbleTextView) editableView).setBold();
                executeBubbleViewThread((BubbleTextView) editableView);

            }
        });

    }

    /**
     * Text Italic
     */
    public void textItalic() {
        ivFontItalic = (ImageView) findViewById(R.id.tmfontstyle_ivItalic);
        ivFontItalic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ivFontItalic.isPressed()) {
                    ivFontBold.setSelected(false);
                    ivFontItalic.setSelected(true);
                    ivFontUnderline.setSelected(false);
                }
                ((BubbleTextView) editableView).setItalic();
                executeBubbleViewThread((BubbleTextView) editableView);
            }
        });

    }

    /**
     * Text Underline
     */
    public void textUnderline() {
        ivFontUnderline = (ImageView) findViewById(R.id.tmfontstyle_ivUnderline);
        ivFontUnderline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ivFontUnderline.isPressed()) {
                    ivFontBold.setSelected(false);
                    ivFontItalic.setSelected(false);
                    ivFontUnderline.setSelected(true);
                }
                ((BubbleTextView) editableView).setUnderline();
                executeBubbleViewThread((BubbleTextView) editableView);
            }
        });

    }

    /**
     * Text Font Rotate and Flip Change
     */
    public void textRotationFlip() {
        rlFontRotation = (RelativeLayout) findViewById(R.id.tml_rlTextRotate);
        rlFontRotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.VISIBLE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlFontRotation.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(true);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }
            }
        });

    }

    /**
     * Text Font LAyer Order Change
     */
    public void textLayerOrder() {
        rlLayer = (RelativeLayout) findViewById(R.id.tml_rlTextLayerOrder);
        rlLayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.VISIBLE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlLayer.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(true);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }


            }
        });
    }

    /**
     * Text Font Alignment Change
     */
    public void textAlignment() {
        rlAlign = (RelativeLayout) findViewById(R.id.tml_rlTextAlignment);
        rlAlign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.VISIBLE);
                mapv_menuimage_opacity.setVisibility(View.GONE);

                if (rlAlign.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(true);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(false);
                }


            }
        });
    }

    /**
     * Text Font Opacity Change
     */
    public void textOpacity() {
        rlFontOpacity = (RelativeLayout) findViewById(R.id.tml_rlTextOpacity);
        rlFontOpacity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.GONE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.VISIBLE);

                if (rlFontOpacity.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(true);
                    rlCurve.setSelected(false);
                }
                setOpacity();

            }
        });
    }

    public void setOpacity() {
        int viewOpacity = 255;
        if (editableView instanceof BubbleTextView) {
            BubbleTextView textView = (BubbleTextView) editableView;
            viewOpacity = textView.getTextOpacity();
        } else if (editableView instanceof StickerView) {
            StickerView stickerView = (StickerView) editableView;
            viewOpacity = stickerView.getOpa();
        } else {
            viewOpacity = 255;
        }
        sbOpacity.setProgress(viewOpacity);
        sbOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int p;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                p = progress;
                if (editableView instanceof BubbleTextView) {
                    BubbleTextView bubbleTextView = (BubbleTextView) ProductVirtualActivity.this.editableView;
                    bubbleTextView.setTextOpacity(p);
                    executeBubbleViewThread(bubbleTextView);
                } else if (editableView instanceof StickerView) {
                    ((StickerView) editableView).setImageOpacity(p);
                }

                int per = ((p * 100) / 255);
                mapv_svCustomeView.setText("Opacity : " + per + "%");
                mapv_svCustomeView.showView();


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mapv_svCustomeView.hideView(ProductVirtualActivity.this);
            }
        });
    }

    /**
     * Text Font Curve
     */
    public void textFontCurve() {
        rlCurve = (RelativeLayout) findViewById(R.id.tml_rlTextCurve);
        rlCurve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHideBottomBarContainer(true);
                showHideColorSwaches(false);
                mapv_menutext_fonttype.setVisibility(View.GONE);
                mapv_menutext_fontcolor.setVisibility(View.GONE);
                mapv_menutext_fontsize.setVisibility(View.GONE);
                mapv_menutext_fontstyle.setVisibility(View.GONE);
                mapv_menutext_fontcurve.setVisibility(View.VISIBLE);
                mapv_menuimage_rotate.setVisibility(View.GONE);
                mapv_menuimage_layer.setVisibility(View.GONE);
                mapv_menuimage_alignment.setVisibility(View.GONE);
                mapv_menuimage_opacity.setVisibility(View.GONE);
                mapv_menuimage_removecolor.setVisibility(View.GONE);
                if (rlCurve.isPressed()) {
                    //tltml_rlAddText.setSelected(false);
                    rlFontFace.setSelected(false);
                    rlFontColor.setSelected(false);
                    rlFontSize.setSelected(false);
                    rlFontStyle.setSelected(false);
                    rlFontRotation.setSelected(false);
                    rlLayer.setSelected(false);
                    rlAlign.setSelected(false);
                    rlFontOpacity.setSelected(false);
                    rlCurve.setSelected(true);
                }


                sb_Curve.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    int p = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        p = sb_Curve.getProgress() - 360;
//                        p = progress;
                        if (p <= 0 && p >= -8) {
                            p = -8;
                        }
                        BubbleTextView bubbleTextView = (BubbleTextView) ProductVirtualActivity.this.editableView;
                        bubbleTextView.setCurve(p);
                        executeBubbleViewThread(bubbleTextView);

                        mapv_svCustomeView.setText("Angle : " + p);
                        mapv_svCustomeView.showView();
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        mapv_svCustomeView.hideView(ProductVirtualActivity.this);
                    }
                });
            }
        });
    }

    @Override
    public void onAddMediaAction(int actionCode) {
        if (actionCode == AddMediaFragment.ACTION_FROM_CAMERA) {
            checkSinglePermission(this, Manifest.permission.CAMERA, "Allowed CAMERA permission for take picture from mobile camera.", REQUEST_CAMERA_PERMISSION);
        } else {
            checkSinglePermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "Allowed STORAGE permission for pick image from gallery.", REQUEST_GALLERY_PERMISSION);

        }

    }

    private void pickImageFromGallery() {
        Intent intent = new Intent(
                Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(
                Intent.createChooser(intent, "Select File"),
                REQUEST_GALLERY);
    }

    private void pickImagefromCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go

            try {
                photoFile = createImageFile();
                CustomLogHandler.printVerbose(TAG, "path:--" + photoFile.getPath());
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                startActivityForResult(takePictureIntent, REQUEST_CAMERA);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                CustomLogHandler.printVerbose(TAG, "path:--" + photoFile.getPath());

                String appDirectory = AppConstant.getAppTempDirectory();
                File copyFilePath = new File(appDirectory, System.currentTimeMillis() + ".png");
                boolean result = FileIO.copyDirectory(photoFile, copyFilePath);
                if (result) {
                    removeBottomBarContainerFragment();
                    addStickerView(copyFilePath.getPath());

                    mapv_main_menu_layout.setVisibility(View.GONE);
                    mapv_menu_image.setVisibility(View.VISIBLE);
                    mapv_back.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(mContext, getString(R.string.err_something_went_wrong), Toast.LENGTH_SHORT).show();
                }


            } else if (requestCode == REQUEST_GALLERY) {
                Uri selectedImageUri = data.getData();
                String[] projection = {MediaStore.MediaColumns.DATA};
                CursorLoader cursorLoader = new CursorLoader(this, selectedImageUri, projection, null, null,
                        null);
                Cursor cursor = cursorLoader.loadInBackground();
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
                cursor.moveToFirst();
                String selectedImagePath = cursor.getString(column_index);
                String appDirectory = AppConstant.getAppTempDirectory();
                File copyFilePath = new File(appDirectory, System.currentTimeMillis() + ".png");
                boolean result = FileIO.copyDirectory(new File(selectedImagePath), copyFilePath);
                if (result) {
                    addStickerView(selectedImagePath);
                } else {
                    Toast.makeText(mContext, getString(R.string.err_something_went_wrong), Toast.LENGTH_SHORT).show();
                }


            } else if (requestCode == UCrop.REQUEST_CROP) {
                final Uri resultUri = UCrop.getOutput(data);
                CustomLogHandler.printVerbose(TAG, "resultUri:--" + resultUri.getPath());
                if (editableView != null) {
                    StickerView stickerView = (StickerView) editableView;
                    stickerView.setBitmapPath(resultUri.getPath());
                    int widthHalf = CommonUtil.getDisplayWidth(this) / 3;
                    float imageWidth = stickerView.getmBitmap().getWidth();
                    float imageHeight = stickerView.getmBitmap().getHeight();

                    /*ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo imprintParam = mProductImprintInfo.getImprintParam();
                    if (imprintParam != null ) {

                        String imprintSize = imprintParam.getImprintImageSize();
                        String[] imageSizes = imprintSize.split("X");
                        if (imageSizes.length == 2 && Float.parseFloat(imageSizes[0])>imageWidth ) {
                            imageWidth = Float.parseFloat(imageSizes[0]);
                            imageHeight = Float.parseFloat(imageSizes[1]);
                        }

                    }
*/

                    Bitmap bm = CommonUtils.decodeSampledBitmapFromFile(resultUri.getPath(), (int) imageWidth, (int) imageHeight);
                    stickerView.setChangeBitmap(bm);

                    executeStickerViewThread(stickerView);

             /*       StickerImageVo stickerImageVo = stickerView.getmImageVo();
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.SINGLE_COLOR) {
                        stickerView.setSingleColorWithColorCode(true, stickerImageVo.getSingleColorCode());
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.EMBOSS) {
                        stickerView.setEmbossEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.DEBOSS) {
                        stickerView.setDebossEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.ENGRAVE) {
                        stickerView.setEngraveEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.SATIN_EACH) {
                        stickerView.setSatinEachEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.WOODEN) {
                        stickerView.setWoodenEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.EMBROIDERY) {
                        stickerView.setEmbroideryEffect(true);
                    }
                    if (stickerImageVo != null && stickerImageVo.getEffectType() == EffectTypes.SHARPNESS) {
                        stickerView.setSharpness(true, 0);
                    }
                    if (stickerImageVo != null && stickerImageVo.isWhiteRemove()) {
                        stickerView.removeWhiteColor(true);
                    }*/
                }

            }
        } else {
            if (resultCode == UCrop.RESULT_ERROR) {
                final Throwable cropError = UCrop.getError(data);
                CustomLogHandler.printVerbose(TAG, "CropEror:-" + cropError.getMessage());
            }
        }
    }

    private void executeStickerViewThread(StickerView stickerView) {
        mViewsEffectsThread.enqueueStickerEffect(new StickerEffectsTask(ProductVirtualActivity.this, stickerView));
    }

    private void executeBubbleViewThread(BubbleTextView bubbleTextView) {
        mViewsEffectsThread.enqueueBubbleViewEffect(new BubbleEffectsTask(ProductVirtualActivity.this, bubbleTextView));
    }

    private void addStickerView(String mediaImagePath) {
        CustomLogHandler.printVerbose(TAG, "selectedImagePath:-" + mediaImagePath);

        if (mediaImagePath == null || mediaImagePath.length() <= 0)
            return;



        int widthHalf = CommonUtil.getDisplayWidth(this) / 3;
        float imageWidth = widthHalf;
        float imageHeight = widthHalf;

        ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo imprintParam = mProductImprintInfo.getImprintParam();
        if (imprintParam != null ) {

            String imprintSize = imprintParam.getImprintImageSize();
            String[] imageSizes = imprintSize.split("X");
            if (imageSizes.length == 2 && Float.parseFloat(imageSizes[0])>imageWidth ) {
                imageWidth = Float.parseFloat(imageSizes[0]);
                imageHeight = Float.parseFloat(imageSizes[1]);
            }

        }


        CustomLogHandler.printVerbose(TAG, "imageWidth:--" + imageWidth);
        CustomLogHandler.printVerbose(TAG, "imageHeight:--" + imageHeight);

        Bitmap bm = CommonUtils.decodeSampledBitmapFromFile(mediaImagePath, (int) imageWidth, (int) imageHeight);

        editableViewId = System.currentTimeMillis();
        final StickerView stickerView = new StickerView(this, editableViewId);
        stickerView.setBitmapPath(mediaImagePath);
        stickerView.setBitmap(bm, (int) imageHeight);

        stickerView.setOperationListener(stickerOperationListener);


        sdv_ProductImage.post(new Runnable() {
            @Override
            public void run() {
                CustomLogHandler.printVerbose(TAG, "Drawee Height:--" + sdv_ProductImage.getHeight());

                int screenWidth = imprintViewResizeWidth(mProductOverlayImprintArea.getWidth(), mProductOverlayImprintArea.getHeight());
                int setUpHeight = (int) imprintViewResizeHeight(screenWidth, mProductOverlayImprintArea.getWidth(), mProductOverlayImprintArea.getHeight());
//                        drawImprintAreasOverlay(mProductImprintInfo,imageInfo.getWidth(),imageInfo.getHeight(), sdv_ProductImage.getWidth(), sdv_ProductImage.getHeight());
                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(screenWidth, (int) setUpHeight);
                lp.setLayoutDirection(RelativeLayout.ALIGN_PARENT_TOP);
                rlCustomeDraw.addView(stickerView, lp);
                if (editableView != null)
                    showViewEditable(false);

                editableView = stickerView;
                showViewEditable(true);

                //removewhitedefault from Supplier Detail API
                if (mConfigurationOptionsVo.getRemovewhitedefault() == 1) {
                    mimremove_cbRemoveWhite.setChecked(true);
                }

                //defaultImprintMethod from Product Detail API
                if (mProductImprintInfo.getDefaultImprintMethod().contains("single_color")) {
                    stickerView.setSingleColor();
                    stickerView.setEffectType(EffectTypes.SINGLE_COLOR);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("emboss")) {
                    stickerView.setEffectType(EffectTypes.EMBOSS);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("deboss")) {
                    stickerView.setEffectType(EffectTypes.DEBOSS);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("wooden")) {
                    stickerView.setEffectType(EffectTypes.WOODEN);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("glass")) {
                    stickerView.setEffectType(EffectTypes.SATIN_EACH);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("embroidery")) {
                    stickerView.setSingleColor();
                    stickerView.setEffectType(EffectTypes.EMBROIDERY);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("leather_engrave")) {
                    stickerView.setEffectType(EffectTypes.ENGRAVE);
                } else if (mProductImprintInfo.getDefaultImprintMethod().contains("tone_on_tone")) {
                    stickerView.setEffectType(EffectTypes.TONE_ON_TONE);
                }

                //Fabric in imprintSettings from Product Detail API
                if (mProductImprintInfo.getImprintSettings().getFabric() == 1) {
                    stickerView.setImageOpacity(160);
                }

                //top to bottom and bottom to top in imprintSettings from Product Detail API
                if (mProductImprintInfo.getImprintSettings().getToptobottomrotate() == 1) {
                    stickerView.rotateView(true);
                }
                if (mProductImprintInfo.getImprintSettings().getBottomtotoprotate() == 1) {
                    stickerView.rotateView(false);
                }
//                executeStickerViewThread(stickerView);
            }
        });
        removeBottomBarContainerFragment();
        showHideImgaeViewActionBar(true);
    }

    private void showHideBottomBarContainer(boolean wantShow) {
        findViewById(R.id.apv_bottombarContainer).setVisibility(wantShow ? View.VISIBLE : View.GONE);
    }

    private void showHideColorSwaches(boolean isShow) {
        findViewById(R.id.apv_llColorSwatcher).setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void showHideImgaeViewActionBar(boolean isVisible) {
        if (isVisible) {
            mapv_main_menu_layout.setVisibility(View.GONE);
            mapv_back.setVisibility(View.VISIBLE);
            mapv_menu_image.setVisibility(View.VISIBLE);
            mapv_menu_text.setVisibility(View.GONE);
            mapv_menueffects.setVisibility(View.GONE);
        } else {
            mapv_main_menu_layout.setVisibility(View.VISIBLE);
            mapv_back.setVisibility(View.GONE);
            mapv_menu_image.setVisibility(View.GONE);
            mapv_menu_text.setVisibility(View.GONE);

        }
    }

    private void showHideTextViewActionBar(boolean isVisible) {
        if (isVisible) {
            mapv_main_menu_layout.setVisibility(View.GONE);
            mapv_back.setVisibility(View.VISIBLE);
            mapv_menu_text.setVisibility(View.VISIBLE);
            mapv_menu_image.setVisibility(View.GONE);
            mapv_menueffects.setVisibility(View.GONE);
        } else {
            mapv_main_menu_layout.setVisibility(View.VISIBLE);
            mapv_back.setVisibility(View.GONE);
            mapv_menu_text.setVisibility(View.GONE);
            mapv_menu_image.setVisibility(View.GONE);

        }
    }

    private void showHideTextMenu(boolean isView) {
        if (!isView) {
            mapv_menutext_fonttype.setVisibility(View.GONE);
            mapv_menutext_fontcolor.setVisibility(View.GONE);
            mapv_menutext_fontsize.setVisibility(View.GONE);
            mapv_menutext_fontstyle.setVisibility(View.GONE);
            mapv_menuimage_rotate.setVisibility(View.GONE);
            mapv_menuimage_layer.setVisibility(View.GONE);
            mapv_menuimage_alignment.setVisibility(View.GONE);
            mapv_menuimage_opacity.setVisibility(View.GONE);
            mapv_menutext_fontcurve.setVisibility(View.GONE);
        }
    }

    private void showHideImageMenu(boolean isView) {
        if (!isView) {
            mapv_menuimage_rotate.setVisibility(View.GONE);
            mapv_menuimage_layer.setVisibility(View.GONE);
            mapv_menuimage_alignment.setVisibility(View.GONE);
            mapv_menuimage_opacity.setVisibility(View.GONE);
            mapv_menuimage_sharpness.setVisibility(View.GONE);
            mapv_menuimage_removecolor.setVisibility(View.GONE);
        }
    }

    private void removeBottomBarContainerFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.apv_bottombarContainer);

        if (fragment != null) {
            fragmentManager.beginTransaction().remove(fragment).commit();
        }
    }

    private void showViewEditable(boolean isEditable) {
        if (editableView != null) {
            if (editableView instanceof BubbleTextView)
                ((BubbleTextView) editableView).setInEdit(isEditable);
            else if (editableView instanceof StickerView)
                ((StickerView) editableView).setInEdit(isEditable);
        }
    }

    public int imprintViewResizeWidth(int parentWidth, int parentHeight) {
        return DensityUtils.getScreenWidth(ProductVirtualActivity.this);
    }

    public float imprintViewResizeHeight(int resizeWidth, int parentWidth, int parentHeight) {
        return parentWidth * (resizeWidth / parentHeight);
    }

    @Override
    public void onColorClick(int colorCode) {
        showHideColorSwaches(true);
        if (editableView != null) {
            mSelectedColor = colorCode;
            String selectPmsColor = colorDataVo.getPmscolor().get(colorCode).getHex();
//            ((BubbleTextView) editableView).setSingleColor(Color.parseColor("#" + selectPmsColor));
            callRelatedPmsColor(selectPmsColor);
        }
    }

    private void callRelatedPmsColor(String selectPmsColor) {
        List<NameValuePair> postHeader = Util.getDefaultHeader(this);
        List<NameValuePair> postparams = new ArrayList<>();
        postparams.add(new NameValuePair(WSKeyConstant.KEY_HEX_COLOR, selectPmsColor));

        FormHttpCaller formHttpCaller = new FormHttpCaller(this, WSUrlConstant.productApiGetRelatedPmsColor(), APIType.METHOD_GET, postHeader, postparams, WSRequestCodeConstant.REQUEST_GET_RELATED_PMS_COLOR, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    @Override
    public void onSingleColorClick(String colorCode) {
        showHideColorSwaches(true);
        callRelatedPmsColor(colorCode);
    }

    @Override
    public void onEmbroidaryEffectClick(String colorCode) {
        showHideColorSwaches(true);
        callRelatedPmsColor(colorCode);
    }

    @Override
    public void onToneOnToneEffectClick(String colorCode) {
        showHideColorSwaches(true);
        callRelatedPmsColor(colorCode);
    }

    @Override
    public void permissionDenied(int requestCode) {

        if (requestCode == REQUEST_ALL_PERMISSION) {
            Toast.makeText(mContext, "Denied CAMERA and STORAGE permission, Stop some application functionality", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_CAMERA_PERMISSION) {
            Toast.makeText(mContext, "Denied CAMERA permission,Can't open camera.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_GALLERY_PERMISSION) {
            Toast.makeText(mContext, "Denied STORAGE / GALLERY permission, Can't open gallery.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            Toast.makeText(mContext, "Denied STORAGE permission, Can't save your virtual work.", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void permissionGranted(int requestCode) {
        if (requestCode == REQUEST_ALL_PERMISSION) {
//            Toast.makeText(mContext, "CAMERA and STORAGE permission granted.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_CAMERA_PERMISSION) {
//            Toast.makeText(mContext, "CAMERA permission granted.", Toast.LENGTH_SHORT).show();
            pickImagefromCamera();
        } else if (requestCode == REQUEST_GALLERY_PERMISSION) {
//            Toast.makeText(mContext, "GALLERY permission granted.", Toast.LENGTH_SHORT).show();
            pickImageFromGallery();
        } else if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            new SaveArtWorkAsync(ProductVirtualActivity.this, rlCustomeDraw).execute();

        }
    }

    @Override
    public void permissionNeverAsked(int requestCode) {
        if (requestCode == REQUEST_ALL_PERMISSION) {
            Toast.makeText(mContext, "CAMERA and STORAGE permission denied with never ask, Please allowed both permission from device settings.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_CAMERA_PERMISSION) {
            Toast.makeText(mContext, "CAMERA permission denied with never ask, Please allowed CAMERA permission from device settings.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_GALLERY_PERMISSION) {
            Toast.makeText(mContext, "STORAGE permission denied with never ask, Please allowed STORAGE / GALLERY permission from device settings.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            Toast.makeText(mContext, "STORAGE permission denied with never ask, Please allowed STORAGE permission from device settings to store your virtual work.", Toast.LENGTH_SHORT).show();
        }

        openAppSettingDialog(this, "Need to enable all permission from app setting.");
    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        BaseVo baseVo = (BaseVo) itemObj;
        if (requestCode == WSRequestCodeConstant.REQUEST_GET_PMS_COLOR) {
            if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                PmsColorVo pmsColorVo = (PmsColorVo) baseVo;
                colorDataVo = pmsColorVo.getData();

                mColorAdapter = new ColorAdapter(getApplicationContext(), colorDataVo.getPmscolor(), mSelectedColor, ProductVirtualActivity.this);
                rv_ProductColor.setAdapter(mColorAdapter);
            }
        } else if (requestCode == WSRequestCodeConstant.REQUEST_GET_RELATED_PMS_COLOR) {
            if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                RelatedPmsColorVo relatedPmsVo = (RelatedPmsColorVo) baseVo;
                relatedPmsColorVo = relatedPmsVo.getData();

                LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
                rvPmsColorSwatches.setLayoutManager(layoutManager);
                List<PmshexcolorVo> pmshexcolorVoList = relatedPmsColorVo.getPmshexcolor();

                EffectTypes effectTypes = null;
                if (mSingleColorAdapter != null) {
                    effectTypes = mSingleColorAdapter.getmEffectTypes();
                }

                mColorSwatchesAdapter = new ColorSwatchesAdapter(getApplicationContext(), effectTypes, pmshexcolorVoList, -1, ProductVirtualActivity.this);
                rvPmsColorSwatches.setAdapter(mColorSwatchesAdapter);
            }
        }
    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {

    }

    @Override
    public void onError(Object itemObj) {

    }

    @Override
    public void onColorSwatchesClick(String colorCode, EffectTypes types) {
        int childViewsCount = rlCustomeDraw.getChildCount();
        if (editableView != null && editableView instanceof BubbleTextView) {
            BubbleTextView bubbleTextView = (BubbleTextView) this.editableView;
            bubbleTextView.setFontColor(Color.parseColor(colorCode));
            executeBubbleViewThread(bubbleTextView);
        } else if (types != null && types == EffectTypes.EMBROIDERY) {
            applyEffectsOnViews(rlCustomeDraw, EffectTypes.EMBROIDERY, Color.parseColor(colorCode));
            /*for (int i = 0; i < childViewsCount; i++) {
                View v = rlCustomeDraw.getChildAt(i);
                if (v instanceof StickerView) {
                    StickerView stickerView = (StickerView) v;
                    if (stickerView.getmImageVo().getEffectType() == EffectTypes.EMBROIDERY) {
                        CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                        ((StickerView) v).setEmbroideryEffectWithColor(true, Color.parseColor(colorCode));
                    }
                    CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                    ((StickerView) v).setEmbroideryEffectWithColor(true, Color.parseColor(colorCode));
                } else if (v instanceof BubbleTextView) {
                    BubbleTextView bubbleTextView = (BubbleTextView) v;
                    if (!bubbleTextView.getmFontVo().isEmbroidary()) {
                        ((BubbleTextView) v).setEmbroidery(true, Color.parseColor(colorCode));
                    }
                }
            }*/
        } else if (types != null && types == EffectTypes.SINGLE_COLOR) {
            applyEffectsOnViews(rlCustomeDraw, EffectTypes.SINGLE_COLOR, Color.parseColor(colorCode));
/*
            for (int i = 0; i < childViewsCount; i++) {
                View v = rlCustomeDraw.getChildAt(i);
                if (v instanceof StickerView) {
                    CommonUtil.showProgressDialog(ProductVirtualActivity.this, null, "Please wait...", false, null, -1, getSupportFragmentManager());
                    ((StickerView) v).setSingleColorWithColorCode(true, Color.parseColor(colorCode));
                } else if (v instanceof BubbleTextView) {
                    ((BubbleTextView) v).setSingleColorEffect(true, Color.parseColor(colorCode));

                }
            }
        }*/
        }
    }

    @Override
    public void onYesNoDialogButtonClicked(int pRequestCode, int pWhichButton) {
        if (pRequestCode == REQUEST_DIALOG_SAVE_ARTWORK) {
            if (pWhichButton == YesNoAlertDialogListener.BUTTON_POSITIVE) {
                checkSinglePermission(ProductVirtualActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "Allowed STORAGE permission for save your virtual work.", REQUEST_VIRTUAL_SAVE_PERMISSION);
            } else if (pWhichButton == YesNoAlertDialogListener.BUTTON_NEGATIVE) {
                finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (rlCustomeDraw.getChildCount() > 1) {
            saveArtworkDialog();
        } else {
            super.onBackPressed();
        }
    }

    private boolean saveArtModelAsFile(ArtworkBaseVo artworkBaseVo) {
        Gson gson = new GsonBuilder().create();
        StringBuilder json = new StringBuilder();
        json.append(gson.toJson(artworkBaseVo));

        try {
            String jsonStr = json.toString();
            String directorytPath = getSkuArtDirectoryPath(true);
            //Use current timestamp as id bcz manage View order.
            String fileName = getSkuArtFileName(System.currentTimeMillis());
            File filePath = new File(directorytPath, fileName);

            byte[] bytes = jsonStr.getBytes("UTF-8");
            boolean result = FileIO.writeBytesToFile(bytes, filePath.getAbsolutePath());
            return result;

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void handleStickerEffectTaskUpdate(final StickerView stickerView) {
        // Wrap DownloadTask into another Runnable to track the statistics
        mEffectHandler.post(new Runnable() {
            @Override
            public void run() {
                stickerView.invalidate();

                int totalCompleted = mViewsEffectsThread.getTotalCompleted();
                int totalQueued = mViewsEffectsThread.getTotalQueued();
                if (totalCompleted == totalQueued) {

                    CommonUtil.dismissProgressDialog();
                }

            }
        });
    }

    @Override
    public void handleBubbleEffectTaskUpdate(final BubbleTextView bubbleTextView) {
        // Wrap DownloadTask into another Runnable to track the statistics
        mEffectHandler.post(new Runnable() {
            @Override
            public void run() {
                bubbleTextView.invalidate();

                int totalCompleted = mViewsEffectsThread.getTotalCompleted();
                int totalQueued = mViewsEffectsThread.getTotalQueued();
                if (totalCompleted == totalQueued) {

                    CommonUtil.dismissProgressDialog();
                }

            }
        });
    }

    private class SaveArtWorkAsync extends AsyncTask<Void, Void, Boolean> {


        private Activity context;
        private RelativeLayout aParentLayout;

        public SaveArtWorkAsync(Activity context, RelativeLayout aParentLayout) {
            this.context = context;
            this.aParentLayout = aParentLayout;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            CommonUtil.showProgressDialog(context, null, "Saving artwork...", false, null, -1, getSupportFragmentManager());
        }

        @Override
        protected Boolean doInBackground(Void... params) {

            int artCounter = 0;

            boolean saveVirtualWorkImageResult;
            if (isProductPreview)
                saveVirtualWorkImageResult = saveVirtualProduct();
            else
                saveVirtualWorkImageResult = true;
            if (saveVirtualWorkImageResult) {
                int countArtChild = aParentLayout.getChildCount();
                for (int i = 0; i < countArtChild; i++) {
                    View artView = aParentLayout.getChildAt(i);
                    ArtworkBaseVo artworkBaseVo = new ArtworkBaseVo();
                    if (artView instanceof BubbleTextView) {
                        BubbleTextView bubbleTextView = (BubbleTextView) artView;
                        BubblePropertyModel bubblePropertyModel = bubbleTextView.calculate(new BubblePropertyModel());
                        artworkBaseVo.setBubblePropertyModel(bubblePropertyModel);

                        boolean result = saveArtModelAsFile(artworkBaseVo);
                        if (result) {
                            artCounter++;
                        } else {
                            break;
                        }
                    } else if (artView instanceof StickerView) {
                        StickerView stickerView = (StickerView) artView;
                        StickerPropertyModel stickerPropertyModel = stickerView.calculate(new StickerPropertyModel());
                        artworkBaseVo.setStickerPropertyModel(stickerPropertyModel);
                        boolean result = saveArtModelAsFile(artworkBaseVo);
                        if (result) {
                            artCounter++;
                        } else {
                            break;
                        }
                    }
                }

                if (artCounter == countArtChild - 1)
                    return true;
                else
                    return false;
            }


            return false;
        }

        @Override
        protected void onPostExecute(Boolean saveResult) {
            super.onPostExecute(saveResult);
            CommonUtil.dismissProgressDialog();
            if (saveResult) {
                Toast.makeText(ProductVirtualActivity.this, "Your virtual save successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(ProductVirtualActivity.this, "Sorry,can not save your virtual", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class DrawPreviousArtWorkAsync extends AsyncTask<Void, Void, List<ArtworkBaseVo>> {
        private Activity aContext;
        private File[] aArtFileList;

        public DrawPreviousArtWorkAsync(Activity context, File[] fileList) {
            aContext = context;
            aArtFileList = fileList;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            CommonUtil.showProgressDialog(aContext, null, "Re-draw you artwork...", false, null, -1, getSupportFragmentManager());
        }

        @Override
        protected List<ArtworkBaseVo> doInBackground(Void... params) {

            List<ArtworkBaseVo> propertyModelsList = new ArrayList<>();

            for (int i = 0; i < aArtFileList.length; i++) {

                String fileText = FileIO.readFile(aArtFileList[i]);

                GsonBuilder mGsonBuilder = new GsonBuilder();
                Gson mGson = mGsonBuilder.create();
                ArtworkBaseVo artworkBaseVo = mGson.fromJson(fileText, ArtworkBaseVo.class);

                propertyModelsList.add(artworkBaseVo);

            }


            CustomLogHandler.printVerbose(TAG, "Delete sku Parent directory:-" + getSkuArtDirectoryPath(false));
            FileIO.deleteDirectory(getSkuArtDirectoryPath(false));

            return propertyModelsList;
        }

        @Override
        protected void onPostExecute(List<ArtworkBaseVo> alist) {
            super.onPostExecute(alist);


            for (int index = 0; index < alist.size(); index++) {

                if (alist.get(index).getBubblePropertyModel() != null) {
                    BubblePropertyModel model = alist.get(index).getBubblePropertyModel();
                    BubbleTextView bubbleTextView = new BubbleTextView(aContext,
                            Color.BLACK, model.getBubbleId());

                    bubbleTextView.setBitmap(Bitmap.createBitmap(150, 75, Bitmap.Config.ARGB_8888), model);
                    bubbleTextView.setOperationListener(bubbleTextViewListener);

                    RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    lp.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);

                    executeBubbleViewThread(bubbleTextView);
                    editableView = bubbleTextView;
                    showViewEditable(false);
                    rlCustomeDraw.addView(bubbleTextView, lp);

                } else if (alist.get(index).getStickerPropertyModel() != null) {
                    StickerPropertyModel model = alist.get(index).getStickerPropertyModel();
                    StickerView stickerView = new StickerView(ProductVirtualActivity.this, model.getStickerId());
                    stickerView.setBitmapPath(model.getStickerURL());
                    stickerView.setStickerBitmapModel(model);
                    stickerView.setOperationListener(stickerOperationListener);
                    executeStickerViewThread(stickerView);


                    RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    lp.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);

                    editableView = stickerView;
                    showViewEditable(false);

                    rlCustomeDraw.addView(stickerView, lp);

                }
            }

        }
    }
}