package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 10/10/2016.
 */

/*List of API Calling field Values Constants*/
public class WSValueConstant {
    public static final String EN_US = "en_us";
}
