package com.ob.vmc.vmcproduct.model.appmodel;

import java.io.Serializable;

/**
 * Created by khyati5403 on 9/19/2016.
 */
public class BasePropertyModelVo implements Serializable{

    BubblePropertyModel mBubblePropertyModel;
    StickerPropertyModel mStickerPropertyModel;

    public BubblePropertyModel getmBubblePropertyModel() {
        return mBubblePropertyModel;
    }

    public void setmBubblePropertyModel(BubblePropertyModel mBubblePropertyModel) {
        this.mBubblePropertyModel = mBubblePropertyModel;
    }

    public StickerPropertyModel getmStickerPropertyModel() {
        return mStickerPropertyModel;
    }

    public void setmStickerPropertyModel(StickerPropertyModel mStickerPropertyModel) {
        this.mStickerPropertyModel = mStickerPropertyModel;
    }
}
