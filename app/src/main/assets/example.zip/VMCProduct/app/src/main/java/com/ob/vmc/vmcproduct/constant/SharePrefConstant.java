package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 6/14/2016.
 */
/*List of Save Shared Preference Key List*/
public class SharePrefConstant {
    public static final String KEY_TOKEN_TYPE = "token_type";
    public static final String KEY_EXPIRES_IN = "expires_in";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_SUPPLIER_ID = "supplier_id";
    public static final String KEY_SUPPLIER_TYPE = "supplier_type";
}
