package com.ob.vmc.vmcproduct.application;

import android.app.Application;

import com.crittercism.app.Crittercism;
import com.ob.ecommercelibrary.common.StaticInit;

/**
 * Created by Ishan4452 on 10/10/2016.
 */

public class VMCApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();





        //Debug Configuration for Only CustomLogHandlerClass
        StaticInit.initStaticConstants(this, true);
        Crittercism.initialize(getApplicationContext(), "0dc0122143184c3082a3ba941be2ea2400555300");
    }
}
