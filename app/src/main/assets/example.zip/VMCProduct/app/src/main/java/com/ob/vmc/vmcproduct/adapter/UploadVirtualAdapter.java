package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.appmodel.UploadVirtualFileVo;
import com.ob.vmc.vmcproduct.model.appmodel.VirtualFileSideVo;

import java.util.List;

/**
 * Created by Ishan4452 on 12/14/2016.
 */
public class UploadVirtualAdapter extends RecyclerView.Adapter<UploadVirtualAdapter.UploadVirtualViewHolder> {


    private Context mContext;
    private List<UploadVirtualFileVo> mUploadVirtualFileVos;
    private OnUploadClickListener mOnUploadClickListener;
    private int selectPosition = -1;

    public UploadVirtualAdapter(Context mContext, List<UploadVirtualFileVo> mUploadVirtualFileVos) {
        this.mContext = mContext;
        mOnUploadClickListener = (OnUploadClickListener) mContext;
        this.mUploadVirtualFileVos = mUploadVirtualFileVos;
    }

    @Override
    public UploadVirtualViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_upload_virtual_item, parent, false);
        return new UploadVirtualViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UploadVirtualViewHolder holder, final int position) {


        VirtualSideImageAdapter adapter = new VirtualSideImageAdapter(mContext, mUploadVirtualFileVos.get(position).getVirtualFileSideVos());
        holder.rvVirtualSideImages.setAdapter(adapter);

        holder.ivUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectPosition = position;
                mOnUploadClickListener.onUploadClick(mUploadVirtualFileVos.get(position).getVirtualFileSideVos());
            }
        });


    }

    @Override
    public int getItemCount() {
        return mUploadVirtualFileVos.size();
    }

    public String getUploadColorCode() {
        if (selectPosition != -1)
            return mUploadVirtualFileVos.get(selectPosition).getColorCode();
        else
            return null;
    }

    public interface OnUploadClickListener {
        void onUploadClick(List<VirtualFileSideVo> virtualFileSideVos);

    }

    public class UploadVirtualViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivUploadImage;
        private RecyclerView rvVirtualSideImages;

        public UploadVirtualViewHolder(View itemView) {
            super(itemView);

            ivUploadImage = (ImageView) itemView.findViewById(R.id.auv_ivUploadVirtual);
            rvVirtualSideImages = (RecyclerView) itemView.findViewById(R.id.auv_rvVirtualItemList);
            rvVirtualSideImages.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
        }
    }

}
