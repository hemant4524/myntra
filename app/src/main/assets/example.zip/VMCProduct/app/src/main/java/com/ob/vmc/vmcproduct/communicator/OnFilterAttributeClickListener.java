package com.ob.vmc.vmcproduct.communicator;

import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import java.util.ArrayList;

public interface OnFilterAttributeClickListener
{
//    void onCommonItemSelect(ArrayList<SuppliersVO.DataVo.SuppliersVo> vo, String selectedPositions);
    void onCommonItemSelect(ArrayList<SuppliersVO.DataVo.SuppliersVo> vo, String selectedPositions);
//    void onItemSelect(List<String> selectedSupllierList, String string);
   /* void onTagItemSelect(ArrayList<PublicCustomTagTextEntity> vo, String selectedPositions);

    void onShadeCheckChange(String selected, List<SearchAttributeFilterArrayEntity.ColorMappingEntity.ActualColorEntity> actualColor*//*, int parentPosition*//*);
    void onColorCheckChange(String selected, List<SearchAttributeFilterArrayEntity.ColorMappingEntity.ActualColorEntity> actualColor, int parentPosition);*/
}
