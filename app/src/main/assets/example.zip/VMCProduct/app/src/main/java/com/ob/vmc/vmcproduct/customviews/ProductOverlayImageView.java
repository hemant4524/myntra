package com.ob.vmc.vmcproduct.customviews;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;

import com.ob.vmc.vmcproduct.model.httpmodel.PointVo;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.utils.DensityUtils;
import com.ob.vmc.vmcproduct.utils.ImprintAreaType;

/**
 * Created by Ishan4452 on 9/7/2016.
 */
public class ProductOverlayImageView extends ImageView {

    private static final String TA = ProductOverlayImageView.class.getName();
    private Context context;
    private ProductDetailVo.DataVo.ImprintInfoVo productListVo;
//    private int widthDrawable;
//    private int heightDrawable;
    private int rootHeight;
    private int rootWidth;
    private Bitmap productBitmapDrawable;
    private Bitmap productBitmap;
    private Rect source;
    private Rect dest;
    private Paint mPaint;
    private Paint myPaintShape;
    private float heightProduct, widthProduct;
    private Point point1;
    private Point point2;
    private Point point3;
    private Point point4;
    private Point pointQuadBottom, pointQuadTop;
    private boolean isPreviewView;
    private OnPreviewViewDrawResultListener onPreviewViewResultListener;
    private ProductDetailVo.DataVo.ImprintInfoVo.ImprintParamVo mImprintParamVo;
    private String mImprintAreaType;

    public ProductOverlayImageView(Context context) {
        super(context);
        init(context, null);
    }

    public ProductOverlayImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }


    public ProductOverlayImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attr) {
        this.context = context;
        mPaint = new Paint();
        myPaintShape = new Paint(Paint.ANTI_ALIAS_FLAG);
        myPaintShape.setStyle(Paint.Style.FILL);
        myPaintShape.setColor(Color.parseColor("#50000000"));
        myPaintShape.setAntiAlias(true);

        point1 = new Point();
        point2 = new Point();
        point3 = new Point();
        point4 = new Point();

        pointQuadTop = new Point();
        pointQuadBottom = new Point();

        setLayerType(LAYER_TYPE_SOFTWARE, null);

    }

    public void setProductBitmapDrawable(Bitmap productBitmapDrawable) {
        this.productBitmapDrawable = productBitmapDrawable;
    }

    public void drawImprintAreaPreviewView(ProductDetailVo.DataVo.ImprintInfoVo product, int productImageWidth, int productImageHeight, int imageViewWidth, int imageViewHeight, OnPreviewViewDrawResultListener listener) {

//        this.productBitmapDrawable = bitmap;
        this.productListVo = product;
        this.onPreviewViewResultListener = listener;

        if (productImageWidth > 0 && productImageHeight > 0) {
//            this.widthDrawable = productImageWidth;
//            this.heightDrawable = productImageHeight;
            this.widthProduct = productImageWidth;
            this.heightProduct = productImageHeight;
            float screenWidth = DensityUtils.getScreenWidth(context);
            float setUpHeight = widthProduct * (screenWidth / heightProduct);
/*
            float screenWidth = DensityUtils.getScreenWidth(context);
//            float setUpHeight = heightDrawable * (screenWidth / widthDrawable);*/

            /*this.rootWidth = (int) screenWidth;
            this.rootHeight = (int) setUpHeight;*/
            this.rootWidth = (int) imageViewWidth;
            this.rootHeight = (int) setUpHeight;

//            this.rootWidth = (int) widthProduct;
//            this.rootHeight = (int) heightProduct;
//            this.rootHeight = (int) 800;


            source = new Rect(0, 0, (int)widthProduct, (int)heightProduct);
            dest = new Rect(0, 0, rootWidth, rootHeight);


            //Set ImageView Height/Width
            this.getLayoutParams().width = rootWidth;
            this.getLayoutParams().height = rootHeight;

            mImprintParamVo = productListVo.getImprintParam();
            mImprintAreaType = mImprintParamVo.getProductTemplateObjectShape();

//            this.setLayoutParams(new FrameLayout.LayoutParams(rootWidth,rootHeight));

//            Log.v(TA, "Drawable Width:--" + widthDrawable + "heightDrawable:--" + heightDrawable);
            Log.v(TA, "Drawable RootWidth:--" + rootWidth + "rootHeight:--" + rootHeight);
            Log.v(TA, "Drawable widthProduct:--" + widthProduct + "heightProduct:--" + heightProduct);
        } else {
            onPreviewViewResultListener.onPreviewViewResult(false);
            Log.v(TA, "Drawable null found");
        }


    }

    public boolean isPreviewView() {
        return isPreviewView;
    }

    public void setPreviewView(boolean value) {
        isPreviewView = value;

    }

    public void reDraw() {
        if (onPreviewViewResultListener != null)
            onPreviewViewResultListener.onPreviewViewDrawLoad();
        invalidate();

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (isInEditMode())
            return;
        try {
            if (isPreviewView && productBitmapDrawable != null) {
                canvas.drawBitmap(productBitmapDrawable, source, dest, mPaint);
            } else {
                canvas.drawRect(0, 0, rootWidth, rootHeight, myPaintShape);
    //                canvas.drawARGB(100, 0, 0, 0);
            }


//            List<Product> products = productListVo.getProductAreaArrayList();


            float aspectRatioWidth = rootWidth / widthProduct;
            float aspectRatioHeight = rootHeight / heightProduct;
//            for (Product item : products) {


            if (mImprintAreaType != null) {

                if (mImprintAreaType.equalsIgnoreCase(ImprintAreaType.RECTANGLE) || mImprintAreaType.equalsIgnoreCase(ImprintAreaType.CUSTOM)) {

                    PointVo imprintPoint1 = mImprintParamVo.getImptintPoints().getPoint1();
                    PointVo imprintPoint2 = mImprintParamVo.getImptintPoints().getPoint2();
                    PointVo imprintPoint3 = mImprintParamVo.getImptintPoints().getPoint3();
                    PointVo imprintPoint4 = mImprintParamVo.getImptintPoints().getPoint4();

                    float x1 = imprintPoint1.getX() * aspectRatioWidth;
                    float x2 = imprintPoint2.getX() * aspectRatioWidth;
                    float x3 = imprintPoint3.getX() * aspectRatioWidth;
                    float x4 = imprintPoint4.getX() * aspectRatioWidth;

                    float y1 = imprintPoint1.getY() * aspectRatioHeight;
                    float y2 = imprintPoint2.getY() * aspectRatioHeight;
                    float y3 = imprintPoint3.getY() * aspectRatioHeight;
                    float y4 = imprintPoint4.getY() * aspectRatioHeight;

                    point1.set((int) x1, (int) y1);
                    point2.set((int) x2, (int) y2);
                    point3.set((int) x3, (int) y3);
                    point4.set((int) x4, (int) y4);

                    Path path = drawRectangleImptintArea(point1, point2, point3, point4);
                    Paint transparentPaint = getImprintPaint();
                    canvas.drawPath(path, transparentPaint);
                } else if (mImprintAreaType.equalsIgnoreCase(ImprintAreaType.CIRCLE)) {
                    PointVo circlePoints = mImprintParamVo.getImptintPoints().getCirclePoints();
                    float circleRadius = mImprintParamVo.getImptintPoints().getRadius() * aspectRatioWidth;
                    float cX = (circlePoints.getX() * aspectRatioWidth);
                    float cY = circlePoints.getY() * aspectRatioHeight;
                    Paint transparentPaint = getImprintPaint();
                    canvas.drawCircle(cX, cY, circleRadius, transparentPaint);
                } else if (mImprintAreaType.equalsIgnoreCase(ImprintAreaType.MUG_2)){
                    PointVo imprintPoint1 = mImprintParamVo.getImptintPoints().getPoint1();
                    PointVo imprintPoint2 = mImprintParamVo.getImptintPoints().getPoint2();
                    PointVo imprintPoint3 = mImprintParamVo.getImptintPoints().getPoint3();
                    PointVo imprintPoint4 = mImprintParamVo.getImptintPoints().getPoint4();

                    PointVo imprintQuadPintTop = mImprintParamVo.getImptintPoints().getCurveTop();
                    PointVo imprintQuadPintBottom = mImprintParamVo.getImptintPoints().getCurveBottom();

                    float x1 = imprintPoint1.getX() * aspectRatioWidth;
                    float x2 = imprintPoint2.getX() * aspectRatioWidth;
                    float x3 = imprintPoint3.getX() * aspectRatioWidth;
                    float x4 = imprintPoint4.getX() * aspectRatioWidth;

                    float y1 = imprintPoint1.getY() * aspectRatioHeight;
                    float y2 = imprintPoint2.getY() * aspectRatioHeight;
                    float y3 = imprintPoint3.getY() * aspectRatioHeight;
                    float y4 = imprintPoint4.getY() * aspectRatioHeight;

                    float quadTopX = imprintQuadPintTop.getX() * aspectRatioWidth;
                    float quadBottomX = imprintQuadPintBottom.getX() * aspectRatioWidth;

                    float quadTopY = imprintQuadPintTop.getY() * aspectRatioHeight;
                    float quadBottomY = imprintQuadPintBottom.getY() * aspectRatioHeight;

                    point1.set((int) x1, (int) y1);
                    point2.set((int) x2, (int) y2);
                    point3.set((int) x3, (int) y3);
                    point4.set((int) x4, (int) y4);

                    pointQuadTop.set((int) quadTopX, (int) quadTopY);
                    pointQuadBottom.set((int) quadBottomX, (int) quadBottomY);

                    Paint transparentPaint = getImprintPaint();
                    Path path = drawCyinderImprintArea(point1, point2, point3, point4,  pointQuadTop,pointQuadBottom);
                    canvas.drawPath(path, transparentPaint);
                }

    //            }
                onPreviewViewResultListener.onPreviewViewResult(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }



    @NonNull
    private Paint getImprintPaint() {
        Paint transparentPaint = new Paint();
        transparentPaint.setColor(Color.WHITE);
        transparentPaint.setAntiAlias(true);
        transparentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        return transparentPaint;
    }

    private Path drawRectangleImptintArea(Point point1, Point point2, Point point3, Point point4) {
        Path path = new Path();
        path.moveTo(point1.x, point1.y);
        path.lineTo(point2.x, point2.y);
        path.lineTo(point3.x, point3.y);
        path.lineTo(point4.x, point4.y);
        path.close();
        return path;

    }

    private Path drawCyinderImprintArea(Point point1, Point point2, Point point3, Point point4, Point pointQuadTop, Point pointQuadBottom) {
        Path path = new Path();
        path.moveTo(point1.x, point1.y);
        path.quadTo(pointQuadTop.x, pointQuadTop.y, point2.x, point2.y);
        path.lineTo(point3.x, point3.y);
        path.quadTo(pointQuadBottom.x, pointQuadBottom.y, point4.x, point4.y);
        path.close();
        return path;
    }


    public int getWidthDrawable() {
        return rootWidth;
    }

    public int getHeightDrawable() {
        return rootHeight;
    }

    public void initDraw(Context context, ProductDetailVo.DataVo.ImprintInfoVo product, int productWidth, int productHeight, int rootProductwidth, int rootproductHeight) {

        this.context = context;
        this.productListVo = product;
//        this.widthDrawable = productWidth;
//        this.heightDrawable = productHeight;

        this.rootWidth = rootProductwidth;
        this.rootHeight = rootproductHeight;

    }

    public interface OnPreviewViewDrawResultListener {
        void onPreviewViewDrawLoad();

        void onPreviewViewResult(boolean result);
    }


}
