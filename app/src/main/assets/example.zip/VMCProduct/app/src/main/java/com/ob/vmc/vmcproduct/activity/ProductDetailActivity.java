package com.ob.vmc.vmcproduct.activity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.andoblib.io.FileIO;
import com.andoblib.listener.YesNoAlertDialogListener;
import com.andoblib.log.CustomLogHandler;
import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.ProductDetailColorAdapter;
import com.ob.vmc.vmcproduct.adapter.ProductDetailPagerAdapter;
import com.ob.vmc.vmcproduct.adapter.ProductDetailThumbAdapter;
import com.ob.vmc.vmcproduct.constant.AppConstant;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WSValueConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.httpmodel.GetSupplierDetailVo;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.permission.OnPermissionActionListner;
import com.ob.vmc.vmcproduct.permission.PemissionBaseActivity;
import com.ob.vmc.vmcproduct.utils.Util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by khyati5403 on 10/12/2016.
 */
public class ProductDetailActivity extends PemissionBaseActivity implements ProductDetailThumbAdapter.onThumbClickListener, ProductDetailColorAdapter.onColorClick, OnCompleteListener, YesNoAlertDialogListener, OnPermissionActionListner {

    public static final String PRODUCT_NAME = "ProductName";
    public static final String PRODUCT_SKU = "productsku";
    public static final String PRODUCT_SUPPLIER = "productSupplier";
    public static final String SUPPLIER_ID = "supplier_id";
    private static final String TAG = ProductDetailActivity.class.getSimpleName();
    private static final int REQUEST_DIALOG_SAVE_VIRTUAL = 101;
    private static final int REQUEST_VIRTUAL_SAVE_PERMISSION = 102;
    private static final int REQUEST_VIRTUAL_DELETE_PERMISSION = 103;
    private ViewPager vp_ProductImage;
    private RecyclerView rv_ProductThumb, rv_ProductColor;
    private String sku;

    private int mSideIndex = 0;
    private TextView tv_ProductName, tv_ProductSku, tv_ProductSupplier, tv_ProductDetail;
    private int mProductColorIndex;
    private ProductDetailVo.DataVo productDataVo;
    private String prodcuctTitle;
    private String supplierId;
    //    private String supplierType;
    private View fab_Virtual;
    private GetSupplierDetailVo.DataVo supplierDetailVo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);


        setupToolbar();
        bundlesArg();
        initView();
        initAdapters();
        fab_Virtual = findViewById(R.id.apd_fabVirtual);
        fab_Virtual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductDetailActivity.this, ProductVirtualActivity.class);
                intent.putExtra(ProductVirtualActivity.BASIC_INFO, productDataVo.getBasicInformation());
                intent.putExtra(ProductVirtualActivity.IMPRINT_INFO, productDataVo.getImprintInfo().get(mSideIndex));
                intent.putExtra(ProductVirtualActivity.SIDE_DETAIL, productDataVo.getSides().get(mSideIndex).getSideImage().get(mProductColorIndex));

                intent.putExtra(ProductVirtualActivity.CONFIGURATION_OPTION, supplierDetailVo.getSupplierDetail().getConfigurationOptions());
                startActivity(intent);
            }
        });
        callProductDetails();
    }

    private void callSupplierDetails() {

        CommonUtil.showProgressDialog(this, null, null, false, null, -1, getSupportFragmentManager());
        List<NameValuePair> postHeader = Util.getDefaultHeader(this);
        List<NameValuePair> postparams = new ArrayList<>();
        final String supplierType = AppSetting.getString(this, SharePrefConstant.KEY_SUPPLIER_TYPE, "");
        final String id = AppSetting.getString(this, SharePrefConstant.KEY_SUPPLIER_ID, "");
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID, id));
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_TYPE, supplierType));
        FormHttpCaller formHttpCaller = new FormHttpCaller(this, WSUrlConstant.getSupplierDetail(), APIType.METHOD_GET, postHeader, postparams, WSRequestCodeConstant.REQUEST_GET_SUPPLIER_DETAIL, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    private void bundlesArg() {
        Bundle bundle = getIntent().getExtras();
        if (bundle == null) {
            finish();
        }
        supplierId = bundle.getString(SUPPLIER_ID, null);
        prodcuctTitle = bundle.getString(PRODUCT_NAME, null);
        sku = bundle.getString(PRODUCT_SKU, null);
    }

    private void setupToolbar() {
        Toolbar mToolbar = (Toolbar) findViewById(R.id.product_toolbar);
        mToolbar.setNavigationIcon(R.drawable.back_icon);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        ImageView ivUploadVirtualWork = (ImageView) mToolbar.findViewById(R.id.vt_ivUploadProduct);
        ivUploadVirtualWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (productDataVo != null && productDataVo.getBasicInformation() != null) {


                    File productFile = new File(AppConstant.getAppProductImageDirectory(productDataVo.getBasicInformation().getSku()));
                    if (productFile.exists() && productFile.list().length > 0) {
                        Intent intent = new Intent(ProductDetailActivity.this, UploadVirtualProductActivity.class);
                        intent.putExtra(UploadVirtualProductActivity.VIRTUAL_NAME, productDataVo.getProductInformation().getTitle());
                        intent.putExtra(UploadVirtualProductActivity.VIRTUAL_SKU, productDataVo.getBasicInformation().getSku());
                        startActivity(intent);
//                        Toast.makeText(ProductDetailActivity.this, "Uploading", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ProductDetailActivity.this, "Virtual not available", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void initView() {
        vp_ProductImage = (ViewPager) findViewById(R.id.apd_vpProductImage);

        rv_ProductThumb = (RecyclerView) findViewById(R.id.apd_rvImagesList);
        RecyclerView.LayoutManager lm_layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rv_ProductThumb.setLayoutManager(lm_layoutManager);


        rv_ProductColor = (RecyclerView) findViewById(R.id.apd_rvImagesColor);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rv_ProductColor.setLayoutManager(layoutManager);

        tv_ProductName = (TextView) findViewById(R.id.apd_tvProductName);
        tv_ProductName.setText(prodcuctTitle);
        tv_ProductSku = (TextView) findViewById(R.id.apd_tvSkuValue);
        tv_ProductSku.setText(sku);
        tv_ProductSupplier = (TextView) findViewById(R.id.apd_tvSupplierValue);
        tv_ProductDetail = (TextView) findViewById(R.id.apd_tvProductDetail);
    }


    private void initAdapters() {

        vp_ProductImage.setAdapter(new ProductDetailPagerAdapter(this, mProductColorIndex));

        ProductDetailColorAdapter mColorAdapter = new ProductDetailColorAdapter(this, mSideIndex, this);
        rv_ProductColor.setAdapter(mColorAdapter);

        ProductDetailThumbAdapter mThumbAdapter = new ProductDetailThumbAdapter(this, 0, this);
        rv_ProductThumb.setAdapter(mThumbAdapter);

        vp_ProductImage.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                mSideIndex = position;
                rv_ProductThumb.scrollToPosition(position);
                updateProductColorList();
            }
        });
    }

    private void callProductDetails() {


        CommonUtil.showProgressDialog(this, null, null, false, null, -1, getSupportFragmentManager());


        List<NameValuePair> postHeader = Util.getDefaultHeader(this);

//        String supplierId = AppSetting.getString(this, SharePrefConstant.KEY_SUPPLIER_ID, "");
        List<NameValuePair> postparams = new ArrayList<>();
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID, supplierId));
        postparams.add(new NameValuePair(WSKeyConstant.KEY_LOCALE, WSValueConstant.EN_US));
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SKU, sku));
/*
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID, "621"));
        postparams.add(new NameValuePair(WSKeyConstant.KEY_LOCALE, WSValueConstant.EN_US));
        postparams.add(new NameValuePair(WSKeyConstant.KEY_SKU, "BTD500"));
*/

        FormHttpCaller formHttpCaller = new FormHttpCaller(this, WSUrlConstant.productDetailAPIUrl(), APIType.METHOD_GET, postHeader, postparams, WSRequestCodeConstant.REQUEST_GET_PRODUCT_DETAIL, new ResponseHandler(this));
        formHttpCaller.execute();

    }


    @Override
    public void onThumbClick(int position) {

        vp_ProductImage.setCurrentItem(position);
        mSideIndex = position;
   /*    ProductDetailThumbAdapter productDetailThumbAdapter= (ProductDetailThumbAdapter) .getAdapter();
        productDetailThumbAdapter.setSelectedItem(mSideIndex);
        productDetailThumbAdapter.setPColorIndex(mSideIndex);*/
        updateProductColorList();
    }

    private void updateProductColorList() {
        if (productDataVo != null) {
            List<ProductDetailVo.DataVo.SidesVo> sidesVos = productDataVo.getSides();
            if (sidesVos != null && sidesVos.size() > 0) {
                List<ProductDetailVo.DataVo.SidesVo.SideImageVo> sideImageVos = sidesVos.get(mSideIndex).getSideImage();
                ProductDetailColorAdapter colorAdapter = (ProductDetailColorAdapter) rv_ProductColor.getAdapter();
                colorAdapter.setProductSideList(sideImageVos);
                colorAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onItemColorSelect(int position) {
        mProductColorIndex = position;

        //Product Sides Original Image Veiw pager Adapter
        ProductDetailPagerAdapter detailPagerAdapter = (ProductDetailPagerAdapter) vp_ProductImage.getAdapter();
        detailPagerAdapter.setPColorIndex(mProductColorIndex);
        detailPagerAdapter.notifyDataSetChanged();

        //Product Sides Thumb Image Veiw pager Adapter
        ProductDetailThumbAdapter thumbAdapter = (ProductDetailThumbAdapter) rv_ProductThumb.getAdapter();
        thumbAdapter.setPColorIndex(mProductColorIndex);
        thumbAdapter.notifyDataSetChanged();

        CustomLogHandler.printInfo(TAG, mSideIndex + "");

    }

    private void initproductBasicDetail() {

        ProductDetailVo.DataVo.ProductInformationVo productInformationVo = productDataVo.getProductInformation();

        if (productInformationVo == null)
            return;

        String productName = productInformationVo.getTitle();
        if (productName != null)
            tv_ProductName.setText(productName);
        else
            tv_ProductName.setText("---");


        String productDescrption = productInformationVo.getDescription();

        if (productDescrption != null)
            tv_ProductDetail.setText(Html.fromHtml(productDescrption));

        ProductDetailVo.DataVo.BasicInformationVo basicInformationVo = productDataVo.getBasicInformation();

        if (basicInformationVo == null)
            return;

        String productSku = basicInformationVo.getSku();
        if (productSku != null)
            tv_ProductSku.setText(productSku);

        ProductDetailVo.DataVo.BasicInformationVo.SuplierVo suppliersVo = basicInformationVo.getSuplier();
        if (suppliersVo == null)
            return;

        String supplierName = suppliersVo.getSupplierName();
        if (supplierName != null)
            tv_ProductSupplier.setText(supplierName);
        else
            tv_ProductSupplier.setText("---");

    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {

        BaseVo baseVo = (BaseVo) itemObj;
        CommonUtil.dismissProgressDialog();
        if (requestCode == WSRequestCodeConstant.REQUEST_GET_PRODUCT_DETAIL) {
            if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                ProductDetailVo detailVo = (ProductDetailVo) baseVo;
                productDataVo = detailVo.getData();

                initproductBasicDetail();


                List<ProductDetailVo.DataVo.SidesVo> sidesVos = detailVo.getData().getSides();
                if (sidesVos != null && sidesVos.size() > 0) {
                    List<ProductDetailVo.DataVo.SidesVo.SideImageVo> sideImageVo = sidesVos.get(0).getSideImage();
                    if (sideImageVo != null && sideImageVo.size() > 0) {
                        int indexCount = 0;
                        for (ProductDetailVo.DataVo.SidesVo.SideImageVo pSideImageVo : sideImageVo) {
                            String isDefault = pSideImageVo.getIsDefault();

                            if (isDefault != null && isDefault.equalsIgnoreCase("1")) {
                                mProductColorIndex = indexCount;
                                break;
                            }
                            indexCount++;
                        }


                        //Product Color Image Adapter
                        ProductDetailColorAdapter colorAdapter = (ProductDetailColorAdapter) rv_ProductColor.getAdapter();
                        colorAdapter.setColorIndex(mProductColorIndex);
                        ProductDetailVo.DataVo.SidesVo sidesVo = productDataVo.getSides().get(mSideIndex);
                        if (sidesVo != null && sidesVo.getSideImage() != null) {
                            colorAdapter.setProductSideList(sidesVo.getSideImage());
                            colorAdapter.notifyDataSetChanged();
                        }
                        rv_ProductColor.scrollToPosition(mProductColorIndex);

                        //Product Sides Original Image Veiw pager Adapter
                        ProductDetailPagerAdapter detailPagerAdapter = (ProductDetailPagerAdapter) vp_ProductImage.getAdapter();
                        detailPagerAdapter.setPColorIndex(mProductColorIndex);
                        detailPagerAdapter.setProductSidesList(productDataVo.getSides());
                        detailPagerAdapter.notifyDataSetChanged();


                        //Product Sides Thumb Image Veiw pager Adapter
                        ProductDetailThumbAdapter thumbAdapter = (ProductDetailThumbAdapter) rv_ProductThumb.getAdapter();
                        thumbAdapter.setPColorIndex(mProductColorIndex);
                        thumbAdapter.setSidesList(productDataVo.getSides());
                        thumbAdapter.notifyDataSetChanged();
                        fab_Virtual.setVisibility(View.VISIBLE);
                        callSupplierDetails();

                    } else {
                        fab_Virtual.setVisibility(View.GONE);
                        Toast.makeText(this, "Sides Color list not found.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    fab_Virtual.setVisibility(View.GONE);
                    Toast.makeText(this, "Sides Not found.", Toast.LENGTH_SHORT).show();
                }
            }
            checkSinglePermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "Allowed STORAGE permission for save your virtual work.", REQUEST_VIRTUAL_DELETE_PERMISSION);
        } else if (requestCode == WSRequestCodeConstant.REQUEST_GET_SUPPLIER_DETAIL) {
            if (baseVo.getStatus() == WsStatusCode.STATUS_1) {
                GetSupplierDetailVo getSupplierDetailVo = (GetSupplierDetailVo) baseVo;
                supplierDetailVo = getSupplierDetailVo.getData();
            }
        }

    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        Toast.makeText(this, baseVo.getCustomException().getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(Object itemObj) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        Toast.makeText(this, baseVo.getMessage(), Toast.LENGTH_SHORT).show();
    }

    private void deniedVirtualProduct() {
        CommonUtil.showYesNoDialog(this, null, "If you go back without upload this virtual product,You may loss this product.", "GO BACK ", "DISMISS", true, REQUEST_DIALOG_SAVE_VIRTUAL, this, getSupportFragmentManager());
    }


    public boolean checkIsVirtualProductAvailable() {
        if (productDataVo != null) {
            File artFile = new File(AppConstant.getAppProductArtworkDirectory(productDataVo.getBasicInformation().getSku(), false));
            File productFile = new File(AppConstant.getAppProductImageDirectory(productDataVo.getBasicInformation().getSku()));
            boolean isartWorkExist = isArtWorkExist(artFile);
            boolean isProductSave = isProductImageexist(productFile);
            if (isartWorkExist && isProductSave) {
                return true;
            } else if (isartWorkExist && !isProductSave) {
                deleteSkuAllVirtualsFiles();
            }
        }
        return false;
    }

    boolean isProductImageexist(File productFile) {
        return productFile.exists() && productFile.list().length > 0;
    }

    private boolean isArtWorkExist(File artFile) {
        return artFile.exists() && artFile.listFiles().length > 0;
    }


    @Override
    public void onBackPressed() {
        if (checkIsVirtualProductAvailable()) {
            deniedVirtualProduct();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onYesNoDialogButtonClicked(int pRequestCode, int pWhichButton) {
        if (pRequestCode == REQUEST_DIALOG_SAVE_VIRTUAL) {
            if (pWhichButton == YesNoAlertDialogListener.BUTTON_POSITIVE) {
                checkSinglePermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE, "Allowed STORAGE permission for save your virtual work.", REQUEST_VIRTUAL_SAVE_PERMISSION);
            } else if (pWhichButton == YesNoAlertDialogListener.BUTTON_NEGATIVE) {
            }
        }
    }

    @Override
    public void permissionDenied(int requestCode) {
        if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            Toast.makeText(this, "Denied STORAGE permission, Can't save your virtual work.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_VIRTUAL_DELETE_PERMISSION) {
            Toast.makeText(this, "Denied STORAGE permission,application not work properly.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void permissionGranted(int requestCode) {
        if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            deleteSkuAllVirtualsFiles();
            finish();
        } else if (requestCode == REQUEST_VIRTUAL_DELETE_PERMISSION) {
            deleteSkuAllVirtualsFiles();
        }
    }

    private void deleteSkuAllVirtualsFiles() {
        String productArtdirectory = AppConstant.getAppProductArtworkDirectory(productDataVo.getBasicInformation().getSku(), false);
        FileIO.deleteDirectory(productArtdirectory);
        String productVirtualDirectory = AppConstant.getAppProductImageDirectory(productDataVo.getBasicInformation().getSku());
        FileIO.deleteDirectory(productVirtualDirectory);
    }

    @Override
    public void permissionNeverAsked(int requestCode) {
        if (requestCode == REQUEST_VIRTUAL_SAVE_PERMISSION) {
            Toast.makeText(this, "STORAGE permission denied with never ask, Please allowed STORAGE permission from device settings to store your virtual work.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_VIRTUAL_DELETE_PERMISSION) {
            Toast.makeText(this, "STORAGE permission denied with never ask, Please allowed STORAGE permission from device settings.", Toast.LENGTH_SHORT).show();
        }
    }
}
