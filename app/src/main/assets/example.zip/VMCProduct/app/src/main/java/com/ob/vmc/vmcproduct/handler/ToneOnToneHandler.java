package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;
import com.ob.vmc.vmcproduct.effects.ToneOnToneEffectAsync;

/**
 * Created by khyati5403 on 1/5/2017.
 */

public class ToneOnToneHandler {

    private Context mContext;
    private ToneOnToneEffectAsync.ToneOnToneResult mToneOnToneResult;
    private String mBitmapPath;
    private boolean isColor;
    private int mSelectColor;
    private Bitmap bitmap;

    public ToneOnToneHandler(Context mContext, ToneOnToneEffectAsync.ToneOnToneResult mToneOnToneResult) {
        this.mContext = mContext;
        this.mToneOnToneResult = mToneOnToneResult;
    }

    public ToneOnToneHandler(Context mContext) {
        this.mContext = mContext;
    }

    public ToneOnToneHandler setSingleColor(boolean color, Bitmap mBitmapPath, int colorCode) {
        isColor = color;
        bitmap = mBitmapPath;
        mSelectColor = colorCode;
        return this;
    }

    public Bitmap executeProcess(Bitmap srcBitmap, int mSelectColor){
        try {
            if (srcBitmap != null) {
                srcBitmap = BitmapProcessing.darker(srcBitmap, mSelectColor, 0.9f);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        return  srcBitmap;
    }
}
