package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.adapter.ProductListAdapter;
import com.ob.vmc.vmcproduct.communicator.OnItemClickListener;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.httpmodel.Product;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductVo;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OnCompleteListener, OnItemClickListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    private TextView tvSupplier;
    private Spinner spSupplierList;
    private RecyclerView rvSupplierList;
    private ProductListAdapter mProductListAdapter;
    List<SuppliersVO.DataVo.SuppliersVo> suppliersVOList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initView();
    }


    public void initView() {
        tvSupplier = (TextView) findViewById(R.id.cm_tvSupplier);
        spSupplierList = (Spinner) findViewById(R.id.cm_spSupplierList);
        rvSupplierList = (RecyclerView) findViewById(R.id.cm_rvSupplierList);

        String url= WSUrlConstant.urlAppendWithBaseUrl(WSUrlConstant.API_SUPPLIER);
        String supplierId= AppSetting.getString(this, SharePrefConstant.KEY_SUPPLIER_ID,"");
        List<NameValuePair> postParams=new ArrayList<>();
        postParams.add(new NameValuePair(WSKeyConstant.KEY_SUPPLIER_ID,supplierId));


        List<NameValuePair> postHeader= Util.getDefaultHeader(this);

        FormHttpCaller formHttpCaller = new FormHttpCaller(getBaseContext(), url, APIType.METHOD_GET,postHeader, postParams, WSRequestCodeConstant.REQUEST_SUPPLIER, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();

        if (requestCode == WSRequestCodeConstant.REQUEST_SUPPLIER) {
            BaseVo baseVo = (BaseVo) itemObj;

            if (baseVo.getStatus()== WsStatusCode.STATUS_1) {
                SuppliersVO suppliersVO = (SuppliersVO) itemObj;

                suppliersVOList = suppliersVO.getData().getSuppliers();

                List<String> list = new ArrayList<>();
                for (int i = 0; i < suppliersVOList.size(); i++) {
                    String supplierName = suppliersVOList.get(i).getSupplierName();
                    list.add(supplierName);
//                CustomLogHandler.printInfo(TAG, list.get(i).toString());

                }
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spSupplierList.setAdapter(dataAdapter);
                // Spinner item selection Listener
                addListenerOnSpinnerItemSelection();
            }else
            {
                Toast.makeText(this, baseVo.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }else if (requestCode == WSRequestCodeConstant.REQUEST_GET_PRODUCT) {
            ProductVo productVo = (ProductVo) itemObj;

            ProductVo.Data product = ((ProductVo)productVo).getData();
            if (productVo != null) {
                List<Product> productList;
                productList = product.getProducts();

                mProductListAdapter = new ProductListAdapter(productList, getApplicationContext(), this);
                RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                rvSupplierList.setLayoutManager(mLayoutManager);
                rvSupplierList.setAdapter(mProductListAdapter);
            }
        }

    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
    }

    @Override
    public void onError(Object itemObj) {
        CommonUtil.dismissProgressDialog();
    }

    private void addListenerOnSpinnerItemSelection() {

        spSupplierList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                callSupplierListAPI(suppliersVOList.get(i).getId());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void callSupplierListAPI(String id) {
        CommonUtil.showProgressDialog(this, null, null, false, null, -1, getSupportFragmentManager());
        String url= WSUrlConstant.urlAppendWithBaseUrl(WSUrlConstant.API_GET_PRODUCT) + "?" + WSKeyConstant.KEY_SUPPLIER_ID + "="+ id;

        FormHttpCaller formHttpCaller = new FormHttpCaller(getBaseContext(), url, APIType.METHOD_GET, null, WSRequestCodeConstant.REQUEST_GET_PRODUCT, new ResponseHandler(this));
        formHttpCaller.execute();
    }

    @Override
    public void onItemClick(Product product) {
        Intent detailIntent = new Intent(this, ProductDetailActivity.class);
        detailIntent.putExtra("ProductImage", product.getProductImage());
        startActivity(detailIntent);
    }
}
