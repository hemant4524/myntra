package com.ob.vmc.vmcproduct.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.View;

import com.ob.vmc.vmcproduct.R;

/**
 * Created by khyati5403 on 11/2/2016.
 */

public class CircleView extends View {
    private Bitmap overLayBitmap;
    private boolean isSelected;

    private int circleRadius = 30;
    private int strokeColor = 0xFFFF8C00;
    private int strokeWidth = 5;
    private int fillColor = 0XFFFFAB00;
    private int circleGap = 0;
    private int parentWidth, parentHeight;
    private Paint bitmapPaint;
    private Rect rect;
    Rect des;
    private Paint paint;

    public CircleView(Context context) {
        super(context);
        init(context, null);
    }

    public CircleView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
        init(context, attrs);
    }

    public CircleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CircleView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        paint = new Paint();
        paint.setAntiAlias(true);

        TypedArray aTypedArray = context.obtainStyledAttributes(attrs, R.styleable.CircleView);

        strokeColor = aTypedArray.getColor(R.styleable.CircleView_strokeColor, strokeColor);
        strokeWidth = aTypedArray.getDimensionPixelSize(R.styleable.CircleView_strokeWidth, strokeWidth);
        fillColor = aTypedArray.getColor(R.styleable.CircleView_fillColor, fillColor);
        circleRadius = aTypedArray.getDimensionPixelSize(R.styleable.CircleView_circleRadius, circleRadius);
        circleGap = aTypedArray.getDimensionPixelSize(R.styleable.CircleView_circleGap, circleGap);
        int bitmapRef = aTypedArray.getResourceId(R.styleable.CircleView_circleBitmap,R.drawable.ic_done_white_24dp);
        isSelected= aTypedArray.getBoolean(R.styleable.CircleView_showDefaultBitmap,false);

        overLayBitmap= BitmapFactory.decodeResource(getResources(),bitmapRef);

        rect=new Rect(0,0,parentWidth,parentHeight);
        des=new Rect(0,0,parentWidth,parentHeight);

        bitmapPaint=new Paint();
        bitmapPaint.setAntiAlias(true);

        this.setMinimumHeight(circleRadius * 2 + strokeWidth);
        this.setMinimumWidth(circleRadius * 2 + strokeWidth);
        this.setSaveEnabled(true);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = this.getWidth();
        int h = this.getHeight();

        int ox = w/2;
        int oy = h/2;

        canvas.drawCircle(ox, oy, circleRadius, getStroke());
        canvas.drawCircle(ox, oy, circleRadius - circleGap, getFill());

        if(isSelected){
            int divW=parentWidth/2;
            int divH=parentHeight/2;

            int imgW=overLayBitmap.getWidth()/2;
            int imgH=overLayBitmap.getHeight()/2;

            int diffW=divW-imgW;
            int diffH=divH-imgH;

            rect.set(0, 0, parentWidth, parentHeight);

            des.set(diffW,diffH,overLayBitmap.getWidth()+diffW,overLayBitmap.getHeight()+diffH);

            canvas.drawBitmap(overLayBitmap, rect, des, bitmapPaint);
        }
    }

    public void setOverlayBitmap(int draw) {
        overLayBitmap= BitmapFactory.decodeResource(getResources(),draw);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        parentWidth = MeasureSpec.getSize(widthMeasureSpec);
        parentHeight = MeasureSpec.getSize(heightMeasureSpec);
        this.setMeasuredDimension(parentWidth, parentHeight);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public void setSelected(boolean selected) {
        isSelected=selected;
    }

    private Paint getStroke()
    {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStrokeWidth(strokeWidth);
        paint.setColor(strokeColor);
        paint.setStyle(Paint.Style.STROKE);
        return paint;
    }

    private Paint getFill()
    {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(fillColor);
        paint.setStyle(Paint.Style.FILL);
        return paint;
    }

    public int getCircleRadius() {
        return circleRadius;
    }

    public void setCircleRadius(int circleRadius) {
        this.circleRadius = circleRadius;
    }

    public int getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(int strokeColor) {
        this.strokeColor = strokeColor;
    }

    public int getStrokeWidth() {
        return strokeWidth;
    }

    public void setStrokeWidth(int strokeWidth) {
        this.strokeWidth = strokeWidth;
    }

    public int getFillColor() {
        return fillColor;
    }

    public void setFillColor(int fillColor) {
        this.fillColor = fillColor;
    }

    public int getCircleGap() {
        return circleGap;
    }

    public void setCircleGap(int circleGap) {
        this.circleGap = circleGap;
    }

    public void notifyView() {
        invalidate();
    }

}
