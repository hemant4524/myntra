package com.ob.vmc.vmcproduct.effects;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.customviews.BubbleTextView;
import com.ob.vmc.vmcproduct.customviews.StickerView;

/**
 * Created by Ishan4452 on 1/5/2017.
 */

public class ViewsEffectsThread extends Thread {

    private static final String TAG = ViewsEffectsThread.class.getSimpleName();
    private Handler mHandler;
    private int totalQueued;
    private int totalCompleted;
    private StickerEffectTaskListener listener;


    public ViewsEffectsThread(StickerEffectTaskListener listener) {
        this.listener = listener;
    }


    @Override
    public void run() {
        try {
            // preparing a looper on current thread
            // the current thread is being detected implicitly
            Looper.prepare();


            // now, the handler will automatically bind to the
            // Looper that is attached to the current thread
            // You don't need to specify the Looper explicitly
            mHandler = new Handler();

            // After the following line the thread will start
            // running the message loop and will not normally
            // exit the loop unless a problem happens or you
            // quit() the looper (see below)
            Looper.loop();

        } catch (Throwable t) {
            Log.e(TAG, "ViewThread halted due to an error", t);
        }

    }

    // This method is allowed to be called from any thread
    public synchronized void requestStop() {
        // using the handler, post a Runnable that will quit()
        // the Looper attached to our DownloadThread
        // obviously, all previously queued tasks will be executed
        // before the loop gets the quit Runnable
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                // This is guaranteed to run on the DownloadThread
                // so we can use myLooper() to get its looper
                Log.i(TAG, "EffectThread loop quitting by request");

                Looper.myLooper().quit();
            }
        });
    }


    public synchronized void enqueueStickerEffect(final StickerEffectsTask task) {
        // Wrap DownloadTask into another Runnable to track the statistics
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    task.run();
                } catch (Exception e) {
                    CustomLogHandler.printVerbose(TAG,e.getMessage());

                    CustomLogHandler.printVerbose(TAG, "Task catch Completed:--" + totalCompleted);
                } finally {


                    // register task completion
                    synchronized (ViewsEffectsThread.this) {
                        totalCompleted++;
                    }
                    // tell the listener something has happened
                    CustomLogHandler.printVerbose(TAG, "Task Completed:--" + totalCompleted);
                    updateStickerView(task.getStickerView());
                }
            }
        });
        totalQueued++;
        CustomLogHandler.printVerbose(TAG,"Task Queued:--"+totalQueued);

    }


    public synchronized void enqueueBubbleViewEffect(final BubbleEffectsTask task) {
        // Wrap DownloadTask into another Runnable to track the statistics
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    task.run();
                } finally {
                    // register task completion
                    synchronized (ViewsEffectsThread.this) {
                        totalCompleted++;
                    }
                    // tell the listener something has happened
                    CustomLogHandler.printVerbose(TAG,"Task Completed:--"+totalCompleted);
                    updateBubbleView(task.getBubbleTextView());
                }
            }
        });
        totalQueued++;

    }

    public synchronized int getTotalQueued() {
        return totalQueued;
    }

    public synchronized int getTotalCompleted() {
        return totalCompleted;
    }


    private void updateStickerView(StickerView stickerView) {
        if (totalQueued == totalCompleted) {
            totalQueued=0;
            totalCompleted=0;
        }
        if (listener!=null) {
            listener.handleStickerEffectTaskUpdate(stickerView);
        }
    }

    private void updateBubbleView(BubbleTextView bubbleTextView) {
        if (totalQueued == totalCompleted) {
            totalQueued=0;
            totalCompleted=0;
        }
        if (listener!=null) {
            listener.handleBubbleEffectTaskUpdate(bubbleTextView);
        }
    }


}
