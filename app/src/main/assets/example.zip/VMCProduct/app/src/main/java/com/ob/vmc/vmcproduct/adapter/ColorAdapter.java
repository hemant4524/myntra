package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.customviews.CircleView;
import com.ob.vmc.vmcproduct.model.appmodel.PmshexcolorVo;

import java.util.List;

/**
 * Created by khyati5403 on 12/5/2016.
 */

public class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.ColorViewHolder> {

    private Context pContext;
    private List<PmshexcolorVo> colorList;

    private int pSelectedColor = 0;
    private OnColorClickListener pOnColorClickListener;
    public LayoutInflater inflater;

    public ColorAdapter(Context mContext, List<PmshexcolorVo> listColor, int mSelectedColor, OnColorClickListener mOnColorClickListener) {
        this.inflater = LayoutInflater.from(mContext);
        this.pContext = mContext;
        this.colorList = listColor;
        this.pSelectedColor = mSelectedColor;
        this.pOnColorClickListener = mOnColorClickListener;
    }

    @Override
    public ColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ColorViewHolder(inflater.inflate(R.layout.color_list, parent, false));
    }

    @Override
    public void onBindViewHolder(final ColorViewHolder holder, final int position) {

        holder.parent.setTag(R.id.tagKey_position, position);
        String colorCode = "#" + colorList.get(position).getHex();
        holder.mCircleView.setFillColor(Color.parseColor(colorCode));
        holder.mCircleView.setStrokeColor(Color.WHITE);
        holder.mCircleView.setSelected(pSelectedColor == position);
        holder.mCircleView.invalidate();
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selected = (int) v.getTag(R.id.tagKey_position);
                pOnColorClickListener.onColorClick(selected);
                int prevPostion=pSelectedColor;
                pSelectedColor=position;
                notifyItemChanged(prevPostion);
                notifyItemChanged(pSelectedColor);
                holder.mCircleView.setSelected(true);
                holder.mCircleView.notifyView();
//                setSelectedItem(selected);

            }
        });
    }

    @Override
    public int getItemCount() {
        return colorList.size();
    }

    public class ColorViewHolder extends RecyclerView.ViewHolder{

        private final View parent;
        private CircleView mCircleView;
        public ColorViewHolder(View itemView) {
            super(itemView);
            parent = itemView;
            mCircleView = (CircleView) parent.findViewById(R.id.cl_cvColorList);
        }
    }

    public interface OnColorClickListener{
        void onColorClick(int colorCode);
    }
}
