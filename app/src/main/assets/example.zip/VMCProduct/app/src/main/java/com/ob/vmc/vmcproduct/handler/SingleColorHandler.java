package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/2/2016.
 */

public class SingleColorHandler {

    private Context mContext;

    public SingleColorHandler(Context pContext) {
        mContext=pContext;
    }

    public Bitmap executeProcess(Bitmap pBitmapPath, int setColor) {


        try {
            pBitmapPath = BitmapProcessing.singleColor(pBitmapPath, setColor);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pBitmapPath;

    }
}
