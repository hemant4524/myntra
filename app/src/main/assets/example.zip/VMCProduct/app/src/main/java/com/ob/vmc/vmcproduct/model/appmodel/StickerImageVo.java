package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;

/**
 * Created by khyati5403 on 11/29/2016.
 */

public class StickerImageVo implements Parcelable {

    private FlipType flipType=FlipType.NONE;
    private EffectTypes effectType;
    private boolean isWhiteRemove;
    private boolean isBlackRemove;
    private int singleColorCode;
    private int embroideryColorCode;
    private int opacity;
    private String filePath;
    private int toneOnToneColorCode;
    private int leatherEngravedColorCode;

    public int getOpacity() {
        return opacity;
    }

    public void setOpacity(int opacity) {
        this.opacity = opacity;
    }

    public FlipType getFlipType() {
        return flipType;
    }

    public void setFlipType(FlipType flipType) {
        this.flipType = flipType;
    }

    public EffectTypes getEffectType() {
        return effectType;

    }

    public int getEmbroideryColorCode() {
        return embroideryColorCode;
    }

    public void setEmbroideryColorCode(int embroideryColorCode) {
        this.embroideryColorCode = embroideryColorCode;
    }

    public void setEffectType(EffectTypes effectType) {
        this.effectType = effectType;
    }

    public boolean isWhiteRemove() {
        return isWhiteRemove;
    }

    public void setWhiteRemove(boolean whiteRemove) {
        isWhiteRemove = whiteRemove;
    }

    public boolean isBlackRemove() {
        return isBlackRemove;
    }

    public void setBlackRemove(boolean blackRemove) {
        isBlackRemove = blackRemove;
    }

    public int getSingleColorCode() {
        return singleColorCode;
    }

    public void setSingleColorCode(int singleColorCode) {
        this.singleColorCode = singleColorCode;
    }

    public int getToneOnToneColorCode() {
        return toneOnToneColorCode;
    }

    public void setToneOnToneColorCode(int toneOnToneColorCode) {
        this.toneOnToneColorCode = toneOnToneColorCode;
    }

    public int getLeatherEngravedColorCode() {
        return leatherEngravedColorCode;
    }

    public void setLeatherEngravedColorCode(int leatherEngravedColorCode) {
        this.leatherEngravedColorCode = leatherEngravedColorCode;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public StickerImageVo() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.flipType == null ? -1 : this.flipType.ordinal());
        dest.writeInt(this.effectType == null ? -1 : this.effectType.ordinal());
        dest.writeByte(this.isWhiteRemove ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isBlackRemove ? (byte) 1 : (byte) 0);
        dest.writeInt(this.singleColorCode);
        dest.writeInt(this.embroideryColorCode);
        dest.writeInt(this.opacity);
        dest.writeString(this.filePath);
        dest.writeInt(this.toneOnToneColorCode);
        dest.writeInt(this.leatherEngravedColorCode);
    }

    protected StickerImageVo(Parcel in) {
        int tmpFlipType = in.readInt();
        this.flipType = tmpFlipType == -1 ? null : FlipType.values()[tmpFlipType];
        int tmpEffectType = in.readInt();
        this.effectType = tmpEffectType == -1 ? null : EffectTypes.values()[tmpEffectType];
        this.isWhiteRemove = in.readByte() != 0;
        this.isBlackRemove = in.readByte() != 0;
        this.singleColorCode = in.readInt();
        this.embroideryColorCode = in.readInt();
        this.opacity = in.readInt();
        this.filePath = in.readString();
        this.toneOnToneColorCode = in.readInt();
        this.leatherEngravedColorCode = in.readInt();
    }

    public static final Creator<StickerImageVo> CREATOR = new Creator<StickerImageVo>() {
        @Override
        public StickerImageVo createFromParcel(Parcel source) {
            return new StickerImageVo(source);
        }

        @Override
        public StickerImageVo[] newArray(int size) {
            return new StickerImageVo[size];
        }
    };
}
