package com.ob.vmc.vmcproduct.communicator;

/**
 * Interface called when any filter type is clicked
 */
public interface OnFilterTypeClick
{
    /**
     * Method called when user clicks on any filter type
     * @param position int position of the filter type
     * @param itemType int TYPE of filter clicked
     */
//    void onFilterTypeClick(int position, int itemType);
    void onFilterTypeClick(int position);
}
