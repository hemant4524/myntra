package com.ob.vmc.vmcproduct.model.httpmodel;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

import java.util.List;

/**
 * Created by khyati5403 on 10/11/2016.
 */

public class SuppliersVO extends BaseVo {
    /**
     * data : {"suppliers":[{"id":"10","supplierName":"VANTAGE","supplierType":"Supplier","productCount":87},{"id":"107","supplierName":"Advantage Line","supplierType":"Supplier","productCount":825},{"id":"108","supplierName":"Pro Golf Premiums","supplierType":"Supplier","productCount":988},{"id":"109","supplierName":"Hartwell Classic Apparel","supplierType":"Supplier","productCount":0},{"id":"111","supplierName":"Bodek & Rhodes","supplierType":"Supplier","productCount":1677},{"id":"12","supplierName":"S&S Activewear","supplierType":"Supplier","productCount":2},{"id":"15","supplierName":"TRADE NET PUBLISHING","supplierType":"Supplier","productCount":6163},{"id":"309","supplierName":"Hit Promotional Products","supplierType":"Supplier","productCount":1622},{"id":"394","supplierName":"Bel Promo","supplierType":"Supplier","productCount":1535},{"id":"438","supplierName":"Bag Makers Inc.","supplierType":"Supplier","productCount":207},{"id":"441","supplierName":"Gary Line","supplierType":"Supplier","productCount":591},{"id":"442","supplierName":"Molenaar, LLC","supplierType":"Supplier","productCount":268},{"id":"447","supplierName":"SanMar","supplierType":"Supplier","productCount":300},{"id":"448","supplierName":"Norwood BIC","supplierType":"Supplier","productCount":3358},{"id":"449","supplierName":"Gemline","supplierType":"Supplier","productCount":1373},{"id":"450","supplierName":"ALPI International","supplierType":"Supplier","productCount":709},{"id":"454","supplierName":"Showdown Displays","supplierType":"Supplier","productCount":2628},{"id":"459","supplierName":"Hub Pen Company","supplierType":"Supplier","productCount":167},{"id":"460","supplierName":"Ariel Premium Supply","supplierType":"Supplier","productCount":1235},{"id":"461","supplierName":"PrimeLine","supplierType":"Supplier","productCount":1010},{"id":"467","supplierName":"Digispec","supplierType":"Supplier","productCount":0},{"id":"5","supplierName":"Aakronline","supplierType":"Supplier","productCount":1203},{"id":"584","supplierName":"Gill Line / Gill Studios","supplierType":"Supplier","productCount":5709},{"id":"609","supplierName":"Sanford","supplierType":"Supplier","productCount":195},{"id":"619","supplierName":"Dixieland Emblematics","supplierType":"Supplier","productCount":90},{"id":"628","supplierName":"Snugz/USA Inc","supplierType":"Supplier","productCount":571}]}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo {
        @SerializedName("suppliers")
        private List<SuppliersVo> suppliers;

        public List<SuppliersVo> getSuppliers() {
            return suppliers;
        }

        public void setSuppliers(List<SuppliersVo> suppliers) {
            this.suppliers = suppliers;
        }

        public static class SuppliersVo {
            /**
             * id : 10
             * supplierName : VANTAGE
             * supplierType : Supplier
             * productCount : 87
             */

            @SerializedName("id")
            private String id;
            @SerializedName("supplierName")
            private String supplierName;
            @SerializedName("supplierType")
            private String supplierType;
            @SerializedName("productCount")
            private int productCount;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getSupplierName() {
                return supplierName;
            }

            public void setSupplierName(String supplierName) {
                this.supplierName = supplierName;
            }

            public String getSupplierType() {
                return supplierType;
            }

            public void setSupplierType(String supplierType) {
                this.supplierType = supplierType;
            }

            public int getProductCount() {
                return productCount;
            }

            public void setProductCount(int productCount) {
                this.productCount = productCount;
            }
        }
    }

    /* *
     data:{"suppliers":[{"id":"10","supplierName":"VANTAGE","supplierType":"Supplier","productCount":87}
     * */




   /* *//**
     * data : {"suppliers":[{"id":"438","supplierName":"Bag Makers Inc.","productCount":52},{"id":"438","supplierName":"438","productCount":52}]}
     *//*

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo {
        @SerializedName("suppliers")
        private List<SuppliersVo> suppliers;

        public List<SuppliersVo> getSuppliers() {
            return suppliers;
        }

        public void setSuppliers(List<SuppliersVo> suppliers) {
            this.suppliers = suppliers;
        }

        public static class SuppliersVo {
            *//**
     * id : 438
     * supplierName : Bag Makers Inc.
     * productCount : 52
     *//*

            @SerializedName("id")
            private String id;
            @SerializedName("supplierName")
            private String supplierName;
            @SerializedName("productCount")
            private int productCount;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getSupplierName() {
                return supplierName;
            }

            public void setSupplierName(String supplierName) {
                this.supplierName = supplierName;
            }

            public int getProductCount() {
                return productCount;
            }

            public void setProductCount(int productCount) {
                this.productCount = productCount;
            }
        }
    }*/


}
