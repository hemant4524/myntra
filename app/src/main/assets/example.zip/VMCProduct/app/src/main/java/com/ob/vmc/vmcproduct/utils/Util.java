package com.ob.vmc.vmcproduct.utils;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.andoblib.log.CustomLogHandler;
import com.andoblib.util.AppSetting;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.backends.pipeline.PipelineDraweeControllerBuilder;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.ob.ecommercelibrary.common.KeyConstant;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {

    /**
     * Method to check if current API level is 23 and above or not
     *
     * @return true if current API level is 23 or above, false otherwise
     */
    public static boolean atLeast23() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;
    }

    /**
     * Method to find if current API level is greater or equal to Lollipop(21)
     *
     * @return true if current API level is grater or equal to Lollipop(21), false otherwise
     */
    public static boolean atLeast21() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    /**
     * Method to check if current API level is 16 and above or not
     *
     * @return true if current API level is 16 or above, false otherwise
     */
    public static boolean atLeast16() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
    }

    /**
     * text validate
     *
     * @param
     * @return true when matches regular expression
     */
    public static boolean isValidString(String stringvalue, String pattern) {
        try {
            Pattern patt = Pattern.compile(pattern);
            Matcher matcher = patt.matcher(stringvalue);
            //Log.d("signup", "" + matcher.matches());
            return matcher.matches();
        } catch (RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Method use for set URL Default Parameters for GET API
     *
     * @return ArrayList of NameValuePair values _locale=en_us,_format=json
     */
  /*  public static
    @NonNull
    ArrayList<NameValuePair> getPostDefaultParams() {
        ArrayList<NameValuePair> postData = new ArrayList<>();
        postData.add(new NameValuePair(Constants.CURRENT_LOCALE_KEY, Constants.CURRENT_LOCALE_VALUE));
        postData.add(new NameValuePair(Constants.RESPONSE_FORMAT_KEY, Constants.RESPONSE_FORMAT_VALUE));
        return postData;
    }*/


    /**
     * Method use for set URL Default Parameters for GET API
     *
     * @return ?_locale=en_us&_format=json
     */
  /*  public static
    @NonNull
    String getGETDefaultParams() {
        return "?" + Constants.CURRENT_LOCALE_KEY + "=" + Constants.CURRENT_LOCALE_VALUE + "&" + Constants.RESPONSE_FORMAT_KEY + "=" + Constants.RESPONSE_FORMAT_VALUE;
    }*/


    /**
     * Show Alert Error dialog Box
     *
     * @param context      reference
     * @param messageResId resourceId
     * @param title        Alert dialog Title Message
     */

    public static AlertDialog.Builder showErrorDialog(Context context, int messageResId, String title) {
        return showErrorDialog(context, context.getString(messageResId), title);
    }


    /**
     * Show Alert Error dialog Box
     *
     * @param context      reference
     * @param messageResId resourceId
     * @param titleResId   resourceId
     */
    public static AlertDialog.Builder showErrorDialog(Context context, int messageResId, int titleResId) {
        return showErrorDialog(context, context.getString(messageResId), context.getString(titleResId));
    }

    /**
     * Show Alert Error dialog Box
     *
     * @param context    reference
     * @param message    error message
     * @param titleResId resourceId
     */
    public static AlertDialog.Builder showErrorDialog(Context context, String message, int titleResId) {
        return showErrorDialog(context, message, context.getString(titleResId));
    }


    /**
     * Show Alert Error dialog Box
     *
     * @param context reference
     * @param message error message
     * @param title   error title
     */
    public static AlertDialog.Builder showErrorDialog(Context context, String message, String title) {
        AlertDialog.Builder dia = new AlertDialog.Builder(context);
        dia.setTitle(title);
        dia.setMessage(message);
        dia.setPositiveButton(android.R.string.ok, null);
        dia.show();
        return dia;
    }


    /**
     * Show Alert dialog Box
     *
     * @param context reference
     * @param message error message
     * @param title   error title
     */
    public static AlertDialog.Builder showAlertDialog(Context context, String message, String title, DialogInterface.OnClickListener okClickListener) {
        return showAlertDialog(context, message, title, true, okClickListener);
    }

    /**
     * Show Alert dialog Box
     *
     * @param context reference
     * @param message error message
     * @param title   error title
     */
    public static AlertDialog.Builder showAlertDialog(Context context, String message, String title, boolean cancelable, DialogInterface.OnClickListener okClickListener) {
        AlertDialog.Builder dia = new AlertDialog.Builder(context);
        dia.setTitle(title);
        dia.setMessage(message);
        dia.setCancelable(cancelable);
        dia.setPositiveButton(android.R.string.ok, okClickListener);
        dia.show();
        return dia;
    }


    /**
     * Get Color from resourceid
     */
    public static int getColor(Resources resources, int colorResId) {
        return getColor(resources, colorResId, null);
    }


    /**
     * Get Color from resourceid
     */
    @TargetApi(Build.VERSION_CODES.M)
    public static int getColor(Resources resources, int colorResId, Resources.Theme theme) {
        if (atLeast23()) {
            return resources.getColor(colorResId, theme);
        } else {
            //noinspection deprecation
            return resources.getColor(colorResId);
        }
    }

    public static void showPermissionRequestDialog(@NonNull final Activity pActivity, @NonNull final String pPermission, final int pRequestCode, int pTitleResId, int pMessageResId) {
        showPermissionRequestDialog(pActivity, pPermission, pRequestCode, pActivity.getString(pTitleResId), pActivity.getString(pMessageResId));
    }

    public static void showPermissionRequestDialog(@NonNull final Activity pActivity, @NonNull final String pPermission, final int pRequestCode, String pTitle, String pMessage) {
        // Show an explanation to the user *asynchronously* -- don't block
        // this thread waiting for the user's response! After the user
        // sees the explanation, try again to request the permission.
        AlertDialog.Builder dia = new AlertDialog.Builder(pActivity);
        dia.setMessage(pMessage);
        dia.setTitle(pTitle);
        dia.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ActivityCompat.requestPermissions(pActivity, new String[]{pPermission}, pRequestCode);
            }
        });

        dia.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
//                pActivity.finish();
            }
        });
        dia.show();
    }

    public static void requestForPermission(@NonNull Activity pActivity, @NonNull String pPermission, int pRequestCode) {
        ActivityCompat.requestPermissions(pActivity, new String[]{pPermission}, pRequestCode);
    }

    public static Drawable getDrawable(Context pContext, int drawableResId) {
        Drawable d;
        if (atLeast21()) {
            d = pContext.getResources().getDrawable(drawableResId, pContext.getTheme());
        } else {
            //noinspection deprecation
            d = pContext.getResources().getDrawable(drawableResId);
        }
        return d;
    }

    public static int getColor(Context pContext, int colorResId) {
        int color;
        if (atLeast23()) {
            color = pContext.getResources().getColor(colorResId, pContext.getTheme());
        } else {
            //noinspection deprecation
            color = pContext.getResources().getColor(colorResId);
        }
        return color;
    }

   /* public static void logout(final FragmentActivity pContext) {
        AlertDialog.Builder logoutDialog = new AlertDialog.Builder(pContext);
        logoutDialog.setTitle(R.string.txt_logoutTitle);
        logoutDialog.setMessage(R.string.txt_logoutMessage);
        logoutDialog.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO : change api url
                CommonUtil.showProgressDialog(pContext, null, null, false, null, -1, pContext.getSupportFragmentManager());
                String logoutUrl = ECommerceApp.getBaseURL() + WSConstants.WS_LOGOUT + getLogoutGETParams(pContext, false);
                FormHttpCaller caller = new FormHttpCaller(pContext, logoutUrl, getLogoutParams(pContext, true), WSConstants.REQUEST_CODE_CALL_GET_LOGOUT, new HttpResponseHandler() {
                    @Override
                    public void onResponse(ArtworkBaseVo pResponseData, CustomException p_e, int pRequestCode) {
                        CommonUtil.dismissProgressDialog();
                        if (p_e == null) {
                            if (pResponseData != null && (pResponseData.getStatus_code() == WSConstants.STATUS_OK || pResponseData.getStatus().equalsIgnoreCase("OK"))) {
                                LibUtils.sendLogout(pContext);
                                pContext.startActivity(new Intent(pContext, LoginActivity.class));
                            }
                        } else {
                            showErrorDialog(pContext, p_e.getMessage(), R.string.title_error);
                        }
                    }
                }, false);
                caller.execute();
            }
        });

        logoutDialog.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        logoutDialog.show();
    }

    private static
    @Nullable
    ArrayList<NameValuePair> getLogoutParams(Context pContext, boolean isPOST) {
        if (!isPOST) {
            return null;
        } else {
            ArrayList<NameValuePair> postParams = getPostDefaultParams();

            String accToken = AppSetting.getString(pContext, KeyConstant.PREF_ACCESS_TOKEN, null);
            String refToken = AppSetting.getString(pContext, KeyConstant.PREF_REFRESH_TOKEN, null);
            if (accToken != null && refToken != null) {
                postParams.add(new NameValuePair(WSConstants.ACCESS_TOKEN_KEY, accToken));
                postParams.add(new NameValuePair(WSConstants.REFRESH_TOKEN_KEY, refToken));
                postParams.add(new NameValuePair(WSConstants.REFERENCE_ACCESS_TOKEN_KEY, accToken));
            }
            return postParams;
        }
    }*/


    /**
     * Get Logout Paramas
     */

   /* private static
    @NonNull
    String getLogoutGETParams(Context pContext, boolean isGET) {
        if (!isGET) {
            return "";
        } else {
            StringBuilder sb = new StringBuilder();

            String accToken = AppSetting.getString(pContext, KeyConstant.PREF_ACCESS_TOKEN, null);
            String refToken = AppSetting.getString(pContext, KeyConstant.PREF_REFRESH_TOKEN, null);
            if (accToken != null && refToken != null) {
                sb.append("?").append(WSConstants.ACCESS_TOKEN_KEY).append("=").append(accToken).append("&");
                sb.append(WSConstants.REFRESH_TOKEN_KEY).append("=").append(refToken).append("&");
                sb.append(WSConstants.REFERENCE_ACCESS_TOKEN_KEY).append("=").append(accToken);
            }

            return sb.toString();
        }
    }*/

    public static void setBackground(View view, Drawable drawable) {
        if (atLeast16())
            view.setBackground(drawable);
        else
            view.setBackgroundDrawable(drawable);
    }

    /**
     * Get a file path from a Uri. This will get the the path for Storage Access Framework Documents, as well as the _data field for the MediaStore and other file-based ContentProviders.
     *
     * @param context The context.
     * @param uri     The Uri to query.
     */
    @Nullable
    @SuppressLint("NewApi")
    public static String getStringPathFromUri(final Uri uri, final Context context) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]
                        {split[1]};

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    @Nullable
    public static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection =
                {column};

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    /**
     * This method is used to check whether the given file path is valid image or not.
     *
     * @param pImagePath The full file path of the image.
     * @return pImagePath true if valid else false.
     */
    public static boolean isValidImage(final String pImagePath) {
        boolean isValid = false;

        if (pImagePath == null) {
            return false;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        BitmapFactory.decodeFile(pImagePath, options);

        CustomLogHandler.printDebug("isValidImage", "====Image Height====" + options.outHeight);
        CustomLogHandler.printDebug("isValidImage", "====Image Width====" + options.outWidth);

        if (options.outHeight > 0 && options.outWidth > 0) {
            isValid = true;
        }
        return isValid;
    }

    /**
     * Method to check if the selected file can be uploaded or not
     *
     * @return true if attachment can be uploaded, false otherwise.
     */
    public static boolean checkAttachment(String pAttachmentPath) {
        if (pAttachmentPath == null) {
            return false;
        }
        File pAttachment = new File(pAttachmentPath);
        return checkAttachment(pAttachment);
    }

    /**
     * Method to check if the selected file can be uploaded or not
     *
     * @return true if attachment can be uploaded, false otherwise.
     */
    public static boolean checkAttachment(File pAttachment) {
        return pAttachment != null && pAttachment.exists() && pAttachment.length() > 0;
    }


    /**
     * Check uses login or not
     *
     * @return true if access token and user id found otherwise false.
     */
    public static boolean checkUserAsLogin(Context context) {

        return AppSetting.getString(context, KeyConstant.PREF_ACCESS_TOKEN, null) != null && AppSetting.getString(context, KeyConstant.PREF_USER_ID, null) != null;
    }


    /**
     * Load Image Using Fresco Liberary
     *
     * @param imageView        Imageview
     * @param imageUrl         Imgae Url
     * @param imageProgressBar ProgressBar
     */
    public static void loadImageByFresco(@NonNull SimpleDraweeView imageView, String imageUrl, @Nullable ProgressBar imageProgressBar) {
        loadImageByFrescoResize(imageView, imageUrl, imageProgressBar, 0, 0, false);
    }

    /**
     * Load Image with Blur Using Fresco Liberary
     *
     * @param imageView        Imageview
     * @param imageUrl         Imgae Url
     * @param imageProgressBar ProgressBar
     */
    public static void loadImageByFrescoWithBlur(@NonNull SimpleDraweeView imageView, String imageUrl, @Nullable ProgressBar imageProgressBar) {
        loadImageByFrescoResize(imageView, imageUrl, imageProgressBar, 0, 0, true);
    }

    /**
     * Load Image with Blur Using Fresco Liberary
     *
     * @param imageView        Imageview
     * @param imageUrl         Imgae Url
     * @param imageProgressBar ProgressBar
     * @param height           Image Height
     * @param width            Image Width
     * @param shouldBlur       true for blur image otherwise false
     */
    public static void loadImageByFrescoResize(@NonNull SimpleDraweeView imageView, String imageUrl, @Nullable ProgressBar imageProgressBar, float width, float height, boolean shouldBlur) {
        if (imageUrl == null)
            return;
        if (imageProgressBar != null)
            imageProgressBar.setVisibility(View.VISIBLE);

        PipelineDraweeControllerBuilder pipelineDraweeControllerBuilder = Fresco.newDraweeControllerBuilder();
        pipelineDraweeControllerBuilder.setAutoPlayAnimations(true);
        ImageRequestBuilder requestBuilder = ImageRequestBuilder.newBuilderWithSource(Uri.parse(imageUrl));
        if (width > 0 && height > 0) {
            requestBuilder.setResizeOptions(new ResizeOptions((int) width, (int) height));
        }
        if (imageUrl != null)
            pipelineDraweeControllerBuilder.setImageRequest(requestBuilder.build());

        DraweeController controller = pipelineDraweeControllerBuilder.build();
        imageView.setController(controller);
    }

    public static String capitalization(String prodName) {
        StringBuffer stringbf = new StringBuffer();
        Matcher m = Pattern.compile("([a-z])([a-z]*)",
                Pattern.CASE_INSENSITIVE).matcher(prodName.replace("-", " "));
        while (m.find()) {
            m.appendReplacement(stringbf,
                    m.group(1).toUpperCase() + m.group(2).toLowerCase());
        }
        return m.appendTail(stringbf).toString();
    }

    public static String CopyReadAssets(Context context, String fileName) {
        AssetManager assetManager = context.getAssets();

        InputStream in = null;
        OutputStream out = null;
        File file = new File(context.getFilesDir(), fileName);
        try {
            in = assetManager.open("pdf/" + fileName);
            out = context.openFileOutput(file.getName(), Context.MODE_WORLD_READABLE);

            copyFile(in, out);
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
            return file.toString();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("tag", e.getMessage());
        }

        return null;


    }

    public static void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }


    public static List<NameValuePair> getDefaultHeader(Context context) {
        List<NameValuePair> header=new ArrayList<>();
        header.add(new NameValuePair(WSKeyConstant.KEY_TOKEN,getAccessToken(context)));

        return header;
    }

    public static String getAccessToken(Context pContext) {
        return AppSetting.getString(pContext, KeyConstant.PREF_ACCESS_TOKEN, "");
    }

    public static boolean saveBitmap(Context context, File filePath, Bitmap bitamp) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(filePath);
            bitamp.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
            // PNG is a lossless format, the compression factor (100) is ignored
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
