package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 1/12/2017.
 */

public class LeatherEngravedEffectHandler {

    private Context mContext;

    public LeatherEngravedEffectHandler(Context mContext) {
        this.mContext = mContext;
    }

    public Bitmap executeProcess(Bitmap srcBitmap, int mSelectColor){
        try {
            if (srcBitmap != null) {
                srcBitmap = BitmapProcessing.lighter(srcBitmap, mSelectColor, 0.9f);
//                srcBitmap = BitmapProcessing.gaussian(srcBitmap);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        return  srcBitmap;
    }
}
