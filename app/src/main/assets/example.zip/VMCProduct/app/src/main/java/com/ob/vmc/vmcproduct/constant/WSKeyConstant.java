package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 6/7/2016.
 */

/*List of API Methods field key*/
public class WSKeyConstant {

    /*authorize-token*/
    public static final String KEY_AUTH_CLIENT_ID = "client_id";
    public static final String KEY_AUTH_CLIENT_SECRET = "client_secret";
    public static final String KEY_AUTH_GRANT_TYPE = "grant_type";
    public static final String KEY_AUTH_USERNAME= "userName";
    public static final String KEY_AUTH_PASSWORD = "password";


    public static final String KEY_ACCESS_TOKEN="access_token";

/*get-project-settings*/
    public static final String KEY_LOCALE="locale";
    public static final String KEY_INSTANCE_ID="instance_id";
    public static final String KEY_INSTANCE_TYPE="instance_type";

    public static final String KEY_SUPPLIER_ID = "supplierId";
    public static final String KEY_START = "start";
    public static final String KEY_LIMIT = "limit";
    public static final String KEY_SKU = "sku";
    public static final String KEY_TOKEN = "token";
    public static final String KEY_HEX_COLOR = "hex_color";
    public static final String SIDEIMAGES = "sideimages[]";
    public static final String KEY_SUPPLIER_TYPE = "supplierType";
}
