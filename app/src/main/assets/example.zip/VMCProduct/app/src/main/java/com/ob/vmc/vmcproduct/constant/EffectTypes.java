package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 1/4/2017.
 */

public enum  EffectTypes {

    MULTICOLOR,
    SINGLE_COLOR,
    EMBOSS,
    DEBOSS,
    ENGRAVE,
    SATIN_EACH,
    WOODEN,
    EMBROIDERY,
    SHARPNESS,
    TONE_ON_TONE,
    LEATHER_ENGRAVED


}
