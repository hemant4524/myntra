package com.ob.vmc.vmcproduct;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * Created by khyati5403 on 10/14/2016.
 */

public class ApplicationTest extends ApplicationTestCase<Application> {
    public ApplicationTest() {
        super(Application.class);
    }
}