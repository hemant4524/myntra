package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;
import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;
import com.ob.vmc.vmcproduct.customviews.StickerView;
import com.ob.vmc.vmcproduct.handler.DebossEffectHandler;
import com.ob.vmc.vmcproduct.handler.EmbossEffectHandler;
import com.ob.vmc.vmcproduct.handler.EmbroideryEffectHandler;
import com.ob.vmc.vmcproduct.handler.EngraveEffectHandler;
import com.ob.vmc.vmcproduct.handler.LeatherEngravedEffectHandler;
import com.ob.vmc.vmcproduct.handler.MultiColorEffectHandler;
import com.ob.vmc.vmcproduct.handler.RemoveBlackWhiteHandler;
import com.ob.vmc.vmcproduct.handler.SatinEachEffectHandler;
import com.ob.vmc.vmcproduct.handler.SharpenEffectHandler;
import com.ob.vmc.vmcproduct.handler.SingleColorHandler;
import com.ob.vmc.vmcproduct.handler.ToneOnToneHandler;
import com.ob.vmc.vmcproduct.handler.WoodenEffectHandler;
import com.ob.vmc.vmcproduct.model.appmodel.StickerImageVo;

/**
 * Created by Ishan4452 on 1/5/2017.
 */
public class StickerEffectsTask implements Runnable {


    private static final String TAG = StickerEffectsTask.class.getSimpleName();
    private static final double DEFAULT_SHARPNESS = 0;
    private StickerView mStickerView;
    private Context mContext;

    public StickerEffectsTask(Context context, StickerView pStickerView) {
        mContext = context;
        this.mStickerView = pStickerView;
    }

    @Override
    public void run() {

        StickerImageVo stickerImageVo = mStickerView.getmImageVo();

        String uri = stickerImageVo.getFilePath();
        Bitmap uriBitmap = BitmapFactory.decodeFile(uri);

        boolean isWhiteRemove = stickerImageVo.isWhiteRemove();
        boolean isBlackRemove = stickerImageVo.isBlackRemove();
        FlipType flipType = stickerImageVo.getFlipType();
        EffectTypes effectTypes = stickerImageVo.getEffectType();

        //Remove White/Black
        if (isWhiteRemove || isBlackRemove) {
            uriBitmap = new RemoveBlackWhiteHandler(mContext).setRemovedBlack(isBlackRemove).setRemovedWhite(isWhiteRemove).executeProcess(uriBitmap);
        }

        //Apply FlipType
        if (flipType == FlipType.VERTICAL_HORIZONTAL)
            uriBitmap = BitmapProcessing.flip(uriBitmap, true, true);
        if (flipType == FlipType.HORIZONTAL)
            uriBitmap = BitmapProcessing.flip(uriBitmap, true, false);
        else if (flipType == FlipType.VERTICAL)
            uriBitmap = BitmapProcessing.flip(uriBitmap, false, true);


        //Apply Effects
        if (effectTypes == EffectTypes.EMBOSS) {
            uriBitmap = new EmbossEffectHandler(mContext).executeProcess(uriBitmap, !isWhiteRemove,stickerImageVo.getOpacity());
        } else if (effectTypes == EffectTypes.DEBOSS) {
            uriBitmap = new DebossEffectHandler(mContext).executeProcess(uriBitmap, !isWhiteRemove,stickerImageVo.getOpacity());
        } else if (effectTypes == EffectTypes.EMBROIDERY) {
            uriBitmap = new EmbroideryEffectHandler(mContext).executeProcess(stickerImageVo.getEmbroideryColorCode(), uriBitmap, R.drawable.embroidery_1,!isWhiteRemove);
        } else if (effectTypes == EffectTypes.ENGRAVE) {
            uriBitmap = new EngraveEffectHandler(mContext).executeProcess(uriBitmap);
        } else if (effectTypes == EffectTypes.SATIN_EACH) {
            uriBitmap = new SatinEachEffectHandler(mContext).executeProcess(uriBitmap);
        } else if (effectTypes == EffectTypes.SINGLE_COLOR) {
            uriBitmap = new SingleColorHandler(mContext).executeProcess(uriBitmap, stickerImageVo.getSingleColorCode());
        } else if (effectTypes == EffectTypes.SHARPNESS) {
            uriBitmap = new SharpenEffectHandler(mContext).executeProcess(uriBitmap, DEFAULT_SHARPNESS);
        } else if (effectTypes == EffectTypes.WOODEN) {
            uriBitmap = new WoodenEffectHandler(mContext).executeProcess(uriBitmap, R.drawable.wooden_mask);
        } else if (effectTypes ==EffectTypes.TONE_ON_TONE) {
            uriBitmap = new ToneOnToneHandler(mContext).executeProcess(uriBitmap, stickerImageVo.getToneOnToneColorCode());
        }else if (effectTypes ==EffectTypes.LEATHER_ENGRAVED){
            uriBitmap = new LeatherEngravedEffectHandler(mContext).executeProcess(uriBitmap, stickerImageVo.getLeatherEngravedColorCode());
        }else {
            uriBitmap = new MultiColorEffectHandler(mContext).executeProcess(uriBitmap);
        }

        //Update View Bitmap
        mStickerView.setChangeEffectBitmap(uriBitmap);




    }

    public StickerView getStickerView() {
        return mStickerView;
    }
}
