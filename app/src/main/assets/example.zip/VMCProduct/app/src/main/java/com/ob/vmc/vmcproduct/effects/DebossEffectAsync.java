package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/15/2016.
 */

public class DebossEffectAsync extends AsyncTask<Void, Void, Bitmap> {
    private Uri mUri;
    private Bitmap srcBitmap;
    private Context mContext;
    private DebossEffectAsync.DebossResult mDebossResult;
    private String error;
    private View view;

    public DebossEffectAsync(Context mContext, DebossEffectAsync.DebossResult debossResult, Bitmap bitmap) {
        this.mContext = mContext;
        this.mDebossResult = debossResult;
        this.srcBitmap = bitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;
        /**
         * Get bitmap from URI
         */
        try {
            if (srcBitmap != null) {
                bitmap = BitmapProcessing.doDeboss(srcBitmap, true);
            }
        } catch (Exception e) {
            error = e.getMessage();
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mDebossResult.onDebossEventComplete(bitmap);
        } else {
            mDebossResult.onDebossEventFail(error);
        }
    }

    public interface DebossResult {
        void onDebossEventComplete(Bitmap bitmap);

        void onDebossEventFail(String exceptionMsg);
    }
}