package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 1/5/2017.
 */

public class ToneOnToneEffectAsync extends AsyncTask<Void, Void, Bitmap> {

    private int mColor;
    private Bitmap srcBitmap;
    private Context mContext;
    private ToneOnToneEffectAsync.ToneOnToneResult mToneOnToneResult;
    private String error;
    private String pBitmapPath;

    public ToneOnToneEffectAsync(int mColor, Bitmap srcBitmap, Context mContext, ToneOnToneResult mToneOnToneResult) {
        this.mColor = mColor;
        this.srcBitmap = srcBitmap;
        this.mContext = mContext;
        this.mToneOnToneResult = mToneOnToneResult;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... voids) {
        Bitmap bitmap = null;
//        bitmap = BitmapProcessing.darker(srcBitmap, mColor, 0.9f);
        int color = BitmapProcessing.getDominantColor(srcBitmap);
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if (bitmap != null) {
            mToneOnToneResult.onToneOnToneEventCompleted(bitmap);
        } else {
            mToneOnToneResult.onToneOnTonEventFail(error);
        }
    }

    public interface ToneOnToneResult {

        void onToneOnToneEventCompleted(Bitmap bitmap);

        void onToneOnTonEventFail(String str);
    }
}
