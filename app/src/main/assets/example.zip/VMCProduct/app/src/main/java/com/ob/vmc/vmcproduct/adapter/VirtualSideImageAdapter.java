package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.facebook.drawee.view.SimpleDraweeView;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.model.appmodel.VirtualFileSideVo;
import com.ob.vmc.vmcproduct.utils.Util;

import java.util.List;

/**
 * Created by Ishan4452 on 12/14/2016.
 */
public class VirtualSideImageAdapter extends RecyclerView.Adapter<VirtualSideImageAdapter.SideImageViewHolder> {

    private Context mContext;
    private List<VirtualFileSideVo> mVirtualFileSideVos;

    public VirtualSideImageAdapter(Context context, List<VirtualFileSideVo> virtualFileSideVos) {
        mContext = context;
        mVirtualFileSideVos = virtualFileSideVos;
    }

    @Override
    public SideImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_virtual_side_item, parent, false);
        SideImageViewHolder viewHolder = new SideImageViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(SideImageViewHolder holder, int position) {
        Util.loadImageByFresco(holder.ivSideImage, "file://"+mVirtualFileSideVos.get(position).getSidePath(), null);

//        Toast.makeText(mContext, "file://"+mVirtualFileSideVos.get(position).getSidePath(), Toast.LENGTH_SHORT).show();


    }

    @Override
    public int getItemCount() {
        return mVirtualFileSideVos.size();
    }

    public class SideImageViewHolder extends RecyclerView.ViewHolder {
        private SimpleDraweeView ivSideImage;

        public SideImageViewHolder(View itemView) {
            super(itemView);

            ivSideImage = (SimpleDraweeView) itemView.findViewById(R.id.avsi_ivSideImage);
        }
    }
}
