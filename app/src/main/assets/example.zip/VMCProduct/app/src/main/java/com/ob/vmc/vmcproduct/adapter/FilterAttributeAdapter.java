package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.communicator.OnFilterAttributeClickListener;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by khyati5403 on 10/20/2016.
 */

public class FilterAttributeAdapter extends RecyclerView.Adapter<FilterAttributeAdapter.FilterAttributeViewHolder> {

    private final LayoutInflater mInflater;
    private List<String> selectedSupllierList;
    private OnFilterAttributeClickListener mListener;
    private List<SuppliersVO.DataVo.SuppliersVo> mListVo;
    private final SparseBooleanArray mSelected;

    public FilterAttributeAdapter(Context context, List<SuppliersVO.DataVo.SuppliersVo> list, OnFilterAttributeClickListener clickListener, String selected) {
        this.mInflater = LayoutInflater.from(context);
        mListener = clickListener;
        mListVo = list;
        mSelected = new SparseBooleanArray();
        if (selected != null && selected.length() > 0) {
            String[] selectedSupllier = selected.split(",");
            selectedSupllierList = new ArrayList<>(Arrays.asList(selectedSupllier));
        } else {
            selectedSupllierList = new ArrayList<>();
        }
    }

    @Override
    public FilterAttributeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.filter_right_row, parent, false);

        return new FilterAttributeViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return mListVo.size();
    }

    @Override
    public void onBindViewHolder(final FilterAttributeViewHolder holder, final int position) {
        holder.tvItemName.setText(mListVo.get(position).getSupplierName());
        holder.tvItemName.append("(" +mListVo.get(position).getProductCount()
                + ")");
        holder.cbItemSelected.setTag(position);
        holder.cbItemSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                ((ViewGroup) buttonView.getParent()).setSelected(isChecked);
                int pos = (int) buttonView.getTag();
                mSelected.put(pos, isChecked);
                if (isChecked) {
                    selectedSupllierList.add(mListVo.get(position).getId());
                }else
                {
                    selectedSupllierList.remove(mListVo.get(position).getId());
                }
                String stringsP=TextUtils.join(",", selectedSupllierList);
                ArrayList<SuppliersVO.DataVo.SuppliersVo> suppliers=new ArrayList<SuppliersVO.DataVo.SuppliersVo>();

                mListener.onCommonItemSelect(getAllCommonSelected(), stringsP);

            }

        });

        boolean isSupplierSelected = selectedSupllierList.contains(mListVo.get(position).getId());
        holder.cbItemSelected.setChecked(isSupplierSelected);

        holder.parent.setTag(holder.cbItemSelected);
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CompoundButton buttonView = (CompoundButton) v.getTag();
                v.setSelected(!buttonView.isChecked());
                buttonView.setChecked(!buttonView.isChecked());
            }
        });


    }

    private ArrayList<SuppliersVO.DataVo.SuppliersVo> getAllCommonSelected() {
        ArrayList<SuppliersVO.DataVo.SuppliersVo> list = new ArrayList<>();
        for (int i = 0; i < mSelected.size(); i++) {
            if (mSelected.valueAt(i)) {
                list.add(mListVo.get(mSelected.keyAt(i)));
            }
        }
        return list;
    }

    public void clearSelectedPos() {
        selectedSupllierList.clear();
    }

    public class FilterAttributeViewHolder extends RecyclerView.ViewHolder {

        View parent;
        TextView tvItemName;
        CheckBox cbItemSelected;

        public FilterAttributeViewHolder(View itemView) {
            super(itemView);
            parent = itemView;
            tvItemName = (TextView) itemView.findViewById(R.id.frr_tvSupplierName);
            cbItemSelected = (CheckBox) itemView.findViewById(R.id.frr_cbItemSelect);
        }
    }
}
