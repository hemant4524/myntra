package com.ob.vmc.vmcproduct.model.httpmodel;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

/**
 * Created by Ishan4452 on 11/11/2016.
 */

public class LoginVo extends BaseVo {


    /**
     * data : {"token":"GZH3GInsjx6CebzXh2epLpXlNnJVS4OdIK5xglj1nvXi1e-W5NtgP3","virtual":1,"user":{"userId":1,"email":"admin@example.com","supplierId":"51","supplierType":"Group"}}
     */

    @SerializedName("data")
    private LoginDataVo data;

    public LoginDataVo getData() {
        return data;
    }

    public void setData(LoginDataVo data) {
        this.data = data;
    }

    public static class LoginDataVo {
        /**
         * token : GZH3GInsjx6CebzXh2epLpXlNnJVS4OdIK5xglj1nvXi1e-W5NtgP3
         * virtual : 1
         * user : {"userId":1,"email":"admin@example.com","supplierId":"51","supplierType":"Group"}
         */

        @SerializedName("token")
        private String token;
        @SerializedName("virtual")
        private int virtual;
        @SerializedName("user")
        private LoginUserVo user;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public int getVirtual() {
            return virtual;
        }

        public void setVirtual(int virtual) {
            this.virtual = virtual;
        }

        public LoginUserVo getUser() {
            return user;
        }

        public void setUser(LoginUserVo user) {
            this.user = user;
        }

        public static class LoginUserVo {
            /**
             * userId : 1
             * email : admin@example.com
             * supplierId : 51
             * supplierType : Group
             */

            @SerializedName("userId")
            private int userId;
            @SerializedName("email")
            private String email;
            @SerializedName("supplierId")
            private String supplierId;
            @SerializedName("supplierType")
            private String supplierType;

            public int getUserId() {
                return userId;
            }

            public void setUserId(int userId) {
                this.userId = userId;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getSupplierId() {
                return supplierId;
            }

            public void setSupplierId(String supplierId) {
                this.supplierId = supplierId;
            }

            public String getSupplierType() {
                return supplierType;
            }

            public void setSupplierType(String supplierType) {
                this.supplierType = supplierType;
            }
        }
    }
}
