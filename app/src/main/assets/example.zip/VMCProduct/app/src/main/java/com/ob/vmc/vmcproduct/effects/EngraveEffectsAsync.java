package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;

import com.andoblib.util.CommonUtil;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

public class EngraveEffectsAsync extends AsyncTask<Void, Void, Bitmap> {

    private Uri mUri;
    private Bitmap srcBitmap;
    private Context mContext;
    private EngraveEventResult mEngraveEventResult;
    private String error;
    private View view;

    public EngraveEffectsAsync(Context mContext, EngraveEventResult engraveEffectsAsync, Bitmap bitmap) {
        this.mContext = mContext;
        this.mEngraveEventResult = engraveEffectsAsync;
        this.srcBitmap = bitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;

            /**
             * Get bitmap from URI
             */
            try {
                if (srcBitmap != null) {
                    bitmap = BitmapProcessing.doEngrave(srcBitmap);
                }
            } catch (Exception e) {
                error = e.getMessage();
                e.printStackTrace();
            }


        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mEngraveEventResult.onEngraveEventComplete(bitmap);
        } else {
            mEngraveEventResult.onEngraveEventFail(error);
        }
    }

    public interface EngraveEventResult {
        void onEngraveEventComplete(Bitmap bitmap);

        void onEngraveEventFail(String exceptionMsg);
    }


}