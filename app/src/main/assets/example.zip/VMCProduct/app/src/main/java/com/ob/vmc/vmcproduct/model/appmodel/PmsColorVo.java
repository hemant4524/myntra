package com.ob.vmc.vmcproduct.model.appmodel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.ob.ecommercelibrary.vo.BaseVo;

import java.util.List;

/**
 * Created by khyati5403 on 12/13/2016.
 */

public class PmsColorVo extends BaseVo implements Parcelable {


    /**
     * data : {"count":20,"pmscolor":[{"pms":"white","hex":"FFFFFF"},{"pms":"black","hex":"000000"},{"pms":"7527","hex":"D6D2C4"},{"pms":"Cool Gray 10","hex":"63666A"},{"pms":"123","hex":"FFC72C"},{"pms":"166","hex":"E35205"},{"pms":"186","hex":"C8102E"},{"pms":"202","hex":"862633"},{"pms":"259","hex":"6D2077"},{"pms":"286 C","hex":"0033A0"},{"pms":"289 C","hex":"0C2340"},{"pms":"307 C","hex":"006BA6"},{"pms":"343 C","hex":"115740"},{"pms":"348 C","hex":"00843D"},{"pms":"3278 C","hex":"009B77"},{"pms":"476 C","hex":"4E3629"},{"pms":"872 C","hex":"85714D"},{"pms":"877 C","hex":"8A8D8F"},{"pms":"189 C","hex":"F8A3BC"},{"pms":"806 C","hex":"FF3EB5"}]}
     */

    @SerializedName("data")
    private DataVo data;

    public DataVo getData() {
        return data;
    }

    public void setData(DataVo data) {
        this.data = data;
    }

    public static class DataVo implements Parcelable {
        /**
         * count : 20
         * pmscolor : [{"pms":"white","hex":"FFFFFF"},{"pms":"black","hex":"000000"},{"pms":"7527","hex":"D6D2C4"},{"pms":"Cool Gray 10","hex":"63666A"},{"pms":"123","hex":"FFC72C"},{"pms":"166","hex":"E35205"},{"pms":"186","hex":"C8102E"},{"pms":"202","hex":"862633"},{"pms":"259","hex":"6D2077"},{"pms":"286 C","hex":"0033A0"},{"pms":"289 C","hex":"0C2340"},{"pms":"307 C","hex":"006BA6"},{"pms":"343 C","hex":"115740"},{"pms":"348 C","hex":"00843D"},{"pms":"3278 C","hex":"009B77"},{"pms":"476 C","hex":"4E3629"},{"pms":"872 C","hex":"85714D"},{"pms":"877 C","hex":"8A8D8F"},{"pms":"189 C","hex":"F8A3BC"},{"pms":"806 C","hex":"FF3EB5"}]
         */

        @SerializedName("count")
        private int count;
        @SerializedName("pmscolor")
        private List<PmshexcolorVo> pmscolor;

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public List<PmshexcolorVo> getPmscolor() {
            return pmscolor;
        }

        public void setPmscolor(List<PmshexcolorVo> pmscolor) {
            this.pmscolor = pmscolor;
        }


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.count);
            dest.writeTypedList(this.pmscolor);
        }

        public DataVo() {
        }

        protected DataVo(Parcel in) {
            this.count = in.readInt();
            this.pmscolor = in.createTypedArrayList(PmshexcolorVo.CREATOR);
        }

        public static final Creator<DataVo> CREATOR = new Creator<DataVo>() {
            @Override
            public DataVo createFromParcel(Parcel source) {
                return new DataVo(source);
            }

            @Override
            public DataVo[] newArray(int size) {
                return new DataVo[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, flags);
    }

    public PmsColorVo() {
    }

    protected PmsColorVo(Parcel in) {
        this.data = in.readParcelable(DataVo.class.getClassLoader());
    }

    public static final Parcelable.Creator<PmsColorVo> CREATOR = new Parcelable.Creator<PmsColorVo>() {
        @Override
        public PmsColorVo createFromParcel(Parcel source) {
            return new PmsColorVo(source);
        }

        @Override
        public PmsColorVo[] newArray(int size) {
            return new PmsColorVo[size];
        }
    };
}
