package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.EffectTypes;
import com.ob.vmc.vmcproduct.constant.FlipType;
import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;
import com.ob.vmc.vmcproduct.customviews.BubbleTextView;
import com.ob.vmc.vmcproduct.handler.DebossEffectHandler;
import com.ob.vmc.vmcproduct.handler.EmbossEffectHandler;
import com.ob.vmc.vmcproduct.handler.EmbroideryEffectHandler;
import com.ob.vmc.vmcproduct.handler.EngraveEffectHandler;
import com.ob.vmc.vmcproduct.handler.LeatherEngravedEffectHandler;
import com.ob.vmc.vmcproduct.handler.SatinEachEffectHandler;
import com.ob.vmc.vmcproduct.handler.SharpenEffectHandler;
import com.ob.vmc.vmcproduct.handler.ToneOnToneHandler;
import com.ob.vmc.vmcproduct.handler.WoodenEffectHandler;
import com.ob.vmc.vmcproduct.model.appmodel.BubbleTextVo;

/**
 * Created by Ishan4452 on 1/5/2017.
 */
public class BubbleEffectsTask implements Runnable {


    private static final String TAG = BubbleEffectsTask.class.getSimpleName();
    private static final double DEFAULT_SHARPNESS = 0;
    //Font size Default 16sp
    private final float mDefultSize = 12;
    private BubbleTextView mBubbleTextView;
    private Context mContext;
    private int mBWidth = 150;
    private int mBHeight = 75;


    public BubbleEffectsTask(Context context, BubbleTextView pStickerView) {
        mContext = context;
        this.mBubbleTextView = pStickerView;
    }

    @Override
    public void run() {

        BubbleTextVo bubbleTextVo = mBubbleTextView.getmFontVo();

        String text = bubbleTextVo.getLabelText();
        TextPaint fontPaint = mBubbleTextView.getmFontPaint();


        Rect bounds = new Rect();
        fontPaint.getTextBounds(text, 0, text.length(), bounds);

        int boundWidth = bounds.width()+50;
        int boundHeight = bounds.height()+50;


        Bitmap bitmapBack = Bitmap.createBitmap(boundWidth, boundHeight, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmapBack);

        FlipType flipType = bubbleTextVo.getFlipType();
        EffectTypes effectTypes = bubbleTextVo.getEffectType();
        if (effectTypes == EffectTypes.SINGLE_COLOR) {
            fontPaint.setColor(bubbleTextVo.getSingleColorCode());
        } else {
            fontPaint.setColor(bubbleTextVo.getFontColorCode());
        }

        if (TextUtils.isEmpty(text)) {
            text = "Default Text";
        }

        Paint.FontMetrics fm = fontPaint.getFontMetrics();
        float baseline = fm.descent - fm.ascent;


        float top = boundHeight / 2;

        //Based on the bottom line began to draw
        float lineCount = (text.split("\n").length) / 2;
        top -= (baseline - fm.leading) * lineCount;

        int xPos = (boundWidth / 2);


        int curveDegree=bubbleTextVo.getCurveDegree();
        if (curveDegree==0) {
                     canvas.drawText(text, xPos, top + fm.descent, fontPaint);
        }else
        {
            int startAngle;
            int aCurvingAngle = curveDegree + 6;
            if (curveDegree >= 360) {
                aCurvingAngle = 359;
            } else if (curveDegree <= -360) {
                aCurvingAngle = -359;
            }

            float lineWidth = fontPaint.measureText(text) + (((float) (text.length() - 1)));

            float diameter = (float) (((double) ((360.0f * lineWidth) / ((float) Math.abs(aCurvingAngle)))) / 3.141592653589793d);
           float textOffsetX = 0;

            float textOffsetY = boundWidth/2;

            float left = ((float) textOffsetX) + ((boundWidth  - diameter) / 2.0f);
            top = (float) textOffsetY;
            if (aCurvingAngle > 0) {
                top -= fm.ascent;
                startAngle = 270;
            } else {
                top += ((float)boundHeight  - diameter) - fm.descent;

                startAngle = 90;
            }

            Path mArc=new Path();
            RectF rectf = new RectF(left, top, left + diameter, top + diameter);
            mArc.addArc(rectf, (float) (startAngle - (aCurvingAngle / 2)), (float) aCurvingAngle);
            bitmapBack = Bitmap.createBitmap(boundWidth, boundWidth, Bitmap.Config.ARGB_8888);
            canvas.setBitmap(bitmapBack);

            canvas.drawTextOnPath(text, mArc,  0.0f,0.0f, fontPaint);

        }


        //Apply FlipType
        if (flipType == FlipType.VERTICAL_HORIZONTAL)
            bitmapBack = BitmapProcessing.flip(bitmapBack, true, true);
        if (flipType == FlipType.HORIZONTAL)
            bitmapBack = BitmapProcessing.flip(bitmapBack, true, false);
        else if (flipType == FlipType.VERTICAL)
            bitmapBack = BitmapProcessing.flip(bitmapBack, false, true);


        //Apply Effects
        if (effectTypes == EffectTypes.EMBOSS) {
            bitmapBack = new EmbossEffectHandler(mContext).executeProcess(bitmapBack, false, bubbleTextVo.getOpacity());
        } else if (effectTypes == EffectTypes.DEBOSS) {
            bitmapBack = new DebossEffectHandler(mContext).executeProcess(bitmapBack, false, bubbleTextVo.getOpacity());
        } else if (effectTypes == EffectTypes.EMBROIDERY) {
            bitmapBack = new EmbroideryEffectHandler(mContext).executeProcess(bubbleTextVo.getEmbroideryColorCode(), bitmapBack, R.drawable.texture1, false);
        } else if (effectTypes == EffectTypes.ENGRAVE) {
            bitmapBack = new EngraveEffectHandler(mContext).executeProcess(bitmapBack);
        } else if (effectTypes == EffectTypes.SATIN_EACH) {
            bitmapBack = new SatinEachEffectHandler(mContext).executeProcess(bitmapBack);
        } /*else if (effectTypes == EffectTypes.SINGLE_COLOR) {
            bitmapBack = new SingleColorHandler(mContext).executeProcess(bitmapBack, bubbleTextVo.getSingleColorCode());
        } */else if (effectTypes == EffectTypes.SHARPNESS) {
            bitmapBack = new SharpenEffectHandler(mContext).executeProcess(bitmapBack, DEFAULT_SHARPNESS);
        } else if (effectTypes == EffectTypes.WOODEN) {
            bitmapBack = new WoodenEffectHandler(mContext).executeProcess(bitmapBack, R.drawable.wooden_mask);
        } else if (effectTypes == EffectTypes.TONE_ON_TONE){
            bitmapBack = new ToneOnToneHandler(mContext).executeProcess(bitmapBack, bubbleTextVo.getToneOnToneColorCode());
        }else if (effectTypes ==EffectTypes.LEATHER_ENGRAVED){
            bitmapBack= new LeatherEngravedEffectHandler(mContext).executeProcess(bitmapBack, bubbleTextVo.getLeatherEngravedColorCode());
        }/*else{
            bitmapBack = new MultiColorEffectHandler(mContext).executeProcess(bitmapBack);
        }*/

//        canvas.drawBitmap(bitmapBack, 0, 0, null);
//        canvas.drawBitmap(bitmapBack,0,0,null);

        //Update View Bitmap
        mBubbleTextView.setChangeEffectBitmap(bitmapBack);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public BubbleTextView getBubbleTextView() {
        return mBubbleTextView;
    }
}
