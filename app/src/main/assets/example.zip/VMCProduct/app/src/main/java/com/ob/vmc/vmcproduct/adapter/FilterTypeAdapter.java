package com.ob.vmc.vmcproduct.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.communicator.OnFilterTypeClick;

import java.util.ArrayList;

/**
 * Created by khyati5403 on 10/20/2016.
 */

public class FilterTypeAdapter extends RecyclerView.Adapter<FilterTypeAdapter.FilterViewHolder> {

    private final LayoutInflater mInfalte;
    private ArrayList<String> mNameList;
    private final OnFilterTypeClick mListener;
    private final ArrayList<Integer> selected = new ArrayList<>();

    public FilterTypeAdapter(Context context, ArrayList<String> list, OnFilterTypeClick onFilterTypeClick) {
        this.mInfalte = LayoutInflater.from(context);
        mNameList = list;
        mListener = onFilterTypeClick;
    }

    @Override
    public FilterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInfalte.inflate(R.layout.filter_left_row, parent, false);
        return new FilterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final FilterViewHolder holder, final int position) {

        if (!selected.contains(position))
        {
            // view not selected
            holder.parent.setSelected(false);
            holder.sdvRightArrow.setVisibility(View.GONE);

        }
        else
        {
            // view is selected
            holder.parent.setSelected(true);
            holder.sdvRightArrow.setVisibility(View.VISIBLE);

        }
        holder.tvItemName.setText(mNameList.get(position));
        holder.parent.setTag(position);
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final int pos = (int) view.getTag();
                mListener.onFilterTypeClick(position);
                view.setSelected(true);
                if (view.isSelected()){
                    holder.sdvRightArrow.setVisibility(View.VISIBLE);
                }else {
                    holder.sdvRightArrow.setVisibility(View.GONE);
                }
                selected.add(pos);
                // forcing single selection here
                if (selected.isEmpty())
                {
                    selected.add(pos);
                }
                else
                {
                    final int oldSelected = selected.get(0);
                    selected.clear();
                    selected.add(pos);
                    // we do not notify that an item has been selected
                    // because that work is done here.  we instead send
                    // notifications for items to be deselected
                    notifyItemChanged(oldSelected);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return mNameList.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    class FilterViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvItemName;
        ImageView sdvRightArrow;
        View parent;

        public FilterViewHolder(View itemView)
        {
            super(itemView);
            parent = itemView;
            tvItemName = (TextView) parent.findViewById(R.id.tv_ItemName);
            sdvRightArrow = (ImageView)parent.findViewById(R.id.flr_sdvRightArrow);
        }
    }
}
