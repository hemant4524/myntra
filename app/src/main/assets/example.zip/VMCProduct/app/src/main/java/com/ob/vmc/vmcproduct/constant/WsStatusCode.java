package com.ob.vmc.vmcproduct.constant;

/**
 * Created by Ishan4452 on 11/14/2016.
 */

public class WsStatusCode {
    public static final int STATUS_1 = 1;
    public static final int STATUS_0 = 0;
}
