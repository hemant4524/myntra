package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.ecommercelibrary.common.APIType;
import com.ob.ecommercelibrary.common.KeyConstant;
import com.ob.ecommercelibrary.http.FormHttpCaller;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.ecommercelibrary.vo.NameValuePair;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.constant.WSKeyConstant;
import com.ob.vmc.vmcproduct.constant.WSRequestCodeConstant;
import com.ob.vmc.vmcproduct.constant.WSUrlConstant;
import com.ob.vmc.vmcproduct.constant.WsStatusCode;
import com.ob.vmc.vmcproduct.httpcommon.OnCompleteListener;
import com.ob.vmc.vmcproduct.httpcommon.ResponseHandler;
import com.ob.vmc.vmcproduct.model.httpmodel.LoginVo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by khyati5403 on 10/17/2016.
 */

public class LoginActivity extends AppCompatActivity implements OnCompleteListener {

    private EditText metUsername, metPassword;
    private TextView mtvLogin, mtvForgetPassword;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        initListener();
    }

    private void initViews() {
        metUsername = (EditText) findViewById(R.id.al_etUsername);
        metPassword = (EditText) findViewById(R.id.al_etPassword);
        mtvLogin = (TextView) findViewById(R.id.al_tvLogin);

    }

    private void initListener() {
        mtvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isValid = loginValidation();
                if (!isValid) {
                    submitLoginCredential();
                }
            }
        });

        mtvForgetPassword = (TextView) findViewById(R.id.al_tvForgotPassword);

        mtvForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }


    private void submitLoginCredential() {

        CommonUtil.showProgressDialog(this, null, null, false, null, 1, getSupportFragmentManager());

        String username = metUsername.getText().toString().trim();
        String password = metPassword.getText().toString().trim();

        List<NameValuePair> postParams = new ArrayList<>();
        postParams.add(new NameValuePair(WSKeyConstant.KEY_AUTH_USERNAME, username));
        postParams.add(new NameValuePair(WSKeyConstant.KEY_AUTH_PASSWORD, password));


        FormHttpCaller formHttpCaller = new FormHttpCaller(this, WSUrlConstant.loginAPIUrl(), APIType.METHOD_POST, postParams, WSRequestCodeConstant.REQUEST_POST_LOGIN, new ResponseHandler(this));
        formHttpCaller.execute();

    }


    /**
     * Check username and password validation
     *
     * @return validation result
     */
    private boolean loginValidation() {
        boolean isError;

        String username = metUsername.getText().toString().trim();
        String password = metPassword.getText().toString().trim();

        if (username.length() == 0) {
            isError = true;
            metUsername.setError("Invalid username");
        } else {
            metUsername.setError(null);
            isError = false;
        }


        if (password.length() == 0) {
            isError = true;
            metPassword.setError("Invalid password");
        } else {
            if (!isError)
                isError = false;
            metPassword.setError(null);
        }

        return isError;

    }

    @Override
    public void onSuccessComplete(Object itemObj, int requestCode) {
        BaseVo baseVo = (BaseVo) itemObj;
        if (requestCode == WSRequestCodeConstant.REQUEST_POST_LOGIN) {
            CommonUtil.dismissProgressDialog();
            if (baseVo.getStatus() == (WsStatusCode.STATUS_1)) {
                LoginVo loginVo = (LoginVo) baseVo;
                LoginVo.LoginDataVo loginDataVo = loginVo.getData();
                if (loginDataVo != null) {
                    AppSetting.setString(this, KeyConstant.PREF_ACCESS_TOKEN, loginDataVo.getToken());
                    LoginVo.LoginDataVo.LoginUserVo userVo = loginDataVo.getUser();
                    if (userVo != null) {
                        AppSetting.setInt(this, SharePrefConstant.KEY_USER_ID, userVo.getUserId());
                        AppSetting.setString(this, SharePrefConstant.KEY_USER_EMAIL, userVo.getEmail());
                        AppSetting.setString(this, SharePrefConstant.KEY_SUPPLIER_ID, userVo.getSupplierId());
                        AppSetting.setString(this, SharePrefConstant.KEY_SUPPLIER_TYPE, userVo.getSupplierType());
                    }
                    startActivity(new Intent(this, ProductListingActivity.class));
                    finish();
                }
            } else {
                Toast.makeText(this, baseVo.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    public void onFailComplete(Object itemObj, int requestCode) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        Toast.makeText(this, baseVo.getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(Object itemObj) {
        CommonUtil.dismissProgressDialog();
        BaseVo baseVo = (BaseVo) itemObj;
        if (baseVo.getCustomException() != null)
            Toast.makeText(this, baseVo.getCustomException().getMessage(), Toast.LENGTH_SHORT).show();
    }
}
