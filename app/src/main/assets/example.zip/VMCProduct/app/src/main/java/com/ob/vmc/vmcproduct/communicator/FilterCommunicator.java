package com.ob.vmc.vmcproduct.communicator;

/**
 * interface used to handle filter attribute selection
 */
public interface FilterCommunicator {

//    void onAttributeClick(CommonIdNameCountVo commonVo, SearchAttributeFilterArrayEntity.ColorMappingEntity colorVo, int itemType);

    /**
     * Method called to notify that an attribute from list has been selected
     * @param value String currently selected value(s)
     * @param position String currently selected position(s)
     * @param itemType int TYPE of item/filter selected
     */
//    void onAttributeClick(String value, String position, int itemType);
    void onAttributeClick(String value, String position);
/*
    *//**
     * Method called to notify that a currency filter has been selected
     * @param vo Selected currency
     *//*
    void onCurrencySelected(CurrencyVo vo);

    *//**
     * Method to notify that price range filter has been changed
     * @param minPrice Selected minimum price
     * @param maxPrice Selected maximum price
     *//*
    void onPriceRangeSelected(double minPrice, double maxPrice);

    *//**
     *
     *//*
    void onColorSelected();

    *//**
     * Method called to notify that a shade has been selected
     * @param selected Currently selected shades
     * @param actualSelectedColorId selected color id
     * @param actualSelectedColorName selected color name
     *//*
    void onColorShadeSelected(String selected, String actualSelectedColorId, String actualSelectedColorName);

    *//**
     * Method called to notify that a sortBy has been selected
     * @param sortedVo Selected sort by
     *//*
    void onSortBySelected(FilterSortedVo sortedVo);*/
}