package com.ob.vmc.vmcproduct.effects;

import com.ob.vmc.vmcproduct.customviews.BubbleTextView;
import com.ob.vmc.vmcproduct.customviews.StickerView;

/**
 * Created by Ishan4452 on 1/5/2017.
 */

public interface StickerEffectTaskListener {
    void handleStickerEffectTaskUpdate(StickerView stickerView);
    void handleBubbleEffectTaskUpdate(BubbleTextView bubbleTextView);
}
