package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;

import com.andoblib.log.CustomLogHandler;
import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

public class EmbossEffectsAsync extends AsyncTask<Void, Void, Bitmap> {

    private static final String TAG = EmbossEffectsAsync.class.getName();
    private View view;
    private Bitmap srcBitmap;
    private Context mContext;
    private EmbossEventResult mEmbossEventResult;
    private String error;

    public EmbossEffectsAsync(Context mContext, EmbossEventResult engraveEffectsAsync, Bitmap pBitmap) {
        this.mContext = mContext;
        this.mEmbossEventResult = engraveEffectsAsync;
        this.srcBitmap = pBitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
//        CommonUtil.showProgressDialog(mContext, null, "Please wait...", false, null, -1, ((Activity)mContext.);
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;
        /**
         * Get bitmap from URI
         */
        try {
            if (srcBitmap != null) {
                bitmap = BitmapProcessing.doEmboss(srcBitmap, true);
            } else {
                CustomLogHandler.printVerbose(TAG, "Bitmap null Found");
            }
        } catch (Exception e) {
            error = e.getMessage();
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if (bitmap != null) {
            mEmbossEventResult.onEmbossEventComplete(bitmap);
        } else {
            mEmbossEventResult.onEmbossEventFail(error);
        }
    }

    public interface EmbossEventResult {
        void onEmbossEventComplete(Bitmap bitmap);

        void onEmbossEventFail(String exceptionMsg);
    }


}