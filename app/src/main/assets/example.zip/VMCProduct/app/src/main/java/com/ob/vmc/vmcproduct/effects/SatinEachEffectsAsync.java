package com.ob.vmc.vmcproduct.effects;


import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 3/16/2016.
 */
public class SatinEachEffectsAsync extends AsyncTask<Void, Void, Bitmap> {
    private Uri mUri;
    private Bitmap srcBitmap;
    private Context mContext;
    private SatinEventResult mSatinEachEventResult;
    private String error;
    private View view;

    public SatinEachEffectsAsync(Context mContext, SatinEventResult satinEffectsAsync, Bitmap bitmap) {
        this.mContext = mContext;
        this.mSatinEachEventResult = satinEffectsAsync;
        this.srcBitmap = bitmap;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;
        /**
         * Get bitmap from URI
         */
        try {
            if (srcBitmap != null) {
                bitmap = BitmapProcessing.doSatinEach(srcBitmap);
            }
        } catch (Exception e) {
            error = e.getMessage();
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mSatinEachEventResult.onSatinEachEventComplete(bitmap);
        } else {
            mSatinEachEventResult.onSatinEachEventFail(error);
        }
    }

    public interface SatinEventResult {
        void onSatinEachEventComplete(Bitmap bitmap);

        void onSatinEachEventFail(String exceptionMsg);
    }
}