package com.ob.vmc.vmcproduct.handler;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.ob.vmc.vmcproduct.customcontrol.effect.BitmapProcessing;

/**
 * Created by khyati5403 on 12/28/2016.
 */

public class WoodenEffectHandler {

    private Context mContext;
    private boolean isWoodenEffect;

    public WoodenEffectHandler(Context pContext) {
        mContext=pContext;
    }
    public Bitmap executeProcess(Bitmap srcBitmap, int drawableMask ) {

        try {
            if (srcBitmap != null) {
                Bitmap mask = BitmapFactory.decodeResource(mContext.getResources(), drawableMask );
                srcBitmap = BitmapProcessing.woodenEffect(srcBitmap, mask);
            }
        } catch (Exception e) {

            e.printStackTrace();
        }
        return  srcBitmap;

    }
}
