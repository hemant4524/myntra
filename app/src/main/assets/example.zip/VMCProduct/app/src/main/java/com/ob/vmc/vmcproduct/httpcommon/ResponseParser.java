package com.ob.vmc.vmcproduct.httpcommon;

import android.support.annotation.Nullable;

import com.andoblib.constant.Constants;
import com.andoblib.customexception.CustomException;
import com.andoblib.customexception.ExceptionConstant;
import com.andoblib.log.CustomLogHandler;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.ob.ecommercelibrary.vo.BaseVo;
import com.ob.vmc.vmcproduct.model.appmodel.PmsColorVo;
import com.ob.vmc.vmcproduct.model.appmodel.RelatedPmsColorVo;
import com.ob.vmc.vmcproduct.model.httpmodel.GetSupplierDetailVo;
import com.ob.vmc.vmcproduct.model.httpmodel.LoginVo;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductDetailVo;
import com.ob.vmc.vmcproduct.model.httpmodel.ProductVo;
import com.ob.vmc.vmcproduct.model.httpmodel.SuppliersVO;
import com.ob.vmc.vmcproduct.model.httpmodel.VirtualUploadVo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;


/**
 * This class is the common web service response parser class that is used to parse the specific response.
 */
public class ResponseParser {

    private static final String TAG = "ResponseParser";


    public static
    @Nullable
    String getStringResponse(Reader pResponse) {
        if (pResponse == null) {
            return null;
        }

        BufferedReader br = new BufferedReader(pResponse);

        StringBuilder sb = new StringBuilder();
        String text;
        try {
            while ((text = br.readLine()) != null)
            {
                sb.append(text);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
          CustomLogHandler.printInfo(TAG, "====Response====  " + sb.toString());
        return sb.toString();
    }

    /**
     *Parse ArtworkBaseVo response
     * @param reader Api Response Reader
     * @return
     * @throws CustomException
     */
    public static BaseVo parseGetBaseVo(Reader reader) throws CustomException {
        BaseVo authorizeTokenVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            authorizeTokenVo = mGson.fromJson(getStringResponse(reader), BaseVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  authorizeTokenVo;
    }


    /**
     *Parse SupplierVo response
     * @param reader Api Response Reader
     * @return
     * @throws CustomException
     */
    public static BaseVo parseGetSupplier(Reader reader) throws CustomException {
        BaseVo supplierVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            supplierVo = mGson.fromJson(getStringResponse(reader), SuppliersVO.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  supplierVo;
    }

    /**
     *Parse ProductVo response
     * @param reader Api Response Reader
     * @return
     * @throws CustomException
     */
    public static BaseVo parseGetProductList(Reader reader) throws CustomException {
        BaseVo productVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            productVo = mGson.fromJson(getStringResponse(reader), ProductVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  productVo;
    }

    public static BaseVo parsePostLogin(Reader reader)throws CustomException {
        BaseVo productVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            productVo = mGson.fromJson(getStringResponse(reader), LoginVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  productVo;
    }

    public static BaseVo parseproductDetail(Reader reader)throws CustomException {
        BaseVo productDetailVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            productDetailVo = mGson.fromJson(getStringResponse(reader), ProductDetailVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  productDetailVo;
    }
    public static BaseVo parsepmsColor(Reader reader)throws CustomException {
        BaseVo colorVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            colorVo = mGson.fromJson(getStringResponse(reader), PmsColorVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  colorVo;
    }

    public static BaseVo parsepmsRelatedColor(Reader reader) throws CustomException {
        BaseVo colorVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            colorVo = mGson.fromJson(getStringResponse(reader), RelatedPmsColorVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  colorVo;
    }

    public static BaseVo parseVirtualUpload(Reader reader)throws CustomException {
        BaseVo uploadVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            uploadVo = mGson.fromJson(getStringResponse(reader), VirtualUploadVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return  uploadVo;
    }

    public static BaseVo parseGetSupplierDetail(Reader reader) throws CustomException {
        BaseVo getSupplierDetailVo;
        try
        {
            GsonBuilder mGsonBuilder = new GsonBuilder();
            Gson mGson = mGsonBuilder.create();
            getSupplierDetailVo = mGson.fromJson(getStringResponse(reader), GetSupplierDetailVo.class);

        } catch (JsonSyntaxException p_e)
        {
            throw new CustomException(Constants.ERR_INVALID_RESPONSE, ExceptionConstant.ERROR_CODE_CUSTOM);
        }
        return getSupplierDetailVo;
    }
}