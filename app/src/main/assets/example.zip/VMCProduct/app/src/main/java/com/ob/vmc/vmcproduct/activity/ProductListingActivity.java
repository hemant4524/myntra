package com.ob.vmc.vmcproduct.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.andoblib.listener.YesNoAlertDialogListener;
import com.andoblib.util.AppSetting;
import com.andoblib.util.CommonUtil;
import com.ob.vmc.vmcproduct.R;
import com.ob.vmc.vmcproduct.constant.SharePrefConstant;
import com.ob.vmc.vmcproduct.customcontrol.ActionViewListStyle;
import com.ob.vmc.vmcproduct.fragment.ProductListingFragment;
import com.ob.vmc.vmcproduct.model.httpmodel.Product;

import java.util.List;

/**
 * Created by khyati5403 on 10/19/2016.
 */

public class ProductListingActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = ProductListingActivity.class.getSimpleName();
    public static final int REQUEST_CODE_FILTER_ACTIVITY = 12345;
    public static final String EXTRA_FILTER_SELECTED_CATEGORY = "selectedCategory";
    public static final String EXTRA_SEARCH_FILTER_PARAMS = "searchFilterParams";
    public static final String EXTRA_SEARCH_FILTER_ONLY_PARAMS = "searchFilterOnlyParams";

    private static final String PRODUCTLISTINGFRAGMENT = "ProductListingFragment";
    private Toolbar mToolbar;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private ActionViewListStyle actionViewListStyle;

    // Flag to know which view is currently visible. List or Grid
    private boolean showingList = true;

    // Set to true if a new list is performed
    private boolean mIsList = true;
    // Set to true if more data can be loaded
    private boolean mIsLoadMore = true;
    // set to true if data is been currently fetched.
    private boolean mIsLoading = false;


    private ProductListingFragment mListFragment;
    private ProductListingFragment mGridFragment;
    private String mOriginalCategory = null;
    public List<Product> productList;
    private String mSelectedCategory;
    public View fab_filter;
    private MenuItem listingStyleItem;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_listing);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mToolbar.setTitle(R.string.app_name);
        setupToolbar();

        mDrawerLayout = (DrawerLayout) findViewById(R.id.apl_dlDrawerContainer);

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.open_drawer, R.string.close_drawer) {

            /** Called when a drawer has settled in a completely open state. */
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            /** Called when a drawer has settled in a completely closed state. */
            @Override
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }
        };
        mDrawerToggle.setDrawerIndicatorEnabled(false);
        mToolbar.setNavigationIcon(R.drawable.menu);

        // Set the drawer toggle as the DrawerListener
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.LEFT);
            }
        });
        //TODO Change when all supplier product list webservice ready
//        mSelectedCategory="4";

        fab_filter = findViewById(R.id.apl_fabFilter);
        fab_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductListingActivity.this, FilterActivity.class);
                intent.putExtra(ProductListingActivity.EXTRA_FILTER_SELECTED_CATEGORY, mSelectedCategory);
                startActivityForResult(intent, REQUEST_CODE_FILTER_ACTIVITY);
            }
        });
        setListFragment();
        bindDrawerMenuFragment(savedInstanceState);
    }

    private void bindDrawerMenuFragment(Bundle savedInstanceState) {
 /*       FragmentManager manager = getSupportFragmentManager();
        Fragment mDrawerFragment;
        if (savedInstanceState == null){
            mDrawerFragment = DrawerMenuFragment.newInstance();
            manager.beginTransaction().replace(R.id.apl_flDrawerLayout, mDrawerFragment).commit();
        } else {
            mDrawerFragment = manager.findFragmentById(R.id.apl_flDrawerLayout);
        }*/
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View viewHeader=navigationView.getHeaderView(0);
        String userName=AppSetting.getString(this, SharePrefConstant.KEY_USER_EMAIL,"");
        ((TextView)viewHeader.findViewById(R.id.nhd_userEmail)).setText(userName);
    }

    private void setupToolbar() {
        mToolbar.inflateMenu(R.menu.menu_product_list);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Log.i(TAG, "onMenuItemClick    " + item + ",    item.getItemId()  = " + item.getItemId());
                return false;
            }
        });

        listingStyleItem = mToolbar.getMenu().findItem(R.id.mpl_action_list);
//        listingStyleItem.setVisible(false);
        actionViewListStyle = (ActionViewListStyle) listingStyleItem.getActionView();
        actionViewListStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!actionViewListStyle.isAnimationPerforming()) {
                    onActionButtonClick();
                }
            }
        });

    }

    private void onActionButtonClick() {
//        if (showingList) {
            setGridFragment();
        /*}else {
            setListFragment();
        }*/
    }

    private void setGridFragment() {

        FragmentManager manager = getSupportFragmentManager();
        Fragment fragment=manager.findFragmentByTag(PRODUCTLISTINGFRAGMENT);

        if (fragment!=null) {
            ProductListingFragment productListingFragment= (ProductListingFragment) fragment;
            productListingFragment.changeListingViewStyle();
        }

        actionViewListStyle.changeIcon(R.drawable.list_icon);
        showingList = false;
    }

    private void setListFragment() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        if (mListFragment == null) {
            mListFragment = ProductListingFragment.newInstance();
            transaction.add(R.id.apl_flMainFrame, mListFragment, PRODUCTLISTINGFRAGMENT);
        } else {
            transaction.show(mListFragment);
        }
        if (mGridFragment != null) {
            transaction.hide(mGridFragment);
        }
        transaction.commit();
        showingList = true;

        actionViewListStyle.changeIcon(R.drawable.grid_icon);
        mListFragment.notifyDataSetChange();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_FILTER_ACTIVITY){
            Bundle extra = data.getExtras();
            mSelectedCategory = extra.getString(ProductListingActivity.EXTRA_FILTER_SELECTED_CATEGORY);

            if (mListFragment != null) {
                mListFragment.onActivityResult(requestCode, resultCode, data);
            }
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
        } else if (id == R.id.nav_contactUs) {

        } else if (id == R.id.nav_aboutUs) {

        } else if (id == R.id.nav_setting) {

        } else if (id == R.id.nav_logOut) {

            CommonUtil.showYesNoDialog(this, null, "Are you want to LOG OUT?", "YES", "NO", true, -1, new YesNoAlertDialogListener() {
                @Override
                public void onYesNoDialogButtonClicked(int pRequestCode, int pWhichButton) {
                    if (pWhichButton==YesNoAlertDialogListener.BUTTON_POSITIVE)
                    {
                        AppSetting.clearPreference(ProductListingActivity.this);
                        startActivity(new Intent(ProductListingActivity.this,LoginActivity.class));
                        finish();
                    }
                }
            },getSupportFragmentManager());


        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {

        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

}
