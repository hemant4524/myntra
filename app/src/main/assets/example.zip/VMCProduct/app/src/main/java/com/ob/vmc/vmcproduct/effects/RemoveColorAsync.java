package com.ob.vmc.vmcproduct.effects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;

public class RemoveColorAsync extends AsyncTask<Void, Void, Bitmap> {

    private String  mBitmapPath;
private boolean isRemovedWhite;
    private Context mContext;
    private RemoveColorEventResult mRemoveColorEventResult;
    private String error;

    private final int[] COLOR_FROM_WHITE = new int[]{255, 255, 255};
    private final int[] COLOR_FROM_BLACK = new int[]{0, 0, 0};
    private final int WHITE_THRESHOLD= 100;
    private final int BLACK_THRESHOLD= 100;
    private boolean isRemovedBlack;
    private Bitmap srcBitmap;

    public RemoveColorAsync(Context mContext,Bitmap bitmapPath, boolean isRemoveWhite,boolean isRemoveBlack,RemoveColorEventResult engraveEffectsAsync) {
        this.mContext = mContext;
        this.mRemoveColorEventResult = engraveEffectsAsync;
//        this.mBitmapPath = bitmapPath;
        this.srcBitmap = bitmapPath;
        this.isRemovedWhite = isRemoveWhite;
        this.isRemovedBlack = isRemoveBlack;

    }




    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        Bitmap bitmap = null;

            /**
             * Get bitmap from URI
            */
            try {

//                Uri uri=Uri.fromFile(new File(mBitmapPath));
//                Bitmap srcBitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
                //Need to copy to ensure that the bitmap is mutable.
                 Bitmap bitmapOri = srcBitmap.copy(Bitmap.Config.ARGB_8888, true);
                int[] intArray = new int[srcBitmap.getWidth() * srcBitmap.getHeight()];
                bitmapOri.getPixels(intArray, 0, bitmapOri.getWidth(), 0, 0, bitmapOri.getWidth(), bitmapOri.getHeight());
                for(int x = 0;x < intArray.length;x++) {
                    if (isRemovedWhite)
                        intArray[x] = matchWhite(intArray[x]);
                    if(isRemovedBlack)
                        intArray[x] = matchBlack(intArray[x]);

                }
                bitmap = Bitmap.createBitmap(intArray, bitmapOri.getWidth(), bitmapOri.getHeight(), bitmapOri.getConfig());
//                mUri = Uri.fromFile(FileUtils.saveBitmap(bitmap, mContext));

            } catch (Exception e) {
                error = e.getMessage();
                e.printStackTrace();
            }


        return bitmap;
    }

    private int matchWhite(int pixel)
    {
        //There may be a better way to match, but I wanted to do a comparison ignoring
        //transparency, so I couldn't just do a direct integer compare.
        return Math.abs(Color.red(pixel) - COLOR_FROM_WHITE[0]) < WHITE_THRESHOLD &&
                Math.abs(Color.green(pixel) - COLOR_FROM_WHITE[1]) < WHITE_THRESHOLD &&
                Math.abs(Color.blue(pixel) - COLOR_FROM_WHITE[2]) < WHITE_THRESHOLD ? 0: pixel;
    }
    private int matchBlack(int pixel)
    {
        //There may be a better way to match, but I wanted to do a comparison ignoring
        //transparency, so I couldn't just do a direct integer compare.
        return Math.abs(Color.red(pixel) - COLOR_FROM_BLACK[0]) < BLACK_THRESHOLD &&
               Math.abs(Color.green(pixel) - COLOR_FROM_BLACK[1]) < BLACK_THRESHOLD &&
               Math.abs(Color.blue(pixel) - COLOR_FROM_BLACK[2]) < BLACK_THRESHOLD ? 0:pixel;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {

        if (bitmap != null) {
            mRemoveColorEventResult.onRemoveColorEventComplete(bitmap);
        } else {
            mRemoveColorEventResult.onRemoveColorEventFail(error);
        }
    }

    public interface RemoveColorEventResult {
        void onRemoveColorEventComplete(Bitmap bitmap);

        void onRemoveColorEventFail(String exceptionMsg);
    }


}