package com.ob.vmc.vmcproduct.model.appmodel;

/**
 * Created by khyati5403 on 12/6/2016.
 */

public class ColorVo {
    int colorId;
    int colorValue;

    public ColorVo(int colorValue) {
        this.colorValue = colorValue;
    }

    public int getColorId() {
        return colorId;
    }

    public void setColorId(int colorId) {
        this.colorId = colorId;
    }

    public int getColorValue() {
        return colorValue;
    }

    public void setColorValue(int colorValue) {
        this.colorValue = colorValue;
    }
}
